#include <fstream>
#include <iostream>
#include <math.h>
#include "PolStr.h"
#include <string>
#include <windows.h>

using namespace std;

struct Res {
    double x;
    double fx;
    double prec;
};

Res bisection(char function[], double a, double b, double prec) {
    char *polstr = CreatePolStr(function, 0);
    while ((b-a)/2 >= prec && fabs(EvalPolStr(polstr, (a+b)/2)) >= prec) {
        double cent = (a+b)/2;
        if (EvalPolStr(polstr, a)*EvalPolStr(polstr, cent)<=0) {b=cent;}
        else {a = cent;}
    }
    Res result;
    result.x = (a+b)/2;
    result.fx = EvalPolStr(polstr, result.x);
    result.prec = b-result.x;
    delete[] polstr;
    return result;
}

Res chord(char function[], double a, double b, double prec) {
    char *polstr = CreatePolStr(function, 0);
    double fa, fb, fc;
    double x_curr = a, x_prev;
    while (abs(x_curr-x_prev)>=prec && fabs(EvalPolStr(polstr, abs(x_curr))) >= prec) {
        fa = EvalPolStr(polstr, a); fb = EvalPolStr(polstr, b);
        double cent = a-fa*(b-a)/(fb-fa);
        x_prev = x_curr;
        x_curr = cent;
        fc = EvalPolStr(polstr, cent);
        //cout<<"a="<<a<<" c="<<cent<<" b="<<b<<" x_prev="<<x_prev<<endl;
        if (fa*fc<=0) {b=cent;}
        else {a = cent;}
    }
    Res result;
    fa = EvalPolStr(polstr, a); fb = EvalPolStr(polstr, b);
    result.x = a-fa*(b-a)/(fb-fa);
    result.fx = EvalPolStr(polstr, result.x);
    result.prec = abs(result.x-x_prev);
    delete[] polstr;
    return result;
}

Res golden_section(char function[], double a, double b, double prec) {
    char *polstr = CreatePolStr(function, 0);
    double fa, fd;
    double gamma {(sqrt(5.0)+1)/2.0};
    while ((b-a)/2 >= prec && fabs(EvalPolStr(polstr, (a+b)/2)) >= prec) {
        fa = EvalPolStr(polstr, a);
        double d = a+(b-a)/gamma;
        double c = a+(b-a)/(gamma*gamma);
        fd = EvalPolStr(polstr, d);
        if (fa*fd<=0) {b=d;}
        else {a=c;}
    }
    Res result;
    result.x = (a+b)/2;
    result.fx = EvalPolStr(polstr, result.x);
    result.prec = b-result.x;
    delete[] polstr;
    return result;
}

Res newton(char function[], double a, double b, double prec) {
    char *polstr = CreatePolStr(function, 0);
    double x_k, x_kp1, fx, f1x;
    
    double f2_mid = EvalPolStr(polstr, (a + b) / 2, 2);
    double fa = EvalPolStr(polstr, a);
    double fb = EvalPolStr(polstr, b);
    
    if (fa * f2_mid > 0) {
        x_k = a;
    }

    else if (fb * f2_mid > 0) {
        x_k = b;
    }

    else {
        x_k = (a + b) / 2;
    }

    double abs_prec = prec;
    double delta = prec;
    
    do {
        fx = EvalPolStr(polstr, x_k);
        f1x = EvalPolStr(polstr, x_k, 1);
        
        if (fabs(f1x) < 1e-12) {
            x_kp1 = x_k + 0.001;
        } else {
            x_kp1 = x_k - fx / f1x;
        }
        
        if ((fabs(x_kp1 - x_k) < abs_prec) && (fabs(fx) < delta)) break;
        
        x_k = x_kp1;
        
    } while (true);
    
    Res result;
    result.x = x_kp1;
    result.fx = EvalPolStr(polstr, result.x);
    result.prec = fabs(x_kp1 - x_k);
    
    delete[] polstr;
    return result;
}

Res iteration(char function[], double a, double b, double prec) {
    char *polstr = CreatePolStr(function, 0);
    
    double M = 0;
    for (int i = 0; i <= 100; i++) {
        double x = a + (b - a) * i / 100.0;
        double der = fabs(EvalPolStr(polstr, x, 1));
        if (der > M) M = der;
    }
    
    if (fabs(M) < 1e-10) M = 1.0;

    double x;
    double x_test = (a + b) / 2;
    double der_test = fabs(EvalPolStr(polstr, x_test, 1));
    
    if (fabs(1 - der_test/M) < 1) {
        x = x_test;
    } else {
        for (double i = a; i < b; i += (b-a)/100.0) {
            if (fabs(1 - (EvalPolStr(polstr, i, 1))/M) < 1) {
                x = i;
                break;
            }
        }
    }
    
    double x_prev = x + 2 * prec;
    
    while (fabs(x - x_prev) >= prec && fabs(EvalPolStr(polstr, x)) >= prec) {
        x_prev = x;
        double fx = EvalPolStr(polstr, x);
        x = x - fx / M;
    }
    
    Res result;
    result.x = x;
    result.fx = EvalPolStr(polstr, result.x);
    result.prec = fabs(x - x_prev);
    
    delete[] polstr;
    return result;
}

Res combined(char function[], double a, double b, double prec) {
    char *polstr = CreatePolStr(function, 0);
    
    double a_k = a;
    double b_k = b;
    double c_k;
    
    double f2_mid = EvalPolStr(polstr, (a + b) / 2, 2);
    
    bool newton_on_left = (EvalPolStr(polstr, a, 2) * f2_mid > 0);
    
    while ((b_k - a_k) / 2 >= prec && fabs(EvalPolStr(polstr, (a_k+b_k)/2)) >= prec) {
        double fa = EvalPolStr(polstr, a_k);
        double fb = EvalPolStr(polstr, b_k);
        
        c_k = a_k - fa * (b_k - a_k) / (fb - fa);
          
        if (newton_on_left) {
            double f1a = EvalPolStr(polstr, a_k, 1);
            if (fabs(f1a) > 1e-12) {
                a_k = a_k - fa / f1a;
            }
            b_k = c_k;
        } else {
            a_k = c_k;
            double f1b = EvalPolStr(polstr, b_k, 1);
            if (fabs(f1b) > 1e-12) {
                b_k = b_k - fb / f1b;
            }
        }
        
    }
    
    double root = (a_k + b_k) / 2;
    
    Res result;
    result.x = root;
    result.fx = EvalPolStr(polstr, root);
    result.prec = (b_k - a_k) / 2;
    
    delete[] polstr;
    return result;
}

int main() {
    SetConsoleCP(CP_UTF8);
    SetConsoleOutputCP(CP_UTF8);

    ifstream in("./input.txt");
    fstream out("./output.txt");
    if (!in.is_open()) {
        cout<<"Ошибка открытия входного файла"<<endl;
        return 1;
    }
    if (!out.is_open()) {
        cout<<"Ошибка открытия выходного файла"<<endl;
        return 1;
    }

    int method;
    string func;

    in>>method;
    string emptyline;
    getline(in, emptyline);
    getline(in, func);
    char* function = func.data();
    Res result;

    double a, b, prec;
    in >> a >> b >> prec;
    cout<<method<<" "<<function<<" "<<a<<", "<<b<<" "<<prec<<endl;
    switch (method) {
        case 1: result = bisection(function, a, b, prec); cout<<"bisection"<<endl; break;
        case 2: result = chord(function, a, b, prec); cout<<"chord"<<endl; break;
        case 3: result = golden_section(function, a, b, prec); cout<<"golden_section"<<endl; break;
        case 4: result = newton(function, a, b, prec); cout<<"newton"<<endl; break;
        case 5: result = iteration(function, a, b, prec); cout<<"iteration"<<endl; break;
        case 6: result = combined(function, a, b, prec); cout<<"combined"<<endl; break;
        default: cout << "Нет метода с таким номером" << endl; return 1; break;
    }
    cout << result.x <<" "<< result.fx <<" "<< result.prec << endl;

    out<<result.x<<endl;
    out<<result.fx<<endl;
    out<<result.prec<<endl;

#pragma region //Все методы без вывода в файл
    /*
    Res bisect_res;
    bisect_res = bisection(function, a, b, prec);
    cout << "===== Bisection =====" << endl;
    cout << "Root: " << bisect_res.x << endl;
    cout << "f(root): " << bisect_res.fx << endl;
    cout << "Final precision: " << bisect_res.prec << endl << endl;

    Res chord_res;
    chord_res = chord(function, a, b, prec);
    cout << "===== Chord =====" << endl;
    cout << "Root: " << chord_res.x << endl;
    cout << "f(root): " << chord_res.fx << endl;
    cout << "Final precision: " << chord_res.prec << endl << endl;

    Res gs_res;
    gs_res = golden_section(function, a, b, prec);
    cout << "===== Golden_section =====" << endl;
    cout << "Root: " << gs_res.x << endl;
    cout << "f(root): " << gs_res.fx << endl;
    cout << "Final precision: " << gs_res.prec << endl << endl;

    Res nt_res;
    nt_res = newton(function, a, b, prec);
    cout << "===== Newton =====" << endl;
    cout << "Root: " << nt_res.x << endl;
    cout << "f(root): " << nt_res.fx << endl;
    cout << "Final precision: " << nt_res.prec << endl << endl;

    Res it_res;
    it_res = iteration(function, a, b, prec);
    cout << "===== Iteration =====" << endl;
    cout << "Root: " << it_res.x << endl;
    cout << "f(root): " << it_res.fx << endl;
    cout << "Final precision: " << it_res.prec << endl << endl;

    Res cb_res;
    cb_res = combined(function, a, b, prec);
    cout << "===== Combined =====" << endl;
    cout << "Root: " << cb_res.x << endl;
    cout << "f(root): " << cb_res.fx << endl;
    cout << "Final precision: " << cb_res.prec << endl << endl;
    */
#pragma endregion

    in.close();
    out.close();
    return 0;
}
