#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
#include <vector>
#include <windows.h>

using namespace std;

// Вычисление нормы вектора
double vectorNorm(const vector<double>& v) {
    double sum = 0.0;
    for (double val : v) {
        sum += val * val;
    }
    return sqrt(sum);
}

// Вычисление нормы матрицы
double matrixNorm(const vector<vector<double>>& M) {
    int n = M.size();
    double sum = 0.0;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            sum += M[i][j] * M[i][j];
        }
    }
    return sqrt(sum);
}

// Вычисление невязки для СЛАУ: r = A*x - b
vector<double> computeResidual(const vector<vector<double>>& A, 
                                const vector<double>& b, 
                                const vector<double>& x) {
    int n = A.size();
    vector<double> residual(n, 0.0);
    
    for (int i = 0; i < n; i++) {
        double sum = 0.0;
        for (int j = 0; j < n; j++) {
            sum += A[i][j] * x[j];
        }
        residual[i] = sum - b[i];
    }
    
    return residual;
}

// Вычисление невязки для обратной матрицы: R = A*X - E
vector<vector<double>> computeInverseResidual(const vector<vector<double>>& A, 
                                                const vector<vector<double>>& X) {
    int n = A.size();
    vector<vector<double>> residual(n, vector<double>(n, 0.0));
    
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            double sum = 0.0;
            for (int k = 0; k < n; k++) {
                sum += A[i][k] * X[k][j];
            }
            residual[i][j] = sum - (i == j ? 1.0 : 0.0);
        }
    }
    
    return residual;
}

struct GaussResult {
    vector<double> x;
    vector<vector<vector<double>>> A_steps;
    vector<vector<double>> b_steps;
    double det;
    bool success;
};

// Прямой ход метода Гаусса
GaussResult gaussForwardElimination(vector<vector<double>> A, vector<double> b) {
    int n = A.size();
    GaussResult result;
    result.det = 1.0;
    result.success = true;
    
    result.A_steps.push_back(A);
    result.b_steps.push_back(b);
    
    for (int k = 0; k < n; k++) {
        if (fabs(A[k][k]) < 1e-15) {
            cout << "Ошибка: нулевой ведущий элемент на шаге " << k + 1 << endl;
            result.success = false;
            return result;
        }
        
        result.det *= A[k][k];
        
        double pivot = A[k][k];
        for (int j = k; j < n; j++) {
            A[k][j] /= pivot;
        }
        b[k] /= pivot;
        
        for (int i = k + 1; i < n; i++) {
            double factor = A[i][k];
            if (fabs(factor) < 1e-15) continue;
            
            for (int j = k; j < n; j++) {
                A[i][j] -= factor * A[k][j];
            }
            b[i] -= factor * b[k];
            A[i][k] = 0.0;
        }
        
        result.A_steps.push_back(A);
        result.b_steps.push_back(b);
    }
    
    return result;
}

// Обратный ход метода Гаусса
vector<double> gaussBackSubstitution(const vector<vector<double>>& A, 
                                      const vector<double>& b) {
    int n = A.size();
    vector<double> x(n, 0.0);
    
    for (int i = n - 1; i >= 0; i--) {
        double sum = 0.0;
        for (int j = i + 1; j < n; j++) {
            sum += A[i][j] * x[j];
        }
        x[i] = b[i] - sum;
    }
    
    return x;
}

// Вычисление обратной матрицы методом Гаусса
vector<vector<double>> gaussComputeInverse(vector<vector<double>> A) {
    int n = A.size();
    
    // Создаём расширенную матрицу [A | E]
    vector<vector<double>> augmented(n, vector<double>(2 * n, 0.0));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            augmented[i][j] = A[i][j];
        }
        augmented[i][n + i] = 1.0;  // Единичная матрица
    }
    
    // Прямой ход (приведение к верхнетреугольному виду)
    for (int k = 0; k < n; k++) {
        // Поиск главного элемента (для устойчивости)
        int maxRow = k;
        for (int i = k + 1; i < n; i++) {
            if (fabs(augmented[i][k]) > fabs(augmented[maxRow][k])) {
                maxRow = i;
            }
        }
        if (fabs(augmented[maxRow][k]) < 1e-15) {
            cout << "Ошибка: матрица вырождена" << endl;
            return vector<vector<double>>(n, vector<double>(n, 0.0));
        }
        
        // Меняем строки местами
        if (maxRow != k) {
            swap(augmented[k], augmented[maxRow]);
        }
        
        // Нормировка строки k
        double pivot = augmented[k][k];
        for (int j = k; j < 2 * n; j++) {
            augmented[k][j] /= pivot;
        }
        
        // Исключение в остальных строках
        for (int i = 0; i < n; i++) {
            if (i != k) {
                double factor = augmented[i][k];
                if (fabs(factor) < 1e-15) continue;
                for (int j = k; j < 2 * n; j++) {
                    augmented[i][j] -= factor * augmented[k][j];
                }
            }
        }
    }
    
    // Извлекаем обратную матрицу из правой половины
    vector<vector<double>> inv(n, vector<double>(n, 0.0));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            inv[i][j] = augmented[i][n + j];
        }
    }
    
    return inv;
}

// Вывод промежуточных результатов метода Гаусса
void gaussPrintIntermediate(ofstream& fout, const GaussResult& result) {
    int n = result.A_steps[0].size();
    fout << fixed << setprecision(6);
    
    fout << "A(0):" << endl;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            fout << setw(12) << result.A_steps[0][i][j] << " ";
        }
        fout << "| " << setw(12) << result.b_steps[0][i] << endl;
    }
    fout << endl;
    
    for (size_t k = 1; k < result.A_steps.size(); k++) {
        fout << "A(" << k << "):" << endl;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                fout << setw(12) << result.A_steps[k][i][j] << " ";
            }
            fout << "| " << setw(12) << result.b_steps[k][i] << endl;
        }
        fout << endl;
    }
}

struct SeidelResult {
    vector<double> x;
    vector<vector<double>> alpha;
    vector<double> beta;
    int iterations;
    double finalError;
    bool success;
};

// Проверка диагонального преобладания
bool hasDiagonalDominance(const vector<vector<double>>& A) {
    int n = A.size();
    for (int i = 0; i < n; i++) {
        double sum = 0.0;
        for (int j = 0; j < n; j++) {
            if (j != i) sum += fabs(A[i][j]);
        }
        if (fabs(A[i][i]) <= sum) {
            return false;
        }
    }
    return true;
}

// Преобразование системы A^T A x = A^T b (для обеспечения сходимости)
void symmetrizeSystem(const vector<vector<double>>& A, const vector<double>& b,
                       vector<vector<double>>& A_sym, vector<double>& b_sym) {
    int n = A.size();
    A_sym.assign(n, vector<double>(n, 0.0));
    b_sym.assign(n, 0.0);
    
    // A_sym = A^T * A
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            double sum = 0.0;
            for (int k = 0; k < n; k++) {
                sum += A[k][i] * A[k][j];
            }
            A_sym[i][j] = sum;
        }
    }
    
    // b_sym = A^T * b
    for (int i = 0; i < n; i++) {
        double sum = 0.0;
        for (int k = 0; k < n; k++) {
            sum += A[k][i] * b[k];
        }
        b_sym[i] = sum;
    }
}

// Построение матрицы alpha и вектора Beta для метода Зейделя
void buildAlphaBeta(const vector<vector<double>>& A, const vector<double>& b,
                    vector<vector<double>>& alpha, vector<double>& beta) {
    int n = A.size();
    alpha.assign(n, vector<double>(n, 0.0));
    beta.assign(n, 0.0);
    
    for (int i = 0; i < n; i++) {
        if (fabs(A[i][i]) < 1e-15) {
            cout << "Ошибка: нулевой диагональный элемент!" << endl;
            return;
        }
        beta[i] = b[i] / A[i][i];
        for (int j = 0; j < n; j++) {
            if (i == j) {
                alpha[i][j] = 0.0;
            } else {
                alpha[i][j] = -A[i][j] / A[i][i];
            }
        }
    }
}

// Вычисление нормы матрицы alpha (по строкам)
double alphaNorm(const vector<vector<double>>& alpha) {
    int n = alpha.size();
    double norm = 0.0;
    for (int i = 0; i < n; i++) {
        double rowSum = 0.0;
        for (int j = 0; j < n; j++) {
            rowSum += fabs(alpha[i][j]);
        }
        norm = max(norm, rowSum);
    }
    return norm;
}

SeidelResult seidelMethod(vector<vector<double>> A, vector<double> b,
                           double epsilon, int maxIter = 1000) {
    int n = A.size();
    SeidelResult result;
    result.success = true;
    bool transformed = false;
    
    cout << fixed << setprecision(8);
    
    // Проверяем и при необходимости обеспечиваем сходимость
    if (!hasDiagonalDominance(A)) {
        cout << "Диагональное преобладание не выполняется. " << endl;
        cout << "Выполняется симметризация A^T A x = A^T b..." << endl;
        
        vector<vector<double>> A_sym;
        vector<double> b_sym;
        symmetrizeSystem(A, b, A_sym, b_sym);
        A = A_sym;
        b = b_sym;
        transformed = true;
    }
    
    buildAlphaBeta(A, b, result.alpha, result.beta);
    
    double normAlpha = alphaNorm(result.alpha);
    cout << "Норма матрицы alpha: " << normAlpha << endl;
    
    if (normAlpha >= 1.0) {
        cout << "Внимание: норма alpha >= 1, сходимость не гарантируется!" << endl;
    }
    
    result.x = result.beta;
    
    cout << "Начальное приближение x0:" << endl;
    for (int i = 0; i < n; i++) {
        cout << "x" << i + 1 << " = " << result.x[i] << endl;
    }
    cout << endl;
    
    int iter = 0;
    double error;
    
    do {
        vector<double> x_prev = result.x;
        
        // Одна итерация метода Зейделя: используем уже обновлённые значения
        for (int i = 0; i < n; i++) {
            double sum1 = 0.0;
            double sum2 = 0.0;
            
            for (int j = 0; j < i; j++) {
                sum1 += result.alpha[i][j] * result.x[j];
            }
            for (int j = i + 1; j < n; j++) {
                sum2 += result.alpha[i][j] * x_prev[j];
            }
            
            result.x[i] = result.beta[i] + sum1 + sum2;
        }
        
        // Вычисляем погрешность
        error = 0.0;
        for (int i = 0; i < n; i++) {
            error += (result.x[i] - x_prev[i]) * (result.x[i] - x_prev[i]);
        }
        error = sqrt(error);
        
        iter++;
        
        cout << "Итерация " << iter << ": x = [";
        for (int i = 0; i < n; i++) {
            cout << result.x[i];
            if (i < n - 1) cout << ", ";
        }
        cout << "], погрешность = " << scientific << setprecision(6) << error << endl;
        
        if (iter >= maxIter) {
            cout << "Достигнуто максимальное число итераций!" << endl;
            result.success = false;
            break;
        }
        
    } while (error >= epsilon);
    
    result.iterations = iter;
    result.finalError = error;
    
    cout << endl << "Решение найдено за " << iter << " итераций." << endl;
    if (transformed) {
        cout << "Примечание: система была преобразована к виду A^T A x = A^T b" << endl;
    }
    
    return result;
}

// Вывод результатов метода Зейделя
void printSeidelResults(ofstream& fout, const SeidelResult& result,
                        const vector<vector<double>>& A_orig, 
                        const vector<double>& b_orig) {
    int n = result.x.size();
    
    fout << fixed << setprecision(8);
    fout << "Метод Зейделя" << endl;
    fout << "-------------" << endl << endl;
    
    // Выводим матрицу alpha
    fout << "Матрица alpha:" << endl;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            fout << setw(12) << fixed << setprecision(6) << result.alpha[i][j] << " ";
        }
        fout << endl;
    }
    fout << endl;
    
    // Выводим вектор Beta
    fout << "Вектор Beta:" << endl;
    for (int i = 0; i < n; i++) {
        fout << "Beta" << i + 1 << " = " << fixed << setprecision(8) << result.beta[i] << endl;
    }
    fout << endl;
    
    // Выводим решение
    fout << "Решение x*:" << endl;
    for (int i = 0; i < n; i++) {
        fout << "x" << i + 1 << " = " << result.x[i] << endl;
    }
    fout << endl;
    
    // Выводим невязку
    vector<double> residual = computeResidual(A_orig, b_orig, result.x);
    fout << scientific << setprecision(6);
    fout << "Вектор невязки ε:" << endl;
    for (int i = 0; i < n; i++) {
        fout << "ε" << i + 1 << " = " << residual[i] << endl;
    }
    fout << endl;
    
    fout << "Норма вектора невязки ||ε|| = " << vectorNorm(residual) << endl;
    fout << "Количество итераций: " << result.iterations << endl;
}

int main() {
    SetConsoleCP(CP_UTF8);
    SetConsoleOutputCP(CP_UTF8);
    
    //починить расчет обратной матрицы (в плане погрешности)

    int selectedMethod = 1;
    
    ifstream fin("input.txt");
    ofstream fout("output.txt");
    
    if (!fin.is_open()) {
        cout << "Ошибка: не удалось открыть файл input.txt" << endl;
        return 1;
    }
    
    int m, n;
    fin >> m >> n;
    
    // Чтение матрицы и правой части
    vector<vector<double>> A(n, vector<double>(n, 0.0));
    vector<double> b(n, 0.0);
    
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            fin >> A[i][j];
        }
    }
    for (int i = 0; i < n; i++) {
        fin >> b[i];
    }
    
    cout << "Используемый метод: " << (selectedMethod == 1 ? "Гаусса" : "Зейделя") << endl;
    cout << "Тип задачи: " << m << endl;
    cout << "Размер матрицы: " << n << "x" << n << endl << endl;
    
    if (selectedMethod == 1) {
        if (m == 1) {
            GaussResult result = gaussForwardElimination(A, b);
            
            if (result.success) {
                vector<double> x = gaussBackSubstitution(result.A_steps.back(), 
                                                          result.b_steps.back());
                vector<double> residual = computeResidual(A, b, x);
                
                gaussPrintIntermediate(fout, result);
                
                fout << fixed << setprecision(8);
                fout << "Решение x*:" << endl;
                for (int i = 0; i < n; i++) {
                    fout << "x" << i + 1 << " = " << x[i] << endl;
                }
                fout << endl;
                
                fout << scientific << setprecision(6);
                fout << "Вектор невязки eps:" << endl;
                for (int i = 0; i < n; i++) {
                    fout << "eps" << i + 1 << " = " << residual[i] << endl;
                }
                fout << endl;
                
                fout << "Норма вектора невязки ||eps|| = " << vectorNorm(residual) << endl;
            }
            
        } else if (m == 2) {
            GaussResult result = gaussForwardElimination(A, b);
            
            if (result.success) {
                gaussPrintIntermediate(fout, result);
                
                fout << fixed << setprecision(8);
                fout << "Определитель матрицы det(A) = " << result.det << endl;
            }
            
        } else if (m == 3) {
            // Вычисление обратной матрицы
            vector<vector<double>> inv = gaussComputeInverse(A);  // ← передаём только A
            
            fout << fixed << setprecision(8);
            fout << "Обратная матрица X:" << endl;
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    fout << setw(14) << inv[i][j] << " ";
                }
                fout << endl;
            }
            fout << endl;
            
            vector<vector<double>> residual = computeInverseResidual(A, inv);
            
            fout << scientific << setprecision(6);
            fout << "Матрица невязки eps (AX - E):" << endl;
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    fout << setw(14) << residual[i][j] << " ";
                }
                fout << endl;
            }
            fout << endl;
            
            fout << "Норма матрицы невязки ||eps|| = " << matrixNorm(residual) << endl;
        }
        
    } else if (selectedMethod == 2) {
        double epsilon = 0.0001;
        int maxIter = 10000;
        
        SeidelResult result = seidelMethod(A, b, epsilon, maxIter);
        
        if (result.success) {
            printSeidelResults(fout, result, A, b);
        } else {
            fout << "Метод Зейделя не сошёлся за " << maxIter << " итераций" << endl;
        }
    }
    
    fin.close();
    fout.close();
    
    cout << endl << "Результаты сохранены в файл output.txt" << endl;
    
    return 0;
}