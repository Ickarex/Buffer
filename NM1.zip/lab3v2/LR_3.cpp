#include <iostream>
#include <map>
#include <fstream>
#include <vector>
#include <cmath>
#include <iomanip>
#include <algorithm>

using namespace std;

const double EPS = 1e-10;

// Умножение матриц
vector<vector<double>> mulMatrix(const vector<vector<double>>& A, const vector<vector<double>>& B) {
    int n = A.size();
    int m = B[0].size();
    int p = B.size();
    vector<vector<double>> res(n, vector<double>(m, 0.0));
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < m; ++j)
            for (int k = 0; k < p; ++k)
                res[i][j] += A[i][k] * B[k][j];
    return res;
}

// Умножение матрицы на вектор
vector<double> mulMatVec(const vector<vector<double>>& A, const vector<double>& x) {
    int n = A.size();
    vector<double> res(n, 0.0);
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < n; ++j)
            res[i] += A[i][j] * x[j];
    return res;
}

// Единичная матрица
vector<vector<double>> eye(int size) {
    vector<vector<double>> res(size, vector<double>(size, 0.0));
    for (int i = 0; i < size; ++i) res[i][i] = 1.0;
    return res;
}

// Обратная матрица M 
vector<vector<double>> M_inverse(const vector<vector<double>>& A_i, int size, int k) {
    vector<vector<double>> res = eye(size);
    for (int j = 0; j < size; ++j)
        res[k][j] = A_i[k + 1][j];
    return res;
}

// Матрица M
vector<vector<double>> M_matrix(const vector<vector<double>>& A_i, int size, int k) {
    vector<vector<double>> res = eye(size);
    double pivot = A_i[k + 1][k];
    if (fabs(pivot) < EPS) {
        return res;
    }
    for (int j = 0; j < size; ++j) {
        if (j == k)
            res[k][j] = 1.0 / pivot;
        else
            res[k][j] = -A_i[k + 1][j] / pivot;
    }
    return res;
}

// Приведение к матрице Фробениуса
vector<vector<double>> toFrobenius(const vector<vector<double>>& A, int size, vector<vector<double>>& S) {
    vector<vector<double>> A_i = A;
    S = eye(size);

    for (int k = size - 2; k >= 0; --k) {
        if (fabs(A_i[k + 1][k]) < EPS) {
            continue;
        }
        vector<vector<double>> M = M_matrix(A_i, size, k);
        vector<vector<double>> M_inv = M_inverse(A_i, size, k);
        A_i = mulMatrix(M_inv, mulMatrix(A_i, M));
        S = mulMatrix(S, M);
    }
    return A_i;
}

// Получение коэффициентов характеристического полинома
vector<double> getPolynomialCoeffs(const vector<vector<double>>& P) {
    int n = P.size();
    vector<double> coeffs(n + 1, 0.0);
    coeffs[0] = 1.0;  // старший коэффициент
    for (int i = 0; i < n; ++i) {
        coeffs[i + 1] = -P[0][i];
    }
    return coeffs;
}

// Вычисление значения полинома в точке
double polyValue(const vector<double>& coeffs, double x) {
    double result = 0.0;
    int n = coeffs.size();
    for (int i = 0; i < n; ++i) {
        result += coeffs[i] * pow(x, n - 1 - i);
    }
    return result;
}

// Вычисление производной полинома
vector<double> polyDerivative(const vector<double>& coeffs) {
    int n = coeffs.size() - 1;
    if (n <= 0) return vector<double>(1, 0.0);
    vector<double> deriv(n);
    for (int i = 0; i < n; ++i) {
        deriv[i] = coeffs[i] * (n - i);
    }
    return deriv;
}

// Метод Ньютона для поиска корней полинома
double newtonRoot(const vector<double>& coeffs, double x0) {
    vector<double> deriv = polyDerivative(coeffs);
    double x = x0;
    for (int iter = 0; iter < 100; ++iter) {
        double f = polyValue(coeffs, x);
        double f1 = polyValue(deriv, x);
        if (fabs(f1) < EPS) break;
        double x_next = x - f / f1;
        if (fabs(x_next - x) < EPS) {
            x = x_next;
            break;
        }
        x = x_next;
    }
    return x;
}

// Деление полинома на (x - root)
vector<double> polyDivide(const vector<double>& coeffs, double root) {
    int n = coeffs.size();
    if (n <= 1) return vector<double>(1, 0.0);
    vector<double> result(n - 1, 0.0);
    result[0] = coeffs[0];
    for (int i = 1; i < n - 1; ++i) {
        result[i] = coeffs[i] + result[i - 1] * root;
    }
    return result;
}

// Поиск всех действительных корней полинома
vector<double> findAllRoots(vector<double> coeffs) {
    vector<double> roots;
    int n = coeffs.size() - 1;

    if (fabs(coeffs[0]) < EPS) return roots;

    int originalDegree = n;

    for (int i = 0; i < originalDegree; ++i) {
        if (coeffs.size() <= 1) break;

        double x0 = 0.0;
        if (!roots.empty()) x0 = roots.back() + 1.0;
        else x0 = 1.0;

        double root = newtonRoot(coeffs, x0);

        // Убеждаемся, что это действительно корень
        if (fabs(polyValue(coeffs, root)) < 1e-6) {
            roots.push_back(root);
            coeffs = polyDivide(coeffs, root);
        }
    }

    sort(roots.begin(), roots.end());
    return roots;
}

// Определение кратности корней 
vector<pair<double, int>> getMultiplicity(const vector<double>& roots, const vector<double>& coeffs) {
    vector<pair<double, int>> result;

    for (double root : roots) {
        // Считаем кратность
        int mult = 0;
        vector<double> currentCoeffs = coeffs;

        while (fabs(polyValue(currentCoeffs, root)) < 1e-6) {
            mult++;
            currentCoeffs = polyDerivative(currentCoeffs);
            if (currentCoeffs.empty() || currentCoeffs.size() == 1) break;
        }

        if (mult > 0) {
            // Проверяем, не добавлен ли уже этот корень
            bool found = false;
            for (auto& p : result) {
                if (fabs(p.first - root) < EPS) {
                    p.second = mult;  // обновляем кратность
                    found = true;
                    break;
                }
            }
            if (!found) {
                result.push_back({ root, mult });
            }
        }
    }

    // Сортируем по значению
    sort(result.begin(), result.end(),
        [](const pair<double, int>& a, const pair<double, int>& b) {
            return a.first < b.first;
        });

    return result;
}

// Построение собственного вектора
vector<double> buildEigenvector(const vector<vector<double>>& S, double lambda) {
    int n = S.size();
    vector<double> y(n);
    y[n - 1] = 1.0;
    for (int i = n - 2; i >= 0; --i) {
        y[i] = lambda * y[i + 1];
    }

    vector<double> x = mulMatVec(S, y);

    // Нормировка
    double norm = 0.0;
    for (double v : x) norm += v * v;
    norm = sqrt(norm);
    if (norm > EPS) {
        for (double& v : x) v /= norm;
    }

    return x;
}

// Вычисление определителя через LU-разложение
double determinant(const vector<vector<double>>& A) {
    int n = A.size();
    if (n == 1) return A[0][0];
    if (n == 2) return A[0][0] * A[1][1] - A[0][1] * A[1][0];

    vector<vector<double>> B = A;
    double det = 1.0;

    for (int i = 0; i < n; ++i) {
        // Поиск ведущего элемента
        if (fabs(B[i][i]) < EPS) {
            int pivot = -1;
            for (int j = i + 1; j < n; ++j) {
                if (fabs(B[j][i]) > EPS) {
                    pivot = j;
                    break;
                }
            }
            if (pivot == -1) return 0.0;
            swap(B[i], B[pivot]);
            det = -det;
        }

        det *= B[i][i];
        for (int j = i + 1; j < n; ++j) {
            double factor = B[j][i] / B[i][i];
            for (int k = i; k < n; ++k) {
                B[j][k] -= factor * B[i][k];
            }
        }
    }
    return det;
}

// Проверка собственной пары (λ, x)
void checkEigenpair(const vector<vector<double>>& A, double lambda, const vector<double>& x, ofstream& out) {
    int n = A.size();
    vector<double> Ax = mulMatVec(A, x);
    double error = 0.0;
    for (int i = 0; i < n; ++i) {
        error += fabs(Ax[i] - lambda * x[i]);
    }
    error /= n;
    out << "    |Ax - λx| = " << scientific << setprecision(6) << error << endl;
}

// Вывод матрицы
void printMatrix(const vector<vector<double>>& M, ofstream& out) {
    int n = M.size();
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            out << setw(12) << fixed << setprecision(6) << M[i][j];
        }
        out << endl;
    }
}

// Вывод вектора
void printVector(const vector<double>& v, ofstream& out) {
    out << "(";
    for (int i = 0; i < (int)v.size(); ++i) {
        out << fixed << setprecision(6) << v[i];
        if (i < (int)v.size() - 1) out << ", ";
    }
    out << ")";
}

int main() {
    ifstream infile("input.txt");
    ofstream outfile("output.txt");

    if (!infile.is_open()) {
        outfile << "Error: Cannot open input file" << endl;
        return 1;
    }

    int m, n;
    infile >> m >> n;

    vector<vector<double>> A(n, vector<double>(n));
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            infile >> A[i][j];
        }
    }
    infile.close();

    vector<vector<double>> S;
    vector<vector<double>> P = toFrobenius(A, n, S);
    vector<double> coeffs = getPolynomialCoeffs(P);
    vector<double> roots = findAllRoots(coeffs);

    // Округляем корни до 8 знаков после запятой
    const double ROUND_PREC = 1e-8;
    vector<double> roundedRoots;
    for (double r : roots) {
        roundedRoots.push_back(round(r / ROUND_PREC) * ROUND_PREC);
    }

    // Удаляем дубликаты
    sort(roundedRoots.begin(), roundedRoots.end());
    roundedRoots.erase(unique(roundedRoots.begin(), roundedRoots.end(),
        [](double a, double b) { return fabs(a - b) < EPS; }), roundedRoots.end());

    vector<pair<double, int>> rootsWithMultiplicity = getMultiplicity(roundedRoots, coeffs);

    outfile << fixed << setprecision(6);
    outfile << "Frobenius matrix:\n";
    printMatrix(P, outfile);
    outfile << endl;

    if (m == 1) {
        outfile << "Eigenvalues:\n";
        for (const auto& p : rootsWithMultiplicity) {
            outfile << "λ = " << fixed << setprecision(6) << p.first
                << ", multiplicity = " << p.second << endl;
        }

        outfile << "\nVerification:\n";
        for (const auto& p : rootsWithMultiplicity) {
            outfile << "λ = " << fixed << setprecision(6) << p.first << ":\n";
            double charPoly = polyValue(coeffs, p.first);
            outfile << "    P(λ) = " << scientific << setprecision(6) << charPoly << endl;

            vector<vector<double>> A_minus_lambdaI = A;
            for (int i = 0; i < n; ++i) {
                A_minus_lambdaI[i][i] -= p.first;
            }
            double detA = determinant(A_minus_lambdaI);
            outfile << "    det(A - λI) = " << scientific << setprecision(6) << detA << endl;
            outfile << endl;
        }
    }
    else if (m == 2) {
        outfile << "Eigenvalues and eigenvectors:\n";
        for (const auto& p : rootsWithMultiplicity) {
            outfile << "λ = " << fixed << setprecision(6) << p.first
                << ", multiplicity = " << p.second << endl;

            vector<double> x = buildEigenvector(S, p.first);
            outfile << "Eigenvector: ";
            printVector(x, outfile);
            outfile << endl;

            checkEigenpair(A, p.first, x, outfile);
            outfile << endl;
        }
    }

    outfile.close();
    return 0;
}