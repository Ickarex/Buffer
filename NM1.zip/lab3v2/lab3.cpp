#include <fstream>
#include <iostream>
#include <cmath>
#include <string>
#include <vector>
#include <iomanip>
#include <algorithm>

using namespace std;

const double EPS = 1e-10;

struct Result {
    vector<double> eigenvalues;
    vector<vector<double>> eigenvectors;
    vector<int> multiplicities;
    vector<vector<double>> frobenius;
};

// ============ ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ============

vector<vector<double>> copyMatrix(const vector<vector<double>>& A) {
    int n = A.size();
    vector<vector<double>> B(n, vector<double>(n, 0.0));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            B[i][j] = A[i][j];
        }
    }
    return B;
}

vector<vector<double>> multiplyMatrices(const vector<vector<double>>& A, const vector<vector<double>>& B) {
    int n = A.size();
    int m = B[0].size();
    int p = B.size();
    vector<vector<double>> C(n, vector<double>(m, 0.0));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            for (int k = 0; k < p; k++) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
    return C;
}

vector<double> multiplyMatVec(const vector<vector<double>>& A, const vector<double>& x) {
    int n = A.size();
    vector<double> res(n, 0.0);
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            res[i] += A[i][j] * x[j];
        }
    }
    return res;
}

vector<vector<double>> identityMatrix(int n) {
    vector<vector<double>> I(n, vector<double>(n, 0.0));
    for (int i = 0; i < n; i++) {
        I[i][i] = 1.0;
    }
    return I;
}

void printMatrix(ostream& out, const vector<vector<double>>& mat) {
    out << fixed << setprecision(6);
    for (int i = 0; i < (int)mat.size(); i++) {
        for (int j = 0; j < (int)mat[i].size(); j++) {
            out << mat[i][j];
            if (j < (int)mat[i].size() - 1) out << " ";
        }
        out << endl;
    }
}

void printVector(ostream& out, const vector<double>& vec) {
    out << fixed << setprecision(6);
    for (int i = 0; i < (int)vec.size(); i++) {
        out << vec[i];
        if (i < (int)vec.size() - 1) out << " ";
    }
    out << endl;
}

// ============ МЕТОД ГАУССА ============

double determinantGauss(vector<vector<double>> A) {
    int n = A.size();
    double det = 1.0;
    int sign = 1;
    
    for (int col = 0; col < n; col++) {
        int pivotRow = col;
        for (int row = col; row < n; row++) {
            if (fabs(A[row][col]) > fabs(A[pivotRow][col])) {
                pivotRow = row;
            }
        }
        
        if (fabs(A[pivotRow][col]) < EPS) return 0.0;
        
        if (pivotRow != col) {
            vector<double> tempRow = A[col];
            A[col] = A[pivotRow];
            A[pivotRow] = tempRow;
            sign = -sign;
        }
        
        det *= A[col][col];
        
        for (int row = col + 1; row < n; row++) {
            double factor = A[row][col] / A[col][col];
            for (int j = col; j < n; j++) {
                A[row][j] -= factor * A[col][j];
            }
        }
    }
    
    return det * sign;
}

vector<double> solveGauss(const vector<vector<double>>& A, const vector<double>& b) {
    int n = A.size();
    vector<vector<double>> aug(n, vector<double>(n + 1, 0.0));
    vector<double> x(n, 0.0);
    
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            aug[i][j] = A[i][j];
        }
        aug[i][n] = b[i];
    }
    
    for (int col = 0; col < n; col++) {
        int pivotRow = col;
        for (int row = col; row < n; row++) {
            if (fabs(aug[row][col]) > fabs(aug[pivotRow][col])) {
                pivotRow = row;
            }
        }
        
        if (fabs(aug[pivotRow][col]) < EPS) continue;
        
        vector<double> tempRow = aug[col];
        aug[col] = aug[pivotRow];
        aug[pivotRow] = tempRow;
        
        double pivot = aug[col][col];
        for (int j = col; j <= n; j++) {
            aug[col][j] /= pivot;
        }
        
        for (int row = 0; row < n; row++) {
            if (row != col && fabs(aug[row][col]) > EPS) {
                double factor = aug[row][col];
                for (int j = col; j <= n; j++) {
                    aug[row][j] -= factor * aug[col][j];
                }
            }
        }
    }
    
    for (int i = 0; i < n; i++) {
        x[i] = aug[i][n];
    }
    
    return x;
}

// ============ РАБОТА С ПОЛИНОМАМИ ============

double evalPolynomial(const vector<double>& coeffs, double x) {
    double result = 0.0;
    int n = coeffs.size() - 1;
    for (int i = 0; i < (int)coeffs.size(); i++) {
        result += coeffs[i] * pow(x, n - i);
    }
    return result;
}

vector<double> polyDerivative(const vector<double>& coeffs) {
    int n = coeffs.size() - 1;
    if (n <= 0) return vector<double>(1, 0.0);
    vector<double> deriv(n);
    for (int i = 0; i < n; i++) {
        deriv[i] = coeffs[i] * (n - i);
    }
    return deriv;
}

vector<double> polyDivide(const vector<double>& coeffs, double root) {
    int n = coeffs.size();
    if (n <= 1) return vector<double>(1, 0.0);
    vector<double> result(n - 1, 0.0);
    result[0] = coeffs[0];
    for (int i = 1; i < n - 1; i++) {
        result[i] = coeffs[i] + result[i - 1] * root;
    }
    return result;
}

// ============ МЕТОД НЬЮТОНА ============

double newtonRoot(const vector<double>& coeffs, double x0) {
    vector<double> deriv = polyDerivative(coeffs);
    double x = x0;
    for (int iter = 0; iter < 100; iter++) {
        double f = evalPolynomial(coeffs, x);
        double f1 = evalPolynomial(deriv, x);
        if (fabs(f1) < EPS) break;
        double x_next = x - f / f1;
        if (fabs(x_next - x) < EPS) {
            x = x_next;
            break;
        }
        x = x_next;
    }
    return x;
}

// ============ МЕТОД НЬЮТОНА С ЛОКАЛИЗАЦИЕЙ ============

vector<pair<double, double>> findIntervals(const vector<double>& coeffs) {
    vector<pair<double, double>> intervals;
    double step = 0.1;
    double range = 100.0;
    
    for (double x = -range; x <= range; x += step) {
        double f1 = evalPolynomial(coeffs, x);
        double f2 = evalPolynomial(coeffs, x + step);
        
        if (f1 * f2 < 0) {
            intervals.push_back({x, x + step});
        }
        
        if (fabs(f1) < EPS) {
            intervals.push_back({x, x});
        }
    }
    
    double lastX = range;
    if (fabs(evalPolynomial(coeffs, lastX)) < EPS) {
        intervals.push_back({lastX, lastX});
    }
    
    return intervals;
}

double refineByBisection(const vector<double>& coeffs, double a, double b) {
    if (fabs(a - b) < EPS) return a;
    
    for (int iter = 0; iter < 1000; iter++) {
        double c = (a + b) / 2;
        double fc = evalPolynomial(coeffs, c);
        
        if (fabs(fc) < EPS) return c;
        if (fabs(b - a) < EPS) break;
        
        double fa = evalPolynomial(coeffs, a);
        if (fa * fc < 0) {
            b = c;
        } else {
            a = c;
        }
    }
    return (a + b) / 2;
}

double newtonRootWithBracket(const vector<double>& coeffs, double a, double b) {
    if (fabs(a - b) < EPS) return a;
    
    vector<double> deriv = polyDerivative(coeffs);
    double x = (a + b) / 2;
    
    for (int iter = 0; iter < 100; iter++) {
        double f = evalPolynomial(coeffs, x);
        double f1 = evalPolynomial(deriv, x);
        
        if (fabs(f1) < EPS) {
            return refineByBisection(coeffs, a, b);
        }
        
        double x_next = x - f / f1;
        
        if (x_next < a || x_next > b) {
            return refineByBisection(coeffs, a, b);
        }
        
        if (fabs(x_next - x) < EPS) {
            return x_next;
        }
        
        x = x_next;
    }
    
    return x;
}

// ============ ПОИСК ВСЕХ КОРНЕЙ ============

vector<double> findAllRoots(vector<double> coeffs) {
    vector<double> roots;
    int originalDegree = coeffs.size() - 1;
    int maxIter = originalDegree * 2;
    
    for (int iter = 0; iter < maxIter; iter++) {
        if ((int)coeffs.size() <= 1) break;
        if ((int)roots.size() >= originalDegree) break;
        
        vector<pair<double, double>> intervals = findIntervals(coeffs);
        
        if (intervals.empty()) {
            double range = 100.0;
            for (double start = -range; start <= range; start += 1.0) {
                double root = newtonRoot(coeffs, start);
                if (fabs(evalPolynomial(coeffs, root)) < 1e-6) {
                    roots.push_back(root);
                    coeffs = polyDivide(coeffs, root);
                    break;
                }
            }
            continue;
        }
        
        bool foundRoot = false;
        for (auto interval : intervals) {
            double a = interval.first;
            double b = interval.second;
            
            double root;
            if (fabs(a - b) < EPS) {
                root = a;
            } else {
                root = newtonRootWithBracket(coeffs, a, b);
                if (fabs(evalPolynomial(coeffs, root)) > 1e-6) {
                    root = refineByBisection(coeffs, a, b);
                }
            }
            
            if (fabs(evalPolynomial(coeffs, root)) < 1e-6) {
                roots.push_back(root);
                coeffs = polyDivide(coeffs, root);
                foundRoot = true;
                break;
            }
        }
        
        if (!foundRoot) {
            double range = 100.0;
            for (double start = -range; start <= range; start += 1.0) {
                double root = newtonRoot(coeffs, start);
                if (fabs(evalPolynomial(coeffs, root)) < 1e-6) {
                    roots.push_back(root);
                    coeffs = polyDivide(coeffs, root);
                    break;
                }
            }
        }
    }
    
    sort(roots.begin(), roots.end());
    return roots;
}

// ============ ГРУППИРОВКА КОРНЕЙ ============

vector<pair<double, int>> groupRoots(const vector<double>& roots) {
    vector<pair<double, int>> grouped;
    
    if (roots.empty()) return grouped;
    
    // Сортируем корни
    vector<double> sortedRoots = roots;
    sort(sortedRoots.begin(), sortedRoots.end());
    
    // Группируем одинаковые корни
    for (double root : sortedRoots) {
        bool found = false;
        for (auto& p : grouped) {
            if (fabs(p.first - root) < 1e-7) {
                p.second++;
                found = true;
                break;
            }
        }
        if (!found) {
            grouped.push_back({root, 1});
        }
    }
    
    return grouped;
}

// ============ МЕТОД ДАНИЛЕВСКОГО ============

vector<vector<double>> buildM(const vector<vector<double>>& A, int size, int k) {
    vector<vector<double>> M = identityMatrix(size);
    double pivot = A[k + 1][k];
    
    if (fabs(pivot) < EPS) {
        return M;
    }
    
    for (int j = 0; j < size; j++) {
        if (j == k) {
            M[k][j] = 1.0 / pivot;
        } else {
            M[k][j] = -A[k + 1][j] / pivot;
        }
    }
    
    return M;
}

vector<vector<double>> buildM_inv(const vector<vector<double>>& A, int size, int k) {
    vector<vector<double>> M_inv = identityMatrix(size);
    
    for (int j = 0; j < size; j++) {
        M_inv[k][j] = A[k + 1][j];
    }
    
    return M_inv;
}

vector<vector<double>> toFrobenius(const vector<vector<double>>& A, int size, vector<vector<double>>& S) {
    vector<vector<double>> currentA = A;
    S = identityMatrix(size);
    
    for (int k = size - 2; k >= 0; k--) {
        if (fabs(currentA[k + 1][k]) < EPS) {
            int swapRow = -1;
            for (int i = k; i >= 0; i--) {
                if (fabs(currentA[i + 1][k]) > EPS) {
                    swapRow = i;
                    break;
                }
            }
            if (swapRow != -1) {
                vector<double> tempRow = currentA[k + 1];
                currentA[k + 1] = currentA[swapRow + 1];
                currentA[swapRow + 1] = tempRow;
                
                for (int i = 0; i < size; i++) {
                    double temp = currentA[i][k + 1];
                    currentA[i][k + 1] = currentA[i][swapRow + 1];
                    currentA[i][swapRow + 1] = temp;
                }
            } else {
                continue;
            }
        }
        
        vector<vector<double>> M = buildM(currentA, size, k);
        vector<vector<double>> M_inv = buildM_inv(currentA, size, k);
        
        currentA = multiplyMatrices(M_inv, multiplyMatrices(currentA, M));
        S = multiplyMatrices(S, M);
    }
    
    return currentA;
}

// ============ ПОСТРОЕНИЕ СОБСТВЕННОГО ВЕКТОРА ============

vector<double> buildEigenvector(const vector<vector<double>>& S, double lambda) {
    int n = S.size();
    vector<double> y(n);
    y[n - 1] = 1.0;
    for (int i = n - 2; i >= 0; i--) {
        y[i] = lambda * y[i + 1];
    }
    
    vector<double> x = multiplyMatVec(S, y);
    
    double norm = 0.0;
    for (double v : x) norm += v * v;
    norm = sqrt(norm);
    if (norm > EPS) {
        for (double& v : x) v /= norm;
    }
    
    return x;
}

// ============ ОСНОВНАЯ ФУНКЦИЯ ============

int main() {
    ifstream in("input.txt");
    ofstream out("output.txt");
    
    if (!in.is_open()) {
        cerr << "Ошибка открытия входного файла" << endl;
        return 1;
    }
    if (!out.is_open()) {
        cerr << "Ошибка открытия выходного файла" << endl;
        return 1;
    }
    
    int taskType;
    int n;
    
    in >> taskType;
    in >> n;
    
    vector<vector<double>> A(n, vector<double>(n, 0.0));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            in >> A[i][j];
        }
    }
    
    in.close();
    
    vector<vector<double>> S;
    vector<vector<double>> P = toFrobenius(A, n, S);
    vector<double> coeffs;
    coeffs.push_back(1.0);
    for (int i = 0; i < n; i++) {
        coeffs.push_back(-P[0][i]);
    }
    
    vector<double> roots = findAllRoots(coeffs);
    
    // Группируем корни
    vector<pair<double, int>> groupedRoots = groupRoots(roots);
    
    // ============ ВЫВОД В ФАЙЛ ============
    
    out << "P" << endl;
    printMatrix(out, P);
    
    for (int i = 0; i < (int)groupedRoots.size(); i++) {
        out << "lambda" << i + 1 << endl;
        out << fixed << setprecision(6) << groupedRoots[i].first << endl;
        
        vector<vector<double>> A_minus_lambdaI = copyMatrix(A);
        for (int j = 0; j < n; j++) {
            A_minus_lambdaI[j][j] -= groupedRoots[i].first;
        }
        
        double det = determinantGauss(A_minus_lambdaI);
        if (taskType == 1) {
            out << "|A - lambda" << i + 1 << "E|" << endl;
            out << scientific << setprecision(6) << det << endl;
        }
        out << "k" << i + 1 << ": ";
        out << groupedRoots[i].second << endl;
        
        if (taskType == 2) {
            vector<double> x = buildEigenvector(S, groupedRoots[i].first);
            out << "x" << i + 1 << endl;
            printVector(out, x);
            
            vector<double> Ax = multiplyMatVec(A, x);
            vector<double> lambdaX(n, 0.0);
            for (int j = 0; j < n; j++) {
                lambdaX[j] = groupedRoots[i].first * x[j];
            }
            
            out << "Ax" << i + 1 << " - lambda" << i + 1 << "x" << i + 1 << endl;
            for (int j = 0; j < n; j++) {
                out << scientific << setprecision(6) << (Ax[j] - lambdaX[j]);
                if (j < n - 1) out << " ";
            }
            out << endl;
        }
    }
    
    out.close();
    return 0;
}