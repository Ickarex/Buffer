#include <fstream>
#include <iostream>
#include <cmath>
#include <string>
#include <vector>
#include <iomanip>
#include <algorithm>

using namespace std;

struct Result {
    vector<double> eigenvalues;
    vector<vector<double>> eigenvectors;
    vector<int> multiplicities;
    vector<vector<double>> frobenius;
};

// ============ ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ============

vector<vector<double>> copyMatrix(const vector<vector<double>>& A) {
    int n = A.size();
    vector<vector<double>> B(n, vector<double>(n, 0.0));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            B[i][j] = A[i][j];
        }
    }
    return B;
}

vector<vector<double>> multiplyMatrices(const vector<vector<double>>& A, const vector<vector<double>>& B) {
    int n = A.size();
    vector<vector<double>> C(n, vector<double>(n, 0.0));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            for (int k = 0; k < n; k++) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
    return C;
}

vector<vector<double>> identityMatrix(int n) {
    vector<vector<double>> I(n, vector<double>(n, 0.0));
    for (int i = 0; i < n; i++) {
        I[i][i] = 1.0;
    }
    return I;
}

void printMatrix(ostream& out, const vector<vector<double>>& mat) {
    out << fixed << setprecision(6);
    for (int i = 0; i < (int)mat.size(); i++) {
        for (int j = 0; j < (int)mat[i].size(); j++) {
            out << mat[i][j];
            if (j < (int)mat[i].size() - 1) out << " ";
        }
        out << endl;
    }
}

void printVector(ostream& out, const vector<double>& vec) {
    out << fixed << setprecision(6);
    for (int i = 0; i < (int)vec.size(); i++) {
        out << vec[i];
        if (i < (int)vec.size() - 1) out << " ";
    }
    out << endl;
}

// ============ МЕТОД ГАУССА ============

vector<double> solveGauss(const vector<vector<double>>& A, const vector<double>& b) {
    int n = A.size();
    vector<vector<double>> aug(n, vector<double>(n + 1, 0.0));
    vector<double> x(n, 0.0);
    
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            aug[i][j] = A[i][j];
        }
        aug[i][n] = b[i];
    }
    
    for (int col = 0; col < n; col++) {
        int pivotRow = col;
        for (int row = col; row < n; row++) {
            if (fabs(aug[row][col]) > fabs(aug[pivotRow][col])) {
                pivotRow = row;
            }
        }
        
        if (fabs(aug[pivotRow][col]) < 1e-12) continue;
        
        vector<double> tempRow = aug[col];
        aug[col] = aug[pivotRow];
        aug[pivotRow] = tempRow;
        
        double pivot = aug[col][col];
        for (int j = col; j <= n; j++) {
            aug[col][j] /= pivot;
        }
        
        for (int row = 0; row < n; row++) {
            if (row != col && fabs(aug[row][col]) > 1e-12) {
                double factor = aug[row][col];
                for (int j = col; j <= n; j++) {
                    aug[row][j] -= factor * aug[col][j];
                }
            }
        }
    }
    
    for (int i = 0; i < n; i++) {
        x[i] = aug[i][n];
    }
    
    return x;
}

double determinantGauss(vector<vector<double>> A) {
    int n = A.size();
    double det = 1.0;
    int sign = 1;
    
    for (int col = 0; col < n; col++) {
        int pivotRow = col;
        for (int row = col; row < n; row++) {
            if (fabs(A[row][col]) > fabs(A[pivotRow][col])) {
                pivotRow = row;
            }
        }
        
        if (fabs(A[pivotRow][col]) < 1e-12) return 0.0;
        
        if (pivotRow != col) {
            vector<double> tempRow = A[col];
            A[col] = A[pivotRow];
            A[pivotRow] = tempRow;
            sign = -sign;
        }
        
        det *= A[col][col];
        
        for (int row = col + 1; row < n; row++) {
            double factor = A[row][col] / A[col][col];
            for (int j = col; j < n; j++) {
                A[row][j] -= factor * A[col][j];
            }
        }
    }
    
    return det * sign;
}

// ============ ВЫЧИСЛЕНИЕ КОРНЕЙ ПОЛИНОМА ============

double evalPolynomial(const vector<double>& coeffs, double x) {
    double result = 0;
    int n = coeffs.size() - 1;
    for (int i = 0; i < (int)coeffs.size(); i++) {
        result += coeffs[i] * pow(x, n - i);
    }
    return result;
}

vector<double> findRootsPolynomial(const vector<double>& coeffs, int n) {
    vector<double> roots;
    double step = 0.01;
    double range = 100.0;
    int maxIter = 100;
    
    if (fabs(evalPolynomial(coeffs, 0)) < 1e-10) {
        roots.push_back(0);
    }
    
    for (double x = -range; x <= range; x += step) {
        if (fabs(x) < 1e-10) continue;
        
        double f1 = evalPolynomial(coeffs, x);
        double f2 = evalPolynomial(coeffs, x + step);
        
        if (f1 * f2 < 0) {
            double a = x;
            double b = x + step;
            
            for (int iter = 0; iter < maxIter; iter++) {
                double c = (a + b) / 2;
                double fc = evalPolynomial(coeffs, c);
                
                if (fabs(fc) < 1e-14 || fabs(b - a) < 1e-14) {
                    a = c;
                    b = c;
                    break;
                }
                
                double fa = evalPolynomial(coeffs, a);
                if (fa * fc < 0) {
                    b = c;
                } else {
                    a = c;
                }
            }
            
            double root = (a + b) / 2;
            
            bool duplicate = false;
            for (double r : roots) {
                if (fabs(root - r) < 1e-6) {
                    duplicate = true;
                    break;
                }
            }
            if (!duplicate) {
                roots.push_back(root);
            }
        }
    }
    
    if ((int)roots.size() < n) {
        for (double start = -range; start <= range; start += 0.5) {
            if ((int)roots.size() >= n) break;
            
            double x = start;
            for (int iter = 0; iter < maxIter; iter++) {
                double fx = evalPolynomial(coeffs, x);
                double h = 1e-8;
                double f1x = (evalPolynomial(coeffs, x + h) - evalPolynomial(coeffs, x - h)) / (2 * h);
                
                if (fabs(f1x) < 1e-14) break;
                
                double x_new = x - fx / f1x;
                
                if (fabs(x_new - x) < 1e-12) {
                    x = x_new;
                    break;
                }
                x = x_new;
                
                if (fabs(x) > range * 2) break;
            }
            
            if (fabs(x) <= range && fabs(evalPolynomial(coeffs, x)) < 1e-6) {
                bool duplicate = false;
                for (double r : roots) {
                    if (fabs(x - r) < 1e-6) {
                        duplicate = true;
                        break;
                    }
                }
                if (!duplicate) {
                    roots.push_back(x);
                }
            }
        }
    }
    
    sort(roots.begin(), roots.end());
    return roots;
}

// ============ ПРЯМОЕ ВЫЧИСЛЕНИЕ ХАРАКТЕРИСТИЧЕСКОГО ПОЛИНОМА ============

vector<double> characteristicPolynomial(const vector<vector<double>>& A) {
    int n = A.size();
    vector<double> coeffs(n + 1, 0.0);
    
    // Используем метод интерполяции
    // Вычисляем значения полинома в n+1 точке
    vector<double> x_vals(n + 1);
    vector<double> y_vals(n + 1);
    
    for (int i = 0; i <= n; i++) {
        x_vals[i] = i + 1.0;
        vector<vector<double>> A_minus_xI = copyMatrix(A);
        for (int j = 0; j < n; j++) {
            A_minus_xI[j][j] -= x_vals[i];
        }
        y_vals[i] = determinantGauss(A_minus_xI);
    }
    
    // Интерполяция полинома степени n
    // Коэффициенты: coeffs[0]*x^n + coeffs[1]*x^(n-1) + ... + coeffs[n]
    for (int i = 0; i <= n; i++) {
        double term = y_vals[i];
        for (int j = 0; j <= n; j++) {
            if (i != j) {
                term /= (x_vals[i] - x_vals[j]);
            }
        }
        
        // Добавляем term * ∏(x - x_j)
        vector<double> poly(n + 1, 0.0);
        poly[0] = 1.0;
        
        for (int j = 0; j <= n; j++) {
            if (i == j) continue;
            
            vector<double> new_poly(n + 1, 0.0);
            // Умножаем на (x - x_j)
            for (int k = 0; k < n; k++) {
                new_poly[k] += poly[k] * (-x_vals[j]);
                new_poly[k + 1] += poly[k];
            }
            poly = new_poly;
        }
        
        for (int j = 0; j <= n; j++) {
            coeffs[j] += term * poly[j];
        }
    }
    
    return coeffs;
}

// ============ МАТРИЦА ФРОБЕНИУСА ============

vector<vector<double>> frobeniusMatrix(const vector<double>& coeffs) {
    int n = coeffs.size() - 1;
    vector<vector<double>> P(n, vector<double>(n, 0.0));
    
    for (int i = 0; i < n; i++) {
        P[0][i] = -coeffs[i + 1];
    }
    
    for (int i = 1; i < n; i++) {
        P[i][i - 1] = 1.0;
    }
    
    return P;
}

// ============ ОСНОВНАЯ ФУНКЦИЯ ============

int main() {
    ifstream in("input.txt");
    ofstream out("output.txt");
    
    if (!in.is_open()) {
        cerr << "Ошибка открытия входного файла" << endl;
        return 1;
    }
    if (!out.is_open()) {
        cerr << "Ошибка открытия выходного файла" << endl;
        return 1;
    }
    
    int taskType;
    int n;
    
    in >> taskType;
    in >> n;
    
    vector<vector<double>> A(n, vector<double>(n, 0.0));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            in >> A[i][j];
        }
    }
    
    in.close();
    
    cout << "=== Исходная матрица A ===" << endl;
    printMatrix(cout, A);
    cout << endl;
    
    // Находим характеристический полином
    vector<double> coeffs = characteristicPolynomial(A);
    
    cout << "=== Коэффициенты характеристического полинома ===" << endl;
    cout << "λ^" << n;
    for (int i = 1; i <= n; i++) {
        if (coeffs[i] >= 0) cout << "+";
        cout << coeffs[i];
        if (i < n) cout << "*λ^" << (n - i);
    }
    cout << "=0" << endl << endl;
    
    // Строим матрицу Фробениуса
    vector<vector<double>> P = frobeniusMatrix(coeffs);
    
    cout << "=== Матрица Фробениуса P ===" << endl;
    printMatrix(cout, P);
    cout << endl;
    
    // Находим корни
    vector<double> roots = findRootsPolynomial(coeffs, n);
    
    // Группируем корни
    vector<double> uniqueRoots;
    vector<int> multiplicities;
    double eps = 1e-7;
    
    for (int i = 0; i < (int)roots.size(); i++) {
        bool found = false;
        for (int j = 0; j < (int)uniqueRoots.size(); j++) {
            if (fabs(roots[i] - uniqueRoots[j]) < eps) {
                multiplicities[j]++;
                found = true;
                break;
            }
        }
        if (!found) {
            uniqueRoots.push_back(roots[i]);
            multiplicities.push_back(1);
        }
    }
    
    int sum = 0;
    for (int m : multiplicities) sum += m;
    
    if (sum < n) {
        for (int i = 0; i < (int)uniqueRoots.size(); i++) {
            while (sum < n && multiplicities[i] < n) {
                multiplicities[i]++;
                sum++;
            }
        }
    }
    
    cout << "=== Собственные числа ===" << endl;
    for (int i = 0; i < (int)uniqueRoots.size(); i++) {
        cout << "lambda" << i + 1 << " = " << fixed << setprecision(6) 
             << uniqueRoots[i] << ", кратность = " << multiplicities[i] << endl;
    }
    cout << endl;
    
    // ============ ВЫВОД В ФАЙЛ ============
    
    out << "P" << endl;
    printMatrix(out, P);
    
    for (int i = 0; i < (int)uniqueRoots.size(); i++) {
        out << "lambda" << i + 1 << endl;
        out << fixed << setprecision(6) << uniqueRoots[i] << endl;
        
        vector<vector<double>> A_minus_lambdaI = copyMatrix(A);
        for (int j = 0; j < n; j++) {
            A_minus_lambdaI[j][j] -= uniqueRoots[i];
        }
        
        double det = determinantGauss(A_minus_lambdaI);
        out << "|A - lambda" << i + 1 << "E|" << endl;
        out << scientific << setprecision(6) << det << endl;
        out << "k" << i + 1 << ": ";
        out << multiplicities[i] << endl;
        
        if (taskType == 2) {
            vector<double> x(n, 1.0);
            
            for (int iter = 0; iter < 30; iter++) {
                vector<vector<double>> mat = copyMatrix(A_minus_lambdaI);
                vector<double> b = x;
                
                double shift = 1e-8;
                for (int j = 0; j < n; j++) {
                    mat[j][j] += shift;
                }
                
                vector<double> y = solveGauss(mat, b);
                
                double norm = 0;
                for (int j = 0; j < n; j++) norm += y[j] * y[j];
                norm = sqrt(norm);
                
                if (norm < 1e-30) {
                    for (int j = 0; j < n; j++) x[j] = 1.0 + j * 0.1;
                    continue;
                }
                
                for (int j = 0; j < n; j++) x[j] = y[j] / norm;
            }
            
            if (x[0] < 0) {
                for (int j = 0; j < n; j++) x[j] = -x[j];
            }
            
            out << "x" << i + 1 << endl;
            printVector(out, x);
            
            vector<double> Ax(n, 0.0);
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < n; k++) {
                    Ax[j] += A[j][k] * x[k];
                }
            }
            vector<double> lambdaX(n, 0.0);
            for (int j = 0; j < n; j++) {
                lambdaX[j] = uniqueRoots[i] * x[j];
            }
            
            out << "Ax" << i + 1 << " - lambda" << i + 1 << "x" << i + 1 << endl;
            for (int j = 0; j < n; j++) {
                out << scientific << setprecision(6) << (Ax[j] - lambdaX[j]);
                if (j < n - 1) out << " ";
            }
            out << endl;
        }
    }
    
    out.close();
    return 0;
}