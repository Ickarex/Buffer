#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

#define MAX_ITER 1000
#define EPS 1e-10

// Выделение памяти для матрицы
double** alloc_matrix(int n) {
    double** m = (double**)malloc(n * sizeof(double*));
    for (int i = 0; i < n; i++) {
        m[i] = (double*)calloc(n, sizeof(double));
    }
    return m;
}

// Освобождение памяти матрицы
void free_matrix(double** m, int n) {
    for (int i = 0; i < n; i++) free(m[i]);
    free(m);
}

// Копирование матрицы
void copy_matrix(double** dest, double** src, int n) {
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            dest[i][j] = src[i][j];
}

// Умножение матриц: C = A * B
void mat_mult(double** A, double** B, double** C, int n) {
    double** temp = alloc_matrix(n);
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            temp[i][j] = 0;
            for (int k = 0; k < n; k++)
                temp[i][j] += A[i][k] * B[k][j];
        }
    }
    copy_matrix(C, temp, n);
    free_matrix(temp, n);
}

// След матрицы
double trace(double** A, int n) {
    double tr = 0;
    for (int i = 0; i < n; i++)
        tr += A[i][i];
    return tr;
}

// Преобразование матрицы к форме Фробениуса (верхняя форма Хессенберга)
void frobenius_form(double** A, double** F, int n) {
    double** temp = alloc_matrix(n);
    copy_matrix(temp, A, n);
    
    for (int k = 0; k < n - 2; k++) {
        // Поиск максимального элемента в столбце k ниже поддиагонали
        int max_row = k + 1;
        for (int i = k + 2; i < n; i++) {
            if (fabs(temp[i][k]) > fabs(temp[max_row][k]))
                max_row = i;
        }
        
        if (fabs(temp[max_row][k]) > EPS) {
            // Перестановка строк
            if (max_row != k + 1) {
                for (int j = k; j < n; j++) {
                    double t = temp[k + 1][j];
                    temp[k + 1][j] = temp[max_row][j];
                    temp[max_row][j] = t;
                }
                // Перестановка столбцов
                for (int i = 0; i < n; i++) {
                    double t = temp[i][k + 1];
                    temp[i][k + 1] = temp[i][max_row];
                    temp[i][max_row] = t;
                }
            }
            
            // Приведение к форме Хессенберга
            for (int i = k + 2; i < n; i++) {
                if (fabs(temp[i][k]) > EPS) {
                    double factor = temp[i][k] / temp[k + 1][k];
                    for (int j = k; j < n; j++) {
                        temp[i][j] -= factor * temp[k + 1][j];
                    }
                    for (int j = 0; j < n; j++) {
                        temp[j][k + 1] += factor * temp[j][i];
                    }
                }
            }
        }
    }
    
    copy_matrix(F, temp, n);
    free_matrix(temp, n);
}

// МЕТОД Леверье для нахождения коэффициентов характеристического полинома
void leverrier_method(double** A, int n, double* coeffs) {
    double** power = alloc_matrix(n);
    copy_matrix(power, A, n);
    
    double* s = (double*)malloc((n + 1) * sizeof(double));  // Следы степеней матрицы
    
    // Вычисление следов степеней матрицы
    for (int k = 1; k <= n; k++) {
        s[k] = trace(power, n);
        
        // Вычисление следующей степени
        if (k < n) {
            double** temp = alloc_matrix(n);
            mat_mult(power, A, temp, n);
            copy_matrix(power, temp, n);
            free_matrix(temp, n);
        }
    }
    
    // Формулы Ньютона для коэффициентов характеристического полинома
    coeffs[0] = 1.0;  // коэффициент при λ^n
    
    for (int k = 1; k <= n; k++) {
        coeffs[k] = 0;
        for (int i = 1; i <= k; i++) {
            coeffs[k] -= s[i] * coeffs[k - i];
        }
        coeffs[k] /= k;
    }
    
    // Переворачиваем коэффициенты (чтобы coeffs[0] был свободным членом)
    for (int i = 0; i <= n / 2; i++) {
        double t = coeffs[i];
        coeffs[i] = coeffs[n - i];
        coeffs[n - i] = t;
    }
    
    free(s);
    free_matrix(power, n);
}

// Вычисление значения полинома в точке
double poly_val(double* coeffs, int n, double x) {
    double res = coeffs[0];  // свободный член
    double x_pow = x;
    for (int i = 1; i <= n; i++) {
        res += coeffs[i] * x_pow;
        x_pow *= x;
    }
    return res;
}

// Вычисление производной полинома
void poly_deriv(double* coeffs, int n, double* deriv) {
    for (int i = 1; i <= n; i++) {
        deriv[i - 1] = i * coeffs[i];
    }
}

// Метод Ньютона для поиска корня полинома
double find_root(double* coeffs, int n, double x0, double eps) {
    double* deriv = (double*)malloc(n * sizeof(double));
    poly_deriv(coeffs, n, deriv);
    
    double x = x0;
    double dx;
    int iter = 0;
    
    do {
        double f_val = poly_val(coeffs, n, x);
        double f_der = 0;
        double x_pow = 1;
        for (int i = 1; i <= n; i++) {
            f_der += i * coeffs[i] * x_pow;
            x_pow *= x;
        }
        
        if (fabs(f_der) < 1e-12) {
            x += eps;
            continue;
        }
        
        dx = f_val / f_der;
        x -= dx;
        iter++;
    } while (fabs(dx) > eps && iter < MAX_ITER);
    
    free(deriv);
    return x;
}

// Деление полинома на (x - root)
void poly_div(double* coeffs, int n, double root, double* result) {
    result[n] = coeffs[n];
    for (int i = n - 1; i >= 0; i--) {
        result[i] = coeffs[i] + root * result[i + 1];
    }
}

// Вычисление ранга матрицы (A - λE)
int matrix_rank(double** A, int n, double lambda) {
    double** M = alloc_matrix(n);
    
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            M[i][j] = A[i][j];
            if (i == j) M[i][j] -= lambda;
        }
    }
    
    int rank = 0;
    for (int i = 0; i < n; i++) {
        int max_row = -1;
        for (int k = rank; k < n; k++) {
            if (fabs(M[k][i]) > EPS) {
                max_row = k;
                break;
            }
        }
        
        if (max_row == -1) continue;
        
        if (max_row != rank) {
            for (int j = i; j < n; j++) {
                double t = M[rank][j];
                M[rank][j] = M[max_row][j];
                M[max_row][j] = t;
            }
        }
        
        double pivot = M[rank][i];
        for (int j = i; j < n; j++) {
            M[rank][j] /= pivot;
        }
        
        for (int k = rank + 1; k < n; k++) {
            double factor = M[k][i];
            if (fabs(factor) < EPS) continue;
            for (int j = i; j < n; j++) {
                M[k][j] -= factor * M[rank][j];
            }
        }
        
        rank++;
    }
    
    free_matrix(M, n);
    return rank;
}

// Вычисление геометрической кратности
int geometric_multiplicity(double** A, int n, double lambda) {
    int rank = matrix_rank(A, n, lambda);
    return n - rank;
}

// Поиск всех собственных чисел с кратностями
void find_eigenvalues(double* coeffs, int n, double* vals, int* alg_mult, int* geom_mult, double** A, double eps) {
    double* curr = (double*)malloc((n + 1) * sizeof(double));
    for (int i = 0; i <= n; i++) curr[i] = coeffs[i];
    
    int curr_n = n;
    int idx = 0;
    
    while (curr_n > 0 && idx < n) {
        // Поиск корня
        double root = find_root(curr, curr_n, 0.0, eps);
        
        // Определение алгебраической кратности
        int alg_mult_count = 0;
        double* temp = (double*)malloc((curr_n + 1) * sizeof(double));
        
        while (curr_n > 0 && fabs(poly_val(curr, curr_n, root)) < eps) {
            alg_mult_count++;
            poly_div(curr, curr_n, root, temp);
            curr_n--;
            for (int i = 0; i <= curr_n; i++)
                curr[i] = temp[i];
        }
        
        if (alg_mult_count == 0) {
            alg_mult_count = 1;
            poly_div(curr, curr_n, root, temp);
            curr_n--;
            for (int i = 0; i <= curr_n; i++)
                curr[i] = temp[i];
        }
        
        vals[idx] = root;
        alg_mult[idx] = alg_mult_count;
        geom_mult[idx] = geometric_multiplicity(A, n, root);
        
        idx++;
        free(temp);
    }
    
    free(curr);
}

// Проверка собственных чисел
double check_eigenvalue(double** A, int n, double lambda) {
    double** M = alloc_matrix(n);
    double det = 1.0;
    
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            M[i][j] = A[i][j];
            if (i == j) M[i][j] -= lambda;
        }
    }
    
    for (int i = 0; i < n; i++) {
        int max_row = i;
        for (int k = i + 1; k < n; k++) {
            if (fabs(M[k][i]) > fabs(M[max_row][i]))
                max_row = k;
        }
        
        if (max_row != i) {
            for (int j = i; j < n; j++) {
                double t = M[i][j];
                M[i][j] = M[max_row][j];
                M[max_row][j] = t;
            }
            det *= -1;
        }
        
        if (fabs(M[i][i]) < 1e-12) {
            det = 0;
            break;
        }
        
        det *= M[i][i];
        
        for (int k = i + 1; k < n; k++) {
            double factor = M[k][i] / M[i][i];
            for (int j = i; j < n; j++)
                M[k][j] -= factor * M[i][j];
        }
    }
    
    free_matrix(M, n);
    return det;
}

// Вычисление собственного вектора (методом Гаусса)
int find_eigenvector(double** A, int n, double lambda, double* vec) {
    double** M = alloc_matrix(n);
    
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            M[i][j] = A[i][j];
            if (i == j) M[i][j] -= lambda;
        }
    }
    
    // Приведение к верхнетреугольному виду
    for (int i = 0; i < n; i++) {
        // Поиск ненулевого элемента
        int max_row = i;
        for (int k = i; k < n; k++) {
            if (fabs(M[k][i]) > fabs(M[max_row][i]))
                max_row = k;
        }
        
        if (fabs(M[max_row][i]) < EPS) continue;
        
        // Перестановка строк
        if (max_row != i) {
            for (int j = i; j < n; j++) {
                double t = M[i][j];
                M[i][j] = M[max_row][j];
                M[max_row][j] = t;
            }
        }
        
        // Нормализация строки
        double pivot = M[i][i];
        for (int j = i; j < n; j++) {
            M[i][j] /= pivot;
        }
        
        // Вычитание из остальных строк
        for (int k = 0; k < n; k++) {
            if (k != i && fabs(M[k][i]) > EPS) {
                double factor = M[k][i];
                for (int j = i; j < n; j++) {
                    M[k][j] -= factor * M[i][j];
                }
            }
        }
    }
    
    // Поиск свободной переменной (столбца с нулевым ведущим элементом)
    int free_var = -1;
    for (int j = 0; j < n; j++) {
        int has_pivot = 0;
        for (int i = 0; i < n; i++) {
            if (fabs(M[i][j]) > EPS) {
                has_pivot = 1;
                break;
            }
        }
        if (!has_pivot) {
            free_var = j;
            break;
        }
    }
    
    if (free_var == -1) {
        free_matrix(M, n);
        return 0; // Только нулевое решение
    }
    
    // Находим решение
    for (int i = 0; i < n; i++) vec[i] = 0;
    vec[free_var] = 1.0;
    
    // Обратный ход
    for (int i = n - 1; i >= 0; i--) {
        int pivot_col = -1;
        for (int j = 0; j < n; j++) {
            if (fabs(M[i][j]) > EPS && j != free_var) {
                pivot_col = j;
                break;
            }
        }
        if (pivot_col != -1) {
            double sum = 0;
            for (int j = pivot_col + 1; j < n; j++) {
                sum += M[i][j] * vec[j];
            }
            vec[pivot_col] = -sum / M[i][pivot_col];
        }
    }
    
    // Нормировка
    double norm = 0;
    for (int i = 0; i < n; i++) norm += vec[i] * vec[i];
    norm = sqrt(norm);
    if (norm > EPS) {
        for (int i = 0; i < n; i++) vec[i] /= norm;
    }
    
    free_matrix(M, n);
    return 1;
}

// Проверка собственного вектора
double check_eigenvector(double** A, int n, double lambda, double* vec) {
    double* res = (double*)calloc(n, sizeof(double));
    double norm = 0;
    
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++)
            res[i] += A[i][j] * vec[j];
        res[i] -= lambda * vec[i];
        norm += res[i] * res[i];
    }
    
    free(res);
    return sqrt(norm);
}

// Проверка линейной независимости векторов
int are_vectors_independent(double** vectors, int num_vecs, int n, double* new_vec) {
    if (num_vecs == 0) return 1;
    
    // Формируем матрицу из существующих векторов и нового
    double** M = alloc_matrix(n);
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < num_vecs; j++) {
            M[i][j] = vectors[j][i];
        }
        M[i][num_vecs] = new_vec[i];
    }
    
    // Проверка ранга
    int rank = 0;
    for (int col = 0; col <= num_vecs; col++) {
        int max_row = -1;
        for (int row = rank; row < n; row++) {
            if (fabs(M[row][col]) > EPS) {
                max_row = row;
                break;
            }
        }
        if (max_row == -1) {
            free_matrix(M, n);
            return 0; // Линейно зависим
        }
        
        if (max_row != rank) {
            for (int j = col; j <= num_vecs; j++) {
                double t = M[rank][j];
                M[rank][j] = M[max_row][j];
                M[max_row][j] = t;
            }
        }
        
        for (int row = rank + 1; row < n; row++) {
            double factor = M[row][col] / M[rank][col];
            for (int j = col; j <= num_vecs; j++) {
                M[row][j] -= factor * M[rank][j];
            }
        }
        rank++;
    }
    
    free_matrix(M, n);
    return 1; // Линейно независим
}

int main() {
    FILE* fin = fopen("input.txt", "r");
    FILE* fout = fopen("output.txt", "w");
    
    if (!fin || !fout) {
        printf("Ошибка открытия файлов\n");
        return 1;
    }
    
    int task_type, n;
    fscanf(fin, "%d", &task_type);
    fscanf(fin, "%d", &n);
    
    double** A = alloc_matrix(n);
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            fscanf(fin, "%lf", &A[i][j]);
    fclose(fin);
    
    // Преобразование к форме Фробениуса
    double** F = alloc_matrix(n);
    frobenius_form(A, F, n);
    
    // Вывод матрицы Фробениуса
    fprintf(fout, "Матрица Фробениуса (приведенная форма):\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++)
            fprintf(fout, "%12.6lf ", F[i][j]);
        fprintf(fout, "\n");
    }
    fprintf(fout, "\n");
    
    // Метод Леверье для характеристического полинома (используем исходную матрицу)
    double* coeffs = (double*)malloc((n + 1) * sizeof(double));
    leverrier_method(A, n, coeffs);
    
    fprintf(fout, "Характеристический полином:\n");
    fprintf(fout, "P(λ) = λ^%d", n);
    for (int i = n - 1; i >= 0; i--) {
        if (coeffs[i] >= 0)
            fprintf(fout, " + %.6lf λ^%d", coeffs[i], i);
        else
            fprintf(fout, " - %.6lf λ^%d", -coeffs[i], i);
    }
    fprintf(fout, " = 0\n\n");
    
    double* eigenvalues = (double*)malloc(n * sizeof(double));
    int* alg_multiplicity = (int*)calloc(n, sizeof(int));
    int* geom_multiplicity = (int*)calloc(n, sizeof(int));
    
    find_eigenvalues(coeffs, n, eigenvalues, alg_multiplicity, geom_multiplicity, A, EPS);
    
    // Вывод собственных чисел и их кратностей
    fprintf(fout, "СОБСТВЕННЫЕ ЧИСЛА И ИХ КРАТНОСТИ:\n");
    for (int i = 0; i < n; i++) {
        if (alg_multiplicity[i] > 0) {
            fprintf(fout, "\nλ = %.10lf\n", eigenvalues[i]);
            fprintf(fout, "Алгебраическая кратность: %d\n", alg_multiplicity[i]);
            fprintf(fout, "Геометрическая кратность: %d\n", geom_multiplicity[i]);
            
            double det = check_eigenvalue(A, n, eigenvalues[i]);
            fprintf(fout, "|A - λE| = %.10e\n", det);
        }
    }
    
    // Вывод общего вывода о диагонализируемости матрицы
    int is_diagonalizable = 1;
    for (int i = 0; i < n; i++) {
        if (alg_multiplicity[i] > 0 && geom_multiplicity[i] != alg_multiplicity[i]) {
            is_diagonalizable = 0;
            break;
        }
    }
    
    
    // Вычисление и вывод собственных векторов
    if (task_type == 2) {
        fprintf(fout, "\nСОБСТВЕННЫЕ ВЕКТОРЫ:\n");
        
        for (int i = 0; i < n; i++) {
            if (alg_multiplicity[i] > 0) {
                fprintf(fout, "Собственное число λ = %.10lf\n", eigenvalues[i]);
                fprintf(fout, "Алгебраическая кратность: %d\n", alg_multiplicity[i]);
                fprintf(fout, "Геометрическая кратность: %d\n", geom_multiplicity[i]);
                
                if (geom_multiplicity[i] > 0) {
                    double** eigenvectors = (double**)malloc(geom_multiplicity[i] * sizeof(double*));
                    for (int k = 0; k < geom_multiplicity[i]; k++) {
                        eigenvectors[k] = (double*)malloc(n * sizeof(double));
                    }
                    
                    int found_vectors = 0;
                    int max_attempts = 500;
                    
                    for (int attempt = 0; attempt < max_attempts && found_vectors < geom_multiplicity[i]; attempt++) {
                        double* vec = (double*)malloc(n * sizeof(double));
                        
                        if (find_eigenvector(A, n, eigenvalues[i], vec)) {
                            // Проверка на нулевой вектор
                            double norm = 0;
                            for (int j = 0; j < n; j++) norm += vec[j] * vec[j];
                            if (norm < EPS) {
                                free(vec);
                                continue;
                            }
                            
                            // Проверка линейной независимости
                            if (are_vectors_independent(eigenvectors, found_vectors, n, vec)) {
                                for (int j = 0; j < n; j++)
                                    eigenvectors[found_vectors][j] = vec[j];
                                
                                fprintf(fout, "\nСобственный вектор %d:\n", found_vectors + 1);
                                fprintf(fout, "v = [");
                                for (int j = 0; j < n; j++) {
                                    fprintf(fout, "%10.6lf", eigenvectors[found_vectors][j]);
                                    if (j < n - 1) fprintf(fout, ", ");
                                }
                                fprintf(fout, "]^T\n");
                                
                                double err = check_eigenvector(A, n, eigenvalues[i], eigenvectors[found_vectors]);
                                fprintf(fout, "Невязка: ||A v - λ v|| = %.2e\n", err);
                                
                                found_vectors++;
                            }
                        }
                        free(vec);
                    }
                    
                    if (found_vectors < geom_multiplicity[i]) {
                        fprintf(fout, "\nПредупреждение: найдено только %d из %d линейно независимых собственных векторов\n",
                                found_vectors, geom_multiplicity[i]);
                    } else {
                        fprintf(fout, "\nУспешно найдено %d линейно независимых собственных векторов\n", found_vectors);
                    }
                    
                    for (int k = 0; k < geom_multiplicity[i]; k++)
                        free(eigenvectors[k]);
                    free(eigenvectors);
                }
            }
        }
        
    }
    
    free_matrix(A, n);
    free_matrix(F, n);
    free(coeffs);
    free(eigenvalues);
    free(alg_multiplicity);
    free(geom_multiplicity);
    
    fclose(fout);
    
    return 0;
}