#include <fstream>
#include <iostream>
#include <math.h>
#include "PolStr.h"
#include <string>
#include <windows.h>

using namespace std;

// Структура для хранения результата решения СНУ
struct Result {
    double* x;          // Вектор решения
    double* fx;         // Вектор невязки
    double norm;        // Норма вектора невязки
    int iterations;     // Количество итераций
};

// Функция для вычисления нормы вектора
double vectorNorm(double* vec, int n) {
    double sum = 0.0;
    for (int i = 0; i < n; i++) {
        sum += vec[i] * vec[i];
    }
    return sqrt(sum);
}

// Функция для вычисления значения системы функций в точке x
void evalSystem(char** functions, int n, double* x, double* result) {
    for (int i = 0; i < n; i++) {
        char* polstr = CreatePolStr(functions[i], n);
        result[i] = EvalPolStr(polstr, x, 0, 0);
        delete[] polstr;
    }
}

// Функция для вычисления якобиана системы в точке x
void evalJacobian(char** functions, int n, double* x, double** J) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            char* polstr = CreatePolStr(functions[i], n);
            // ВАЖНО: arg_idx = j + 1 (1-based)
            J[i][j] = EvalPolStr(polstr, x, 1, j + 1);
            delete[] polstr;
        }
    }
}

// Решение СЛАУ методом Гаусса
bool solveLinearSystem(double** A, double* b, int n, double* x) {
    double** a = new double*[n];
    for (int i = 0; i < n; i++) {
        a[i] = new double[n];
        for (int j = 0; j < n; j++) {
            a[i][j] = A[i][j];
        }
    }
    double* bb = new double[n];
    for (int i = 0; i < n; i++) {
        bb[i] = b[i];
    }

    for (int k = 0; k < n; k++) {
        int maxRow = k;
        for (int i = k + 1; i < n; i++) {
            if (fabs(a[i][k]) > fabs(a[maxRow][k])) {
                maxRow = i;
            }
        }
        if (fabs(a[maxRow][k]) < 1e-12) {
            for (int i = 0; i < n; i++) {
                delete[] a[i];
            }
            delete[] a;
            delete[] bb;
            return false;
        }
        if (maxRow != k) {
            for (int j = 0; j < n; j++) {
                double temp = a[k][j];
                a[k][j] = a[maxRow][j];
                a[maxRow][j] = temp;
            }
            double temp = bb[k];
            bb[k] = bb[maxRow];
            bb[maxRow] = temp;
        }
        for (int i = k + 1; i < n; i++) {
            double factor = a[i][k] / a[k][k];
            for (int j = k; j < n; j++) {
                a[i][j] -= factor * a[k][j];
            }
            bb[i] -= factor * bb[k];
        }
    }

    for (int i = n - 1; i >= 0; i--) {
        x[i] = bb[i];
        for (int j = i + 1; j < n; j++) {
            x[i] -= a[i][j] * x[j];
        }
        x[i] /= a[i][i];
    }

    for (int i = 0; i < n; i++) {
        delete[] a[i];
    }
    delete[] a;
    delete[] bb;
    return true;
}

// Метод Ньютона
Result newtonMethod(char** functions, int n, double* x0, double prec) {
    Result res;
    res.x = new double[n];
    res.fx = new double[n];
    res.iterations = 0;

    double* x = new double[n];
    double* x_next = new double[n];
    double* f = new double[n];
    double** J = new double*[n];
    for (int i = 0; i < n; i++) {
        J[i] = new double[n];
    }

    for (int i = 0; i < n; i++) {
        x[i] = x0[i];
    }

    do {
        evalSystem(functions, n, x, f);
        evalJacobian(functions, n, x, J);
        
        double* b = new double[n];
        for (int i = 0; i < n; i++) {
            b[i] = -f[i];
        }
        
        double* dx = new double[n];
        if (!solveLinearSystem(J, b, n, dx)) {
            for (int i = 0; i < n; i++) {
                dx[i] = 0.001;
            }
        }
        
        for (int i = 0; i < n; i++) {
            x_next[i] = x[i] + dx[i];
        }
        
        delete[] b;
        delete[] dx;
        
        res.iterations++;
        
        double diff = 0.0;
        for (int i = 0; i < n; i++) {
            diff += (x_next[i] - x[i]) * (x_next[i] - x[i]);
        }
        diff = sqrt(diff);
        
        for (int i = 0; i < n; i++) {
            x[i] = x_next[i];
        }
        
        if (diff < prec) break;
        
    } while (res.iterations < 1000);

    for (int i = 0; i < n; i++) {
        res.x[i] = x[i];
    }
    evalSystem(functions, n, x, res.fx);
    res.norm = vectorNorm(res.fx, n);

    for (int i = 0; i < n; i++) {
        delete[] J[i];
    }
    delete[] J;
    delete[] x;
    delete[] x_next;
    delete[] f;

    return res;
}

// Метод итераций
Result iterationMethod(char** functions, int n, double* x0, double prec) {
    Result res;
    res.x = new double[n];
    res.fx = new double[n];
    res.iterations = 0;

    double* x = new double[n];
    double* x_next = new double[n];
    double* f = new double[n];

    for (int i = 0; i < n; i++) {
        x[i] = x0[i];
    }

    double** J0 = new double*[n];
    for (int i = 0; i < n; i++) {
        J0[i] = new double[n];
    }
    evalJacobian(functions, n, x0, J0);

    double** invJ = new double*[n];
    for (int i = 0; i < n; i++) {
        invJ[i] = new double[n];
    }
    
    for (int col = 0; col < n; col++) {
        double* e = new double[n];
        for (int i = 0; i < n; i++) {
            e[i] = (i == col) ? 1.0 : 0.0;
        }
        double* colInv = new double[n];
        if (!solveLinearSystem(J0, e, n, colInv)) {
            for (int i = 0; i < n; i++) {
                invJ[i][col] = (i == col) ? 1.0 : 0.0;
            }
        } else {
            for (int i = 0; i < n; i++) {
                invJ[i][col] = colInv[i];
            }
        }
        delete[] e;
        delete[] colInv;
    }

    do {
        evalSystem(functions, n, x, f);
        
        for (int i = 0; i < n; i++) {
            double sum = 0.0;
            for (int j = 0; j < n; j++) {
                sum += invJ[i][j] * f[j];
            }
            x_next[i] = x[i] - sum;
        }
        
        res.iterations++;
        
        double diff = 0.0;
        for (int i = 0; i < n; i++) {
            diff += (x_next[i] - x[i]) * (x_next[i] - x[i]);
        }
        diff = sqrt(diff);
        
        for (int i = 0; i < n; i++) {
            x[i] = x_next[i];
        }
        
        if (diff < prec) break;
        
    } while (res.iterations < 1000);

    for (int i = 0; i < n; i++) {
        res.x[i] = x[i];
    }
    evalSystem(functions, n, x, res.fx);
    res.norm = vectorNorm(res.fx, n);

    for (int i = 0; i < n; i++) {
        delete[] J0[i];
        delete[] invJ[i];
    }
    delete[] J0;
    delete[] invJ;
    delete[] x;
    delete[] x_next;
    delete[] f;

    return res;
}

// Метод наискорейшего спуска
Result steepestDescentMethod(char** functions, int n, double* x0, double prec) {
    Result res;
    res.x = new double[n];
    res.fx = new double[n];
    res.iterations = 0;

    double* x = new double[n];
    double* x_next = new double[n];
    double* f = new double[n];
    double* grad = new double[n];
    double** J = new double*[n];
    for (int i = 0; i < n; i++) {
        J[i] = new double[n];
    }

    for (int i = 0; i < n; i++) {
        x[i] = x0[i];
    }

    do {
        // Вычисляем значения функций
        evalSystem(functions, n, x, f);
        
        // Проверяем норму невязки
        double f_norm = vectorNorm(f, n);
        if (f_norm < prec) break;
        
        // Вычисляем якобиан
        evalJacobian(functions, n, x, J);
        
        // Вычисляем градиент: grad = 2 * J^T * f
        for (int i = 0; i < n; i++) {
            grad[i] = 0.0;
            for (int j = 0; j < n; j++) {
                grad[i] += 2.0 * J[j][i] * f[j];  // ← ДОБАВЛЕН МНОЖИТЕЛЬ 2
            }
        }
        
        // линейный поиск шага
        double alpha = 1.0;
        double* x_new = new double[n];
        double* f_new = new double[n];
        
        // Пробуем alpha = 1, 0.5, 0.25, ... пока не уменьшится невязка
        do {
            for (int i = 0; i < n; i++) {
                x_new[i] = x[i] - alpha * grad[i];
            }
            evalSystem(functions, n, x_new, f_new);
            double new_norm = vectorNorm(f_new, n);
            
            // Если невязка уменьшилась - выходим из цикла
            if (new_norm < f_norm) break;
            
            // Иначе уменьшаем шаг
            alpha *= 0.5;
            
        } while (alpha > 1e-12);
        
        // Копируем новую точку
        for (int i = 0; i < n; i++) {
            x_next[i] = x_new[i];
        }
        
        delete[] x_new;
        delete[] f_new;
        
        res.iterations++;
        
        // Проверка на переполнение
        bool overflow = false;
        for (int i = 0; i < n; i++) {
            if (!isfinite(x_next[i])) {
                overflow = true;
                break;
            }
        }
        if (overflow) break;
        
        // Обновляем x
        for (int i = 0; i < n; i++) {
            x[i] = x_next[i];
        }
        
    } while (res.iterations < 1000);

    // Сохраняем результат
    for (int i = 0; i < n; i++) {
        res.x[i] = x[i];
    }
    evalSystem(functions, n, x, res.fx);
    res.norm = vectorNorm(res.fx, n);

    for (int i = 0; i < n; i++) {
        delete[] J[i];
    }
    delete[] J;
    delete[] x;
    delete[] x_next;
    delete[] f;
    delete[] grad;

    return res;
}

int main() {
    SetConsoleCP(CP_UTF8);
    SetConsoleOutputCP(CP_UTF8);

    ifstream in("./input.txt");
    ofstream out("./output.txt");
    
    if (!in.is_open()) {
        cout << "Ошибка открытия входного файла" << endl;
        return 1;
    }
    if (!out.is_open()) {
        cout << "Ошибка открытия выходного файла" << endl;
        return 1;
    }

    int method;
    int n;
    
    in >> method;
    in >> n;
    
    double* x0 = new double[n];
    for (int i = 0; i < n; i++) {
        in >> x0[i];
    }
    
    double prec;
    in >> prec;
    
    char** functions = new char*[n];
    string funcStr;
    getline(in, funcStr);
    for (int i = 0; i < n; i++) {
        getline(in, funcStr);
        functions[i] = new char[funcStr.length() + 1];
        strcpy(functions[i], funcStr.c_str());
    }

    Result result;
    
    switch (method) {
        case 1:
            result = newtonMethod(functions, n, x0, prec);
            break;
        case 2:
            result = iterationMethod(functions, n, x0, prec);
            break;
        case 3:
            result = steepestDescentMethod(functions, n, x0, prec);
            break;
        default:
            out << "Нет метода с таким номером" << endl;
            return 1;
    }


    out << "x0: ";
    for (int i = 0; i < n; i++) {
        out << x0[i] << " ";
    }
    out << endl;
    
    out << "x1: ";
    for (int i = 0; i < n; i++) {
        out << result.x[i] << " ";
    }
    out << endl;
    
    // Вектор невязки в научном формате
    out << "eps: ";
    for (int i = 0; i < n; i++) {
        out << result.fx[i] << " ";
    }
    out << endl;
    
    out << "||eps||: " << scientific << result.norm << endl;

    for (int i = 0; i < n; i++) {
        delete[] functions[i];
    }
    delete[] functions;
    delete[] x0;
    delete[] result.x;
    delete[] result.fx;

    in.close();
    out.close();
    
    return 0;
}