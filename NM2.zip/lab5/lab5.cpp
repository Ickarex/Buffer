#include <fstream>
#include <iostream>
#include <string>
#include <cmath>
#include <iomanip>
#include "PolStr.h"

using namespace std;

// Структура для хранения результата интерполяции
struct InterpResult {
    double* x_vals;
    double* y_vals;
    double sko;
    int m;
};

// Функция вычисления разделенных разностей для полинома Ньютона
double* computeDividedDifferences(double* x, double* y, int n) {
    double** table = new double*[n + 1];
    for (int i = 0; i <= n; i++) {
        table[i] = new double[n + 1];
        table[i][0] = y[i];
    }
    
    for (int j = 1; j <= n; j++) {
        for (int i = 0; i <= n - j; i++) {
            table[i][j] = (table[i + 1][j - 1] - table[i][j - 1]) / (x[i + j] - x[i]);
        }
    }
    
    double* diff = new double[n + 1];
    for (int i = 0; i <= n; i++) {
        diff[i] = table[0][i];
    }
    
    for (int i = 0; i <= n; i++) {
        delete[] table[i];
    }
    delete[] table;
    
    return diff;
}

// Вычисление полинома Ньютона в точке x
double newtonPolynomial(double x, double* x_nodes, double* diff, int n) {
    double result = diff[0];
    double product = 1.0;
    
    for (int i = 1; i <= n; i++) {
        product *= (x - x_nodes[i - 1]);
        result += diff[i] * product;
    }
    return result;
}

// Вычисление первой производной полинома Ньютона в точке x
double newtonDerivative1(double x, double* x_nodes, double* diff, int n) {
    double result = 0.0;
    
    for (int i = 1; i <= n; i++) {
        double term = diff[i];
        double sum = 0.0;
        
        for (int j = 0; j < i; j++) {
            double product = 1.0;
            for (int k = 0; k < i; k++) {
                if (k != j) {
                    product *= (x - x_nodes[k]);
                }
            }
            sum += product;
        }
        result += term * sum;
    }
    return result;
}

// Вычисление второй производной полинома Ньютона в точке x
double newtonDerivative2(double x, double* x_nodes, double* diff, int n) {
    double result = 0.0;
    
    for (int i = 2; i <= n; i++) {
        double term = diff[i];
        double sum = 0.0;
        
        for (int j = 0; j < i; j++) {
            for (int l = 0; l < i; l++) {
                if (l != j) {
                    double product = 1.0;
                    for (int k = 0; k < i; k++) {
                        if (k != j && k != l) {
                            product *= (x - x_nodes[k]);
                        }
                    }
                    sum += product;
                }
            }
        }
        result += term * sum;
    }
    return result;
}

// Обработка равномерной сетки
InterpResult processUniform(int derivative_order, int n, double a, double b, 
                            double* y_nodes, int m, double* x_result, 
                            bool has_analytic, char* analytic_func) {
    double h = (b - a) / n;
    double* x_nodes = new double[n + 1];
    for (int i = 0; i <= n; i++) {
        x_nodes[i] = a + i * h;
    }
    
    double* diff = computeDividedDifferences(x_nodes, y_nodes, n);
    
    InterpResult result;
    result.m = m;
    result.x_vals = new double[m + 1];
    result.y_vals = new double[m + 1];
    
    for (int i = 0; i <= m; i++) {
        result.x_vals[i] = x_result[i];
        double x = x_result[i];
        
        switch (derivative_order) {
            case 0:
                result.y_vals[i] = newtonPolynomial(x, x_nodes, diff, n);
                break;
            case 1:
                result.y_vals[i] = newtonDerivative1(x, x_nodes, diff, n);
                break;
            case 2:
                result.y_vals[i] = newtonDerivative2(x, x_nodes, diff, n);
                break;
        }
    }
    
    // Вычисление СКО, если есть аналитическое выражение
    if (has_analytic) {
        char* polstr = CreatePolStr(analytic_func, 0);
        double sum_sq = 0.0;
        for (int i = 0; i <= m; i++) {
            double exact = EvalPolStr(polstr, result.x_vals[i], derivative_order);
            double diff_val = result.y_vals[i] - exact;
            sum_sq += diff_val * diff_val;
        }
        result.sko = sqrt(sum_sq / (m + 1));
        delete[] polstr;
    } else {
        result.sko = 0.0;
    }
    
    delete[] x_nodes;
    delete[] diff;
    return result;
}

// Обработка неравномерной сетки
InterpResult processNonUniform(int derivative_order, int n, double* x_nodes, 
                               double* y_nodes, int m, double* x_result,
                               bool has_analytic, char* analytic_func) {
    double* diff = computeDividedDifferences(x_nodes, y_nodes, n);
    
    InterpResult result;
    result.m = m;
    result.x_vals = new double[m + 1];
    result.y_vals = new double[m + 1];
    
    for (int i = 0; i <= m; i++) {
        result.x_vals[i] = x_result[i];
        double x = x_result[i];
        
        switch (derivative_order) {
            case 0:
                result.y_vals[i] = newtonPolynomial(x, x_nodes, diff, n);
                break;
            case 1:
                result.y_vals[i] = newtonDerivative1(x, x_nodes, diff, n);
                break;
            case 2:
                result.y_vals[i] = newtonDerivative2(x, x_nodes, diff, n);
                break;
        }
    }
    
    // Вычисление СКО, если есть аналитическое выражение
    if (has_analytic) {
        char* polstr = CreatePolStr(analytic_func, 0);
        double sum_sq = 0.0;
        for (int i = 0; i <= m; i++) {
            double exact = EvalPolStr(polstr, result.x_vals[i], derivative_order);
            double diff_val = result.y_vals[i] - exact;
            sum_sq += diff_val * diff_val;
        }
        result.sko = sqrt(sum_sq / (m + 1));
        delete[] polstr;
    } else {
        result.sko = 0.0;
    }
    
    delete[] diff;
    return result;
}

int main() {
    ifstream in("input.txt");
    ofstream out("output.txt");
    
    if (!in.is_open()) {
        cout << "Ошибка открытия входного файла" << endl;
        return 1;
    }
    if (!out.is_open()) {
        cout << "Ошибка открытия выходного файла" << endl;
        return 1;
    }
    
    // Чтение входных данных согласно формату
    int derivative_order;
    int n;
    string grid_type_str;
    
    in >> derivative_order;
    in >> n;
    in >> grid_type_str;
    
    bool is_uniform = (grid_type_str == "uniform" || grid_type_str == "равномерная");
    
    double a, b;
    double* x_nodes = NULL;
    double* y_nodes = new double[n + 1];
    
    if (is_uniform) {
        in >> a >> b;
        for (int i = 0; i <= n; i++) {
            in >> y_nodes[i];
        }
    } else {
        x_nodes = new double[n + 1];
        for (int i = 0; i <= n; i++) {
            in >> x_nodes[i];
        }
        for (int i = 0; i <= n; i++) {
            in >> y_nodes[i];
        }
    }
    
    int m;
    in >> m;
    
    double* x_result = new double[m + 1];
    for (int i = 0; i <= m; i++) {
        in >> x_result[i];
    }
    
    string has_analytic_str;
    in >> has_analytic_str;
    bool has_analytic = (has_analytic_str == "yes" || has_analytic_str == "да");
    
    char* analytic_func = NULL;
    if (has_analytic) {
        string func_str;
        in.ignore(); // пропустить пробел или перевод строки
        getline(in, func_str);
        analytic_func = new char[func_str.length() + 1];
        strcpy(analytic_func, func_str.c_str());
    }
    
    // Выполнение интерполяции
    InterpResult result;
    if (is_uniform) {
        result = processUniform(derivative_order, n, a, b, y_nodes, m, x_result, has_analytic, analytic_func);
    } else {
        result = processNonUniform(derivative_order, n, x_nodes, y_nodes, m, x_result, has_analytic, analytic_func);
    }
    
    out << fixed << setprecision(6);
    for (int i = 0; i <= m; i++) {
        out << result.x_vals[i] << " " << result.y_vals[i] << endl;
    }
    
    if (has_analytic) {
        out << scientific << setprecision(6) << result.sko << endl;
    }

    delete[] y_nodes;
    if (x_nodes != NULL) delete[] x_nodes;
    delete[] x_result;
    delete[] result.x_vals;
    delete[] result.y_vals;
    if (analytic_func != NULL) delete[] analytic_func;
    
    in.close();
    out.close();
    
    return 0;
}