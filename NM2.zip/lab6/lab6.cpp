#include <fstream>
#include <iostream>
#include <math.h>
#include "PolStr.h"
#include <string>
#include <windows.h>
#include <iomanip>

using namespace std;

// Структура для хранения коэффициентов сплайна
struct SplineCoeff {
    double a, b, c, d;
};

// Функция поиска индекса интервала, содержащего точку x
int findInterval(double x, double* xNodes, int n) {
    for (int i = 0; i < n; i++) {
        if (x >= xNodes[i] && x <= xNodes[i+1]) {
            return i;
        }
    }
    return n - 1;
}

// Вычисление линейного сплайна в точке x
double evalLinearSpline(double x, double* xNodes, double* yNodes, int n, SplineCoeff* coeffs) {
    int i = findInterval(x, xNodes, n);
    return coeffs[i].a + coeffs[i].b * (x - xNodes[i]);
}

// Вычисление параболического сплайна в точке x
double evalParabolicSpline(double x, double* xNodes, double* yNodes, int n, SplineCoeff* coeffs) {
    int i = findInterval(x, xNodes, n);
    return coeffs[i].a + coeffs[i].b * (x - xNodes[i]) + coeffs[i].c * (x - xNodes[i]) * (x - xNodes[i]);
}

// Вычисление кубического сплайна в точке x
double evalCubicSpline(double x, double* xNodes, double* yNodes, int n, SplineCoeff* coeffs) {
    int i = findInterval(x, xNodes, n);
    double dx = x - xNodes[i];
    return coeffs[i].a + coeffs[i].b * dx + coeffs[i].c * dx * dx + coeffs[i].d * dx * dx * dx;
}

// Построение линейных сплайнов
SplineCoeff* buildLinearSplines(double* xNodes, double* yNodes, int n) {
    SplineCoeff* coeffs = new SplineCoeff[n];
    for (int i = 0; i < n; i++) {
        coeffs[i].a = yNodes[i];
        coeffs[i].b = (yNodes[i+1] - yNodes[i]) / (xNodes[i+1] - xNodes[i]);
        coeffs[i].c = 0;
        coeffs[i].d = 0;
    }
    return coeffs;
}

// Построение параболических сплайнов
SplineCoeff* buildParabolicSplines(double* xNodes, double* yNodes, int n, int boundaryIdx, double boundaryVal) {
    SplineCoeff* coeffs = new SplineCoeff[n];
    
    // Вычисляем коэффициенты b
    double* b = new double[n+1];
    if (boundaryIdx == 0) {
        b[0] = boundaryVal;
        for (int i = 0; i < n; i++) {
            b[i+1] = 2.0 * (yNodes[i+1] - yNodes[i]) / (xNodes[i+1] - xNodes[i]) - b[i];
        }
    } else {
        b[n] = boundaryVal;
        for (int i = n-1; i >= 0; i--) {
            b[i] = 2.0 * (yNodes[i+1] - yNodes[i]) / (xNodes[i+1] - xNodes[i]) - b[i+1];
        }
    }
    
    // Формируем коэффициенты сплайнов
    for (int i = 0; i < n; i++) {
        coeffs[i].a = yNodes[i];
        coeffs[i].b = b[i];
        coeffs[i].c = (b[i+1] - b[i]) / (2.0 * (xNodes[i+1] - xNodes[i]));
        coeffs[i].d = 0;
    }
    
    delete[] b;
    return coeffs;
}

// Решение трехдиагональной СЛАУ методом прогонки
void solveTridiagonal(double* a, double* b, double* c, double* d, double* x, int size) {
    double* alpha = new double[size];
    double* beta = new double[size];
    
    alpha[0] = -c[0] / b[0];
    beta[0] = d[0] / b[0];
    
    for (int i = 1; i < size; i++) {
        double denom = b[i] + a[i] * alpha[i-1];
        alpha[i] = -c[i] / denom;
        beta[i] = (d[i] - a[i] * beta[i-1]) / denom;
    }
    
    x[size-1] = beta[size-1];
    for (int i = size-2; i >= 0; i--) {
        x[i] = alpha[i] * x[i+1] + beta[i];
    }
    
    delete[] alpha;
    delete[] beta;
}

// Построение кубических сплайнов (граничные условия по второй производной)
SplineCoeff* buildCubicSplines(double* xNodes, double* yNodes, int n, double B0, double Bn) {
    SplineCoeff* coeffs = new SplineCoeff[n];
    
    int m = n - 1; // количество неизвестных M1...M_{n-1}
    double* A = new double[m];
    double* B = new double[m];
    double* C = new double[m];
    double* D = new double[m];
    double* M = new double[m];
    
    for (int i = 0; i < m; i++) {
        double dx_prev = (i == 0) ? (xNodes[1] - xNodes[0]) : (xNodes[i] - xNodes[i-1]);
        double dx_next = (i == m-1) ? (xNodes[n] - xNodes[n-1]) : (xNodes[i+2] - xNodes[i+1]);
        
        A[i] = (i > 0) ? (xNodes[i] - xNodes[i-1]) / 6.0 : 0;
        B[i] = (xNodes[i+1] - xNodes[i-1]) / 3.0;
        C[i] = (i < m-1) ? (xNodes[i+1] - xNodes[i]) / 6.0 : 0;
        
        double dy_i = (i < m) ? (yNodes[i+1] - yNodes[i]) / (xNodes[i+1] - xNodes[i]) : 0;
        double dy_prev = (i > 0) ? (yNodes[i] - yNodes[i-1]) / (xNodes[i] - xNodes[i-1]) : 0;
        D[i] = dy_i - dy_prev;
    }
    
    // Добавляем граничные условия по второй производной
    if (m > 0) {
        D[0] -= (xNodes[1] - xNodes[0]) / 6.0 * B0;
        D[m-1] -= (xNodes[n] - xNodes[n-1]) / 6.0 * Bn;
    }
    
    // Решаем СЛАУ
    if (m > 0) {
        solveTridiagonal(A, B, C, D, M, m);
    }
    
    // Формируем коэффициенты сплайнов
    for (int i = 0; i < n; i++) {
        double dx = xNodes[i+1] - xNodes[i];
        double Mi = (i == 0) ? B0 : M[i-1];
        double Mip1 = (i == n-1) ? Bn : M[i];
        
        coeffs[i].a = yNodes[i];
        coeffs[i].b = (yNodes[i+1] - yNodes[i]) / dx - dx / 6.0 * (2.0 * Mi + Mip1);
        coeffs[i].c = Mi / 2.0;
        coeffs[i].d = (Mip1 - Mi) / (6.0 * dx);
    }
    
    delete[] A;
    delete[] B;
    delete[] C;
    delete[] D;
    delete[] M;
    
    return coeffs;
}

// Построение кубических сплайнов (граничные условия по первой производной)
SplineCoeff* buildCubicSplinesDerivative(double* xNodes, double* yNodes, int n, double A0, double An) {
    SplineCoeff* coeffs = new SplineCoeff[n];
    
    int m = n + 1; // количество неизвестных M0...Mn
    double* a = new double[m];
    double* b = new double[m];
    double* c = new double[m];
    double* d = new double[m];
    double* M = new double[m];
    
    // Первое уравнение (для M0)
    b[0] = (xNodes[1] - xNodes[0]) / 3.0;
    c[0] = (xNodes[1] - xNodes[0]) / 6.0;
    a[0] = 0;
    d[0] = (yNodes[1] - yNodes[0]) / (xNodes[1] - xNodes[0]) - A0;
    
    // Внутренние уравнения
    for (int i = 1; i < n; i++) {
        a[i] = (xNodes[i] - xNodes[i-1]) / 6.0;
        b[i] = (xNodes[i+1] - xNodes[i-1]) / 3.0;
        c[i] = (xNodes[i+1] - xNodes[i]) / 6.0;
        d[i] = (yNodes[i+1] - yNodes[i]) / (xNodes[i+1] - xNodes[i]) - 
               (yNodes[i] - yNodes[i-1]) / (xNodes[i] - xNodes[i-1]);
    }
    
    // Последнее уравнение (для Mn)
    a[n] = (xNodes[n] - xNodes[n-1]) / 6.0;
    b[n] = (xNodes[n] - xNodes[n-1]) / 3.0;
    c[n] = 0;
    d[n] = An - (yNodes[n] - yNodes[n-1]) / (xNodes[n] - xNodes[n-1]);
    
    // Решаем СЛАУ
    solveTridiagonal(a, b, c, d, M, m);
    
    // Формируем коэффициенты сплайнов
    for (int i = 0; i < n; i++) {
        double dx = xNodes[i+1] - xNodes[i];
        double Mi = M[i];
        double Mip1 = M[i+1];
        
        coeffs[i].a = yNodes[i];
        coeffs[i].b = (yNodes[i+1] - yNodes[i]) / dx - dx / 6.0 * (2.0 * Mi + Mip1);
        coeffs[i].c = Mi / 2.0;
        coeffs[i].d = (Mip1 - Mi) / (6.0 * dx);
    }
    
    delete[] a;
    delete[] b;
    delete[] c;
    delete[] d;
    delete[] M;
    
    return coeffs;
}

int main() {
    SetConsoleCP(CP_UTF8);
    SetConsoleOutputCP(CP_UTF8);

    ifstream in("./input.txt");
    fstream out("./output.txt");
    
    if (!in.is_open()) {
        cout << "Ошибка открытия входного файла" << endl;
        return 1;
    }
    if (!out.is_open()) {
        cout << "Ошибка открытия выходного файла" << endl;
        return 1;
    }

    // Чтение входных данных
    int k; // порядок сплайна
    int n; // количество сплайнов
    in >> k >> n;
    
    // Чтение узлов сетки
    double* xNodes = new double[n+1];
    for (int i = 0; i <= n; i++) {
        in >> xNodes[i];
    }
    
    // Чтение значений функции в узлах
    double* yNodes = new double[n+1];
    for (int i = 0; i <= n; i++) {
        in >> yNodes[i];
    }
    
    SplineCoeff* coeffs = NULL;
    int boundaryIdx = 0;
    double boundaryVal = 0;
    double B0 = 0, Bn = 0;
    int boundaryType = 0; // 0 - по второй производной, 1 - по первой
    
    // Чтение граничных условий в зависимости от типа сплайна
    if (k == 2) {
        in >> boundaryIdx >> boundaryVal;
    } else if (k == 3) {
        string boundaryTypeStr;
        in >> boundaryTypeStr;
        if (boundaryTypeStr == "second") {
            boundaryType = 0;
            in >> B0 >> Bn;
        } else {
            boundaryType = 1;
            in >> B0 >> Bn; // здесь B0 и Bn - значения первой производной
        }
    }
    
    // Чтение результирующей сетки
    int m;
    in >> m;
    double* xResult = new double[m+1];
    for (int i = 0; i <= m; i++) {
        in >> xResult[i];
    }
    
    // Чтение информации о наличии аналитического выражения
    string t;
    in >> t;
    bool hasAnalytical = (t == "yes" || t == "true");
    string func = "";
    if (hasAnalytical) {
        in.ignore();
        getline(in, func);
    }
    
    // Построение сплайнов в зависимости от типа
    double* yResult = new double[m+1];
    
    if (k == 1) {
        coeffs = buildLinearSplines(xNodes, yNodes, n);
        for (int i = 0; i <= m; i++) {
            yResult[i] = evalLinearSpline(xResult[i], xNodes, yNodes, n, coeffs);
        }
    } else if (k == 2) {
        coeffs = buildParabolicSplines(xNodes, yNodes, n, boundaryIdx, boundaryVal);
        for (int i = 0; i <= m; i++) {
            yResult[i] = evalParabolicSpline(xResult[i], xNodes, yNodes, n, coeffs);
        }
    } else if (k == 3) {
        if (boundaryType == 0) {
            coeffs = buildCubicSplines(xNodes, yNodes, n, B0, Bn);
        } else {
            coeffs = buildCubicSplinesDerivative(xNodes, yNodes, n, B0, Bn);
        }
        for (int i = 0; i <= m; i++) {
            yResult[i] = evalCubicSpline(xResult[i], xNodes, yNodes, n, coeffs);
        }
    }
    
    // Вывод коэффициентов сплайнов
    for (int i = 0; i < n; i++) {
        out << coeffs[i].a << " " << coeffs[i].b << " " 
            << coeffs[i].c << " " << coeffs[i].d << endl;
    }
    
    // Вывод значений в узлах результирующей сетки
    for (int i = 0; i <= m; i++) {
        out << xResult[i] << " " << yResult[i] << endl;
    }
    
    // Вычисление СКО, если известно аналитическое выражение
    if (hasAnalytical) {
        char* polstr = CreatePolStr(func.c_str(), 0);
        double sum = 0;
        for (int i = 0; i <= m; i++) {
            double exact = EvalPolStr(polstr, xResult[i]);
            sum += (yResult[i] - exact) * (yResult[i] - exact);
        }
        double rmse = sqrt(sum / (m + 1));
        out << scientific << rmse << endl;
        delete[] polstr;
    }
    
    // Освобождение памяти
    delete[] xNodes;
    delete[] yNodes;
    delete[] xResult;
    delete[] yResult;
    delete[] coeffs;
    
    in.close();
    out.close();
    return 0;
}