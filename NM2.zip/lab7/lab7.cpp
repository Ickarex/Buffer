#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
#include <windows.h>
#include "PolStr.h"

using namespace std;

// === ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ДЛЯ МЕТОДА ГАУССА ===

double legendre(int n, double x) {
    if (n == 0) return 1.0;
    if (n == 1) return x;
    
    double P_prev = 1.0;
    double P_curr = x;
    
    for (int i = 2; i <= n; i++) {
        double P_next = ((2.0 * i - 1.0) * x * P_curr - (i - 1.0) * P_prev) / i;
        P_prev = P_curr;
        P_curr = P_next;
    }
    return P_curr;
}

double legendre_derivative(int n, double x) {
    if (n == 0) return 0.0;
    if (n == 1) return 1.0;
    
    if (fabs(x) == 1.0) {
        if (x > 0) return n * (n + 1) / 2.0;
        else return -n * (n + 1) / 2.0;
    }
    
    double P_n = legendre(n, x);
    double P_n_1 = legendre(n - 1, x);
    return n * (x * P_n - P_n_1) / (x * x - 1.0);
}

double find_root(int n, double initial_guess) {
    double x = initial_guess;
    double eps = 1e-15;
    int max_iter = 100;
    
    for (int iter = 0; iter < max_iter; iter++) {
        double P = legendre(n, x);
        double dP = legendre_derivative(n, x);
        
        if (fabs(P) < eps) break;
        if (fabs(dP) < eps) break;
        
        double dx = P / dP;
        x -= dx;
        
        if (fabs(dx) < eps) break;
    }
    return x;
}

void find_gauss_nodes(int n, double* t) {
    for (int i = 0; i < n; i++) {
        double theta = (4.0 * (i + 1) - 1.0) / (4.0 * n + 2.0) * 3.141592653589793;
        double initial_guess = cos(theta);
        t[i] = find_root(n, initial_guess);
    }
    
    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            if (t[i] > t[j]) {
                double temp = t[i];
                t[i] = t[j];
                t[j] = temp;
            }
        }
    }
}

void find_gauss_weights(int n, double* t, double* A) {
    for (int i = 0; i < n; i++) {
        double dP = legendre_derivative(n, t[i]);
        A[i] = 2.0 / ((1.0 - t[i] * t[i]) * dP * dP);
    }
}

void calculate_gauss_coefficients(int n, double*& t, double*& A) {
    t = new double[n];
    A = new double[n];
    find_gauss_nodes(n, t);
    find_gauss_weights(n, t, A);
}

// === ОСНОВНЫЕ МЕТОДЫ ИНТЕГРИРОВАНИЯ ===

double gauss_method(char* function, double a, double b, int n, double* t, double* A) {
    char* polstr = CreatePolStr(function, 0);
    double sum = 0.0;
    for (int i = 0; i < n; i++) {
        double x = (b + a) / 2.0 + (b - a) / 2.0 * t[i];
        sum += A[i] * EvalPolStr(polstr, x);
    }
    double result = (b - a) / 2.0 * sum;
    delete[] polstr;
    return result;
}

// Левые прямоугольники (аналитическая)
double left_rectangles(char* function, double a, double b, int n) {
    char* polstr = CreatePolStr(function, 0);
    double h = (b - a) / n;
    double sum = 0.0;
    for (int i = 0; i < n; i++) {
        double x = a + i * h;
        sum += EvalPolStr(polstr, x);
    }
    double result = h * sum;
    delete[] polstr;
    return result;
}

// Левые прямоугольники (табличная)
double left_rectangles_table(double* y, double a, double b, int n) {
    double h = (b - a) / n;
    double sum = 0.0;
    for (int i = 0; i < n; i++) {
        sum += y[i];
    }
    return h * sum;
}

// Правые прямоугольники (аналитическая)
double right_rectangles(char* function, double a, double b, int n) {
    char* polstr = CreatePolStr(function, 0);
    double h = (b - a) / n;
    double sum = 0.0;
    for (int i = 1; i <= n; i++) {
        double x = a + i * h;
        sum += EvalPolStr(polstr, x);
    }
    double result = h * sum;
    delete[] polstr;
    return result;
}

// Правые прямоугольники (табличная)
double right_rectangles_table(double* y, double a, double b, int n) {
    double h = (b - a) / n;
    double sum = 0.0;
    for (int i = 1; i <= n; i++) {
        sum += y[i];
    }
    return h * sum;
}

// Трапеции (аналитическая)
double trapezoidal(char* function, double a, double b, int n) {
    char* polstr = CreatePolStr(function, 0);
    double h = (b - a) / n;
    double sum = (EvalPolStr(polstr, a) + EvalPolStr(polstr, b)) / 2.0;
    for (int i = 1; i < n; i++) {
        double x = a + i * h;
        sum += EvalPolStr(polstr, x);
    }
    double result = h * sum;
    delete[] polstr;
    return result;
}

// Трапеции (табличная)
double trapezoidal_table(double* y, double a, double b, int n) {
    double h = (b - a) / n;
    double sum = (y[0] + y[n]) / 2.0;
    for (int i = 1; i < n; i++) {
        sum += y[i];
    }
    return h * sum;
}

// Симпсон (аналитическая, равномерная)
double simpson(char* function, double a, double b, int n) {
    if (n % 2 != 0) n++;
    char* polstr = CreatePolStr(function, 0);
    double h = (b - a) / n;
    double sum = EvalPolStr(polstr, a) + EvalPolStr(polstr, b);
    for (int i = 1; i < n; i++) {
        double x = a + i * h;
        if (i % 2 == 0) {
            sum += 2.0 * EvalPolStr(polstr, x);
        } else {
            sum += 4.0 * EvalPolStr(polstr, x);
        }
    }
    double result = (h / 3.0) * sum;
    delete[] polstr;
    return result;
}

// Симпсон (табличная, равномерная)
double simpson_table(double* y, double a, double b, int n) {
    if (n % 2 != 0) n++;
    double h = (b - a) / n;
    double sum = y[0] + y[n];
    for (int i = 1; i < n; i++) {
        if (i % 2 == 0) {
            sum += 2.0 * y[i];
        } else {
            sum += 4.0 * y[i];
        }
    }
    return (h / 3.0) * sum;
}

// Симпсон (аналитическая, неравномерная) - формула (7.17)
double simpson_nonuniform(char* function, double* x, int n) {
    if (n % 2 != 0) n++;
    char* polstr = CreatePolStr(function, 0);
    
    double sum = 0.0;
    for (int i = 0; i < n - 1; i += 2) {
        double h1 = x[i + 1] - x[i];
        double h2 = x[i + 2] - x[i + 1];
        double h_sum = h1 + h2;
        
        double y0 = EvalPolStr(polstr, x[i]);
        double y1 = EvalPolStr(polstr, x[i + 1]);
        double y2 = EvalPolStr(polstr, x[i + 2]);
        
        double I_r = (h_sum / 6.0) * (
            (2.0 * h1 + h2) / (h1 + h2) * y0 +
            (h1 + h2) * (h1 + h2) / (h1 * h2) * y1 +
            (h1 + 2.0 * h2) / (h1 + h2) * y2
        );
        sum += I_r;
    }
    
    delete[] polstr;
    return sum;
}

// Симпсон (табличная, неравномерная)
double simpson_nonuniform_table(double* x, double* y, int n) {
    if (n % 2 != 0) n++;
    
    double sum = 0.0;
    for (int i = 0; i < n - 1; i += 2) {
        double h1 = x[i + 1] - x[i];
        double h2 = x[i + 2] - x[i + 1];
        double h_sum = h1 + h2;
        
        double y0 = y[i];
        double y1 = y[i + 1];
        double y2 = y[i + 2];
        
        double I_r = (h_sum / 6.0) * (
            (2.0 * h1 + h2) / (h1 + h2) * y0 +
            (h1 + h2) * (h1 + h2) / (h1 * h2) * y1 +
            (h1 + 2.0 * h2) / (h1 + h2) * y2
        );
        sum += I_r;
    }
    
    return sum;
}

// Вычисление интеграла с заданной точностью (динамическая сетка)
double integrate_with_precision(char* function, double a, double b, double eps, 
                                 double (*method)(char*, double, double, int),
                                 int& iterations) {
    int n = 2;
    double I_prev = method(function, a, b, n);
    double I_curr;
    iterations = 1;
    
    do {
        n *= 2;
        I_curr = method(function, a, b, n);
        iterations++;
        
        double delta = fabs(I_curr - I_prev);
        if (fabs(I_curr) > 1e-15) {
            if (delta / fabs(I_curr) < eps) break;
        } else {
            if (delta < eps) break;
        }
        I_prev = I_curr;
    } while (true);
    
    return I_curr;
}

void print_gauss_coefficients(ofstream& out, int n, double* t, double* A) {
    out << "t_i:" << endl;
    for (int i = 0; i < n; i++) {
        out << scientific << setprecision(15) << t[i];
        if (i < n - 1) out << " ";
    }
    out << endl;
    
    out << "A_i:" << endl;
    for (int i = 0; i < n; i++) {
        out << scientific << setprecision(15) << A[i];
        if (i < n - 1) out << " ";
    }
    out << endl;
}

int main() {
    SetConsoleCP(CP_UTF8);
    SetConsoleOutputCP(CP_UTF8);

    ifstream in("./input.txt");
    ofstream out("./output.txt");
    
    if (!in.is_open()) {
        cout << "Ошибка открытия входного файла" << endl;
        return 1;
    }
    if (!out.is_open()) {
        cout << "Ошибка открытия выходного файла" << endl;
        return 1;
    }

    int method_num;
    string func_str;
    string grid_type;
    int n;
    int order;
    double a, b;
    double eps;
    string func_type;
    double* y = NULL;
    double* x_nodes = NULL;  // Для неравномерной сетки
    
    in >> method_num;
    
    if (method_num != 5) {
        in >> grid_type;
        if (grid_type != "dynamic") {
            in >> n;
        }
        
        if (grid_type == "uniform") {
            in >> a >> b;
        } else if (grid_type == "dynamic") {
            in >> a >> b;
        } else if (grid_type == "nonuniform") {
            x_nodes = new double[n + 1];
            for (int i = 0; i <= n; i++) {
                in >> x_nodes[i];
            }
            a = x_nodes[0];
            b = x_nodes[n];
        }
    } else {
        in >> order;
        in >> a >> b;
    }
    
    in >> func_type;
    
    // Чтение функции или табличных значений
    if (method_num != 5 && grid_type != "dynamic") {
        if (func_type == "table") {
            y = new double[n + 1];
            for (int i = 0; i <= n; i++) {
                in >> y[i];
            }
        } else {
            in >> func_str;
        }
    } else {
        in >> func_str;
    }
    
    char* function = NULL;
    if (func_type == "analytic" || method_num == 5 || grid_type == "dynamic") {
        function = const_cast<char*>(func_str.c_str());
    }
    
    if (method_num == 5) {
        in >> eps;
    } else if (grid_type == "dynamic") {
        in >> eps;
    }
    
    double result;
    int iterations = 0;
    
    out << scientific << setprecision(10);
    
    switch (method_num) {
        case 1: {
            if (grid_type == "dynamic") {
                result = integrate_with_precision(function, a, b, eps, left_rectangles, iterations);
                out << scientific << setprecision(10) << result << endl;
                out << iterations << endl;
                double delta = fabs(result - left_rectangles(function, a, b, n));
                out << scientific << delta << endl;
            } else if (func_type == "table") {
                result = left_rectangles_table(y, a, b, n);
                out << scientific << setprecision(10) << result << endl;
            } else {
                result = left_rectangles(function, a, b, n);
                out << scientific << setprecision(10) << result << endl;
            }
            break;
        }
        case 2: {
            if (grid_type == "dynamic") {
                result = integrate_with_precision(function, a, b, eps, right_rectangles, iterations);
                out << scientific << setprecision(10) << result << endl;
                out << iterations << endl;
                double delta = fabs(result - right_rectangles(function, a, b, n));
                out << scientific << delta << endl;
            } else if (func_type == "table") {
                result = right_rectangles_table(y, a, b, n);
                out << fixed << setprecision(10) << result << endl;
            } else {
                result = right_rectangles(function, a, b, n);
                out << fixed << setprecision(10) << result << endl;
            }
            break;
        }
        case 3: {
            if (grid_type == "dynamic") {
                result = integrate_with_precision(function, a, b, eps, trapezoidal, iterations);
                out << fixed << setprecision(10) << result << endl;
                out << iterations << endl;
                double delta = fabs(result - trapezoidal(function, a, b, n));
                out << scientific << delta << endl;
            } else if (func_type == "table") {
                result = trapezoidal_table(y, a, b, n);
                out << fixed << setprecision(10) << result << endl;
            } else {
                result = trapezoidal(function, a, b, n);
                out << fixed << setprecision(10) << result << endl;
            }
            break;
        }
        case 4: {
            if (grid_type == "dynamic") {
                result = integrate_with_precision(function, a, b, eps, simpson, iterations);
                out << fixed << setprecision(10) << result << endl;
                out << iterations << endl;
                double delta = fabs(result - simpson(function, a, b, n));
                out << scientific << delta << endl;
            } else if (grid_type == "nonuniform") {
                if (func_type == "table") {
                    result = simpson_nonuniform_table(x_nodes, y, n);
                } else {
                    result = simpson_nonuniform(function, x_nodes, n);
                }
                out << fixed << setprecision(10) << result << endl;
            } else if (func_type == "table") {
                result = simpson_table(y, a, b, n);
                out << fixed << setprecision(10) << result << endl;
            } else {
                result = simpson(function, a, b, n);
                out << fixed << setprecision(10) << result << endl;
            }
            break;
        }
        case 5: {
            double* t = NULL;
            double* A = NULL;
            
            calculate_gauss_coefficients(order, t, A);
            print_gauss_coefficients(out, order, t, A);
            
            result = gauss_method(function, a, b, order, t, A);
            out << fixed << setprecision(10) << result << endl;
            
            delete[] t;
            delete[] A;
            break;
        }
        default: {
            cout << "Нет метода с таким номером" << endl;
            return 1;
        }
    }

    if (y != NULL) delete[] y;
    if (x_nodes != NULL) delete[] x_nodes;
    
    in.close();
    out.close();
    return 0;
}