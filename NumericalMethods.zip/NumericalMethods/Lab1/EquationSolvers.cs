using System;
using System.Collections.Generic;
using MathFlow.Core;

namespace NumericalMethods
{
    public class PolStr
    {
        private readonly MathEngine Engine = new MathEngine();
        private readonly string Expression;

        public PolStr(string expression) => Expression = expression;

        public double Calculate(double x)
        {
            try
            {
                var variables = new Dictionary<string, double> { ["x"] = x };
                return Engine.Calculate(Expression, variables);
            }
            catch (Exception ex)
            {
                throw new Exception($"Ошибка вычисления функции: {ex.Message}");
            }
        }

        public double Derivative(double x, double h = 1e-6) 
            => (Calculate(x + h) - Calculate(x - h)) / (2 * h);

        public double SecondDerivative(double x, double h = 1e-4) 
            => (Calculate(x + h) - 2 * Calculate(x) + Calculate(x - h)) / (h * h);

        public bool HasRoot(double a, double b)
        {
            double Fa = Calculate(a), Fb = Calculate(b);
            return Fa * Fb <= 0 || Math.Abs(Fa) < 1e-15 || Math.Abs(Fb) < 1e-15;
        }
    }

    public class SolutionResult
    {
        public double Root { get; set; }
        public double FunctionValue { get; set; }
        public double AchievedAccuracy { get; set; }
        public int Iterations { get; set; }
        public bool Success { get; set; }
        public string ErrorMessage { get; set; } = string.Empty;
    }

    public interface IEquationSolver
    {
        SolutionResult Solve(PolStr f, double a, double b, double eps);
        string MethodName { get; }
    }

    public class DichotomyMethod : IEquationSolver
    {
        public string MethodName => "Дихотомия";

        public SolutionResult Solve(PolStr f, double a, double b, double eps)
        {
            var result = new SolutionResult();
            
            double Fa = f.Calculate(a);
            double Fb = f.Calculate(b);
            
            if (Math.Abs(Fa) < eps)
                return new SolutionResult { Root = a, FunctionValue = Fa, AchievedAccuracy = Math.Abs(Fa), Iterations = 0, Success = true };
            
            if (Math.Abs(Fb) < eps)
                return new SolutionResult { Root = b, FunctionValue = Fb, AchievedAccuracy = Math.Abs(Fb), Iterations = 0, Success = true };
            
            if (Fa * Fb > 0)
            {
                result.ErrorMessage = "На отрезке нет корня или их четное количество";
                return result;
            }

            int iterations = 0;
            
            while ((b - a) / 2 > eps && iterations < 10000)
            {
                double c = (a + b) / 2;
                double Fc = f.Calculate(c);
                
                if (Math.Abs(Fc) < eps)
                {
                    a = b = c;
                    break;
                }
                
                if (Fa * Fc < 0)
                {
                    b = c;
                    Fb = Fc;
                }
                else
                {
                    a = c;
                    Fa = Fc;
                }
                
                iterations++;
            }

            result.Root = (a + b) / 2;
            result.FunctionValue = f.Calculate(result.Root);
            result.AchievedAccuracy = (b - a) / 2;
            result.Iterations = iterations;
            result.Success = true;
            return result;
        }
    }

    public class ChordMethod : IEquationSolver
    {
        public string MethodName => "Хорд";

        public SolutionResult Solve(PolStr f, double a, double b, double eps)
        {
            var result = new SolutionResult();
            
            double Fa = f.Calculate(a);
            double Fb = f.Calculate(b);
            
            if (Math.Abs(Fa) < eps)
                return new SolutionResult { Root = a, FunctionValue = Fa, AchievedAccuracy = Math.Abs(Fa), Iterations = 0, Success = true };
            
            if (Math.Abs(Fb) < eps)
                return new SolutionResult { Root = b, FunctionValue = Fb, AchievedAccuracy = Math.Abs(Fb), Iterations = 0, Success = true };
            
            if (Fa * Fb > 0)
            {
                result.ErrorMessage = "На отрезке нет корня или их четное количество";
                return result;
            }

            int iterations = 0;
            double xCurr;
            double fCurr;
            
            do
            {
                xCurr = a - Fa * (b - a) / (Fb - Fa);
                fCurr = f.Calculate(xCurr);
                iterations++;
                
                if (Math.Abs(fCurr) < eps)
                {
                    result.Root = xCurr;
                    result.FunctionValue = fCurr;
                    result.AchievedAccuracy = Math.Abs(fCurr);
                    result.Iterations = iterations;
                    result.Success = true;
                    return result;
                }
                
                if (Fa * fCurr < 0)
                {
                    b = xCurr;
                    Fb = fCurr;
                }
                else
                {
                    a = xCurr;
                    Fa = fCurr;
                }
                
                if (iterations > 10000) break;
                
            } while (true);

            result.Root = xCurr;
            result.FunctionValue = fCurr;
            result.AchievedAccuracy = Math.Abs(fCurr);
            result.Iterations = iterations;
            result.Success = true;
            return result;
        }
    }

    public class NewtonMethod : IEquationSolver
    {
        public string MethodName => "Ньютона";

        public SolutionResult Solve(PolStr f, double a, double b, double eps)
        {
            var result = new SolutionResult();
            
            double Fa = f.Calculate(a);
            double Fb = f.Calculate(b);
            
            if (Math.Abs(Fa) < eps)
                return new SolutionResult { Root = a, FunctionValue = Fa, AchievedAccuracy = Math.Abs(Fa), Iterations = 0, Success = true };
            
            if (Math.Abs(Fb) < eps)
                return new SolutionResult { Root = b, FunctionValue = Fb, AchievedAccuracy = Math.Abs(Fb), Iterations = 0, Success = true };
            
            if (Fa * Fb > 0)
            {
                result.ErrorMessage = "На отрезке нет корня или их четное количество";
                return result;
            }

            double x0 = (a + b) / 2;
            int iterations = 0;
            double xPrev = x0;
            double xCurr;
            double fCurr;
            
            do
            {
                double fPrev = f.Calculate(xPrev);
                double fDeriv = f.Derivative(xPrev);
                
                if (Math.Abs(fDeriv) < 1e-15)
                {
                    result.ErrorMessage = "Производная близка к нулю";
                    return result;
                }
                
                xCurr = xPrev - fPrev / fDeriv;
                fCurr = f.Calculate(xCurr);
                iterations++;
                
                if (Math.Abs(fCurr) < eps)
                {
                    result.Root = xCurr;
                    result.FunctionValue = fCurr;
                    result.AchievedAccuracy = Math.Abs(fCurr);
                    result.Iterations = iterations;
                    result.Success = true;
                    return result;
                }
                
                if (xCurr < a || xCurr > b)
                {
                    xCurr = (a + b) / 2;
                }
                
                if (iterations > 10000) break;
                
                xPrev = xCurr;
                
            } while (true);

            result.Root = xCurr;
            result.FunctionValue = fCurr;
            result.AchievedAccuracy = Math.Abs(fCurr);
            result.Iterations = iterations;
            result.Success = true;
            return result;
        }
    }

    public class GoldenSectionMethod : IEquationSolver
    {
        public string MethodName => "Золотое сечение";
        private const double InvPhi = 0.618033988749895;

        public SolutionResult Solve(PolStr f, double a, double b, double eps)
        {
            var result = new SolutionResult();
            
            double Fa = f.Calculate(a);
            double Fb = f.Calculate(b);
            
            if (Math.Abs(Fa) < eps)
                return new SolutionResult { Root = a, FunctionValue = Fa, AchievedAccuracy = Math.Abs(Fa), Iterations = 0, Success = true };
            
            if (Math.Abs(Fb) < eps)
                return new SolutionResult { Root = b, FunctionValue = Fb, AchievedAccuracy = Math.Abs(Fb), Iterations = 0, Success = true };
            
            if (Fa * Fb > 0)
            {
                result.ErrorMessage = "На отрезке нет корня или их четное количество";
                return result;
            }

            int iterations = 0;
            double x1, x2, f1, f2;
            
            while ((b - a) / 2 > eps && iterations < 10000)
            {
                x1 = b - (b - a) * InvPhi;
                x2 = a + (b - a) * InvPhi;
                
                f1 = f.Calculate(x1);
                f2 = f.Calculate(x2);
                
                if (Math.Abs(f1) < eps)
                {
                    result.Root = x1;
                    result.FunctionValue = f1;
                    result.AchievedAccuracy = (b - a) / 2;
                    result.Iterations = iterations;
                    result.Success = true;
                    return result;
                }
                
                if (Math.Abs(f2) < eps)
                {
                    result.Root = x2;
                    result.FunctionValue = f2;
                    result.AchievedAccuracy = (b - a) / 2;
                    result.Iterations = iterations;
                    result.Success = true;
                    return result;
                }
                
                if (f1 * f2 < 0)
                {
                    a = x1;
                    b = x2;
                    Fa = f1;
                    Fb = f2;
                }
                else if (Fa * f1 < 0)
                {
                    b = x1;
                    Fb = f1;
                }
                else
                {
                    a = x2;
                    Fa = f2;
                }
                
                iterations++;
            }

            result.Root = (a + b) / 2;
            result.FunctionValue = f.Calculate(result.Root);
            result.AchievedAccuracy = (b - a) / 2;
            result.Iterations = iterations;
            result.Success = true;
            return result;
        }
    }

    public class CombinedMethod : IEquationSolver
    {
        public string MethodName => "Комбинированный";

        public SolutionResult Solve(PolStr f, double a, double b, double eps)
        {
            var result = new SolutionResult();
            
            double Fa = f.Calculate(a);
            double Fb = f.Calculate(b);
            
            if (Math.Abs(Fa) < eps)
                return new SolutionResult { Root = a, FunctionValue = Fa, AchievedAccuracy = Math.Abs(Fa), Iterations = 0, Success = true };
            
            if (Math.Abs(Fb) < eps)
                return new SolutionResult { Root = b, FunctionValue = Fb, AchievedAccuracy = Math.Abs(Fb), Iterations = 0, Success = true };
            
            if (Fa * Fb > 0)
            {
                result.ErrorMessage = "На отрезке нет корня или их четное количество";
                return result;
            }

            int iterations = 0;
            double an = a, bn = b;
            double Fan = Fa, Fbn = Fb;
            double xCurr = (a + b) / 2;
            double fCurr;
            
            while (iterations < 10000)
            {
                double xChord = an - Fan * (bn - an) / (Fbn - Fan);
                double fChord = f.Calculate(xChord);
                
                if (Math.Abs(fChord) < eps)
                {
                    result.Root = xChord;
                    result.FunctionValue = fChord;
                    result.AchievedAccuracy = Math.Abs(fChord);
                    result.Iterations = iterations;
                    result.Success = true;
                    return result;
                }
                
                double xNewton = an - Fan / f.Derivative(an);
                double fNewton = f.Calculate(xNewton);
                
                if (Math.Abs(fNewton) < eps)
                {
                    result.Root = xNewton;
                    result.FunctionValue = fNewton;
                    result.AchievedAccuracy = Math.Abs(fNewton);
                    result.Iterations = iterations;
                    result.Success = true;
                    return result;
                }
                
                if (Math.Abs(fNewton) < Math.Abs(fChord))
                {
                    xCurr = xNewton;
                    fCurr = fNewton;
                    if (Fan * fNewton < 0)
                    {
                        bn = xNewton;
                        Fbn = fNewton;
                    }
                    else
                    {
                        an = xNewton;
                        Fan = fNewton;
                    }
                }
                else
                {
                    xCurr = xChord;
                    fCurr = fChord;
                    if (Fan * fChord < 0)
                    {
                        bn = xChord;
                        Fbn = fChord;
                    }
                    else
                    {
                        an = xChord;
                        Fan = fChord;
                    }
                }
                
                iterations++;
            }

            result.Root = xCurr;
            result.FunctionValue = f.Calculate(xCurr);
            result.AchievedAccuracy = Math.Abs(f.Calculate(xCurr));
            result.Iterations = iterations;
            result.Success = true;
            return result;
        }
    }

    public class IterationMethod : IEquationSolver
    {
        public string MethodName => "Простых итераций";

        public SolutionResult Solve(PolStr f, double a, double b, double eps)
        {
            var result = new SolutionResult();
            
            double Fa = f.Calculate(a);
            double Fb = f.Calculate(b);
            
            if (Math.Abs(Fa) < eps)
                return new SolutionResult { Root = a, FunctionValue = Fa, AchievedAccuracy = Math.Abs(Fa), Iterations = 0, Success = true };
            
            if (Math.Abs(Fb) < eps)
                return new SolutionResult { Root = b, FunctionValue = Fb, AchievedAccuracy = Math.Abs(Fb), Iterations = 0, Success = true };
            
            if (Fa * Fb > 0)
            {
                result.ErrorMessage = "На отрезке нет корня или их четное количество";
                return result;
            }

            double maxDeriv = 0;
            int steps = 100;
            double step = (b - a) / steps;
            
            for (int i = 0; i <= steps; i++)
            {
                double x = a + i * step;
                double deriv = Math.Abs(f.Derivative(x));
                if (deriv > maxDeriv) maxDeriv = deriv;
            }
            
            double mid = (a + b) / 2;
            double derivMid = f.Derivative(mid);
            double sign = Math.Sign(derivMid);
            if (sign == 0)
            {
                sign = 1.0;
            }

            double lambda = sign * 1.0 / maxDeriv;
            
            int iterations = 0;
            double xPrev = (a + b) / 2;
            double xCurr;
            double fCurr;
            
            do
            {
                xCurr = xPrev - lambda * f.Calculate(xPrev);
                fCurr = f.Calculate(xCurr);
                iterations++;
                
                if (xCurr < a || xCurr > b)
                {
                    xCurr = Math.Max(a, Math.Min(b, xCurr));
                }
                
                if (Math.Abs(fCurr) < eps)
                {
                    result.Root = xCurr;
                    result.FunctionValue = fCurr;
                    result.AchievedAccuracy = Math.Abs(fCurr);
                    result.Iterations = iterations;
                    result.Success = true;
                    return result;
                }
                
                if (iterations > 10000) break;
                
                xPrev = xCurr;
                
            } while (true);

            result.Root = xCurr;
            result.FunctionValue = fCurr;
            result.AchievedAccuracy = Math.Abs(fCurr);
            result.Iterations = iterations;
            result.Success = true;
            return result;
        }
    }

    public static class SolverFactory
    {
        private static readonly Dictionary<int, Func<IEquationSolver>> Solvers = new Dictionary<int, Func<IEquationSolver>>
        {
            { 1, () => new DichotomyMethod() },
            { 2, () => new ChordMethod() },
            { 3, () => new NewtonMethod() },
            { 4, () => new GoldenSectionMethod() },
            { 5, () => new CombinedMethod() },
            { 6, () => new IterationMethod() }
        };

        public static IEquationSolver CreateSolver(int number)
        {
            if (Solvers.TryGetValue(number, out var solver))
                return solver();
            
            throw new ArgumentException("Неверный номер метода");
        }
    }
}