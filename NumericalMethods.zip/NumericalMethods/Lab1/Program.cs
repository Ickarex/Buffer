using System;
using System.IO;
using System.Globalization;
using System.Text;
using System.Collections.Generic;

namespace NumericalMethods
{
    class Program
    {
        static void Main(string[] args)
        {
            CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;
            
            Console.OutputEncoding = Encoding.UTF8;
            Console.InputEncoding = Encoding.UTF8;
            
            Console.WriteLine("  Лабораторная работа №1");
            Console.WriteLine("  Решение уравнений с одной переменной");
            Console.WriteLine();
            
            try
            {
                if (!File.Exists("input.txt"))
                {
                    Console.WriteLine("ОШИБКА: Файл input.txt не найден!");
                    Console.WriteLine("Нажмите любую клавишу для выхода...");
                    Console.ReadKey();
                    return;
                }
                
                InputData inputData = ReadInputFile("input.txt");
                PolStr function = new PolStr(inputData.FunctionExpression);
                IEquationSolver solver = SolverFactory.CreateSolver(inputData.MethodNumber);
                
                Console.WriteLine($"Метод: {solver.MethodName} (№{inputData.MethodNumber})");
                Console.WriteLine($"Функция: f(x) = {inputData.FunctionExpression}");
                Console.WriteLine($"Отрезок: [{inputData.LeftBorder:F6}, {inputData.RightBorder:F6}]");
                Console.WriteLine($"Точность: ε = {inputData.Accuracy:E3}\n");
                
                SolutionResult result = solver.Solve(
                    function, 
                    inputData.LeftBorder, 
                    inputData.RightBorder, 
                    inputData.Accuracy
                );
                
                if (result.Success)
                {
                    int decimalPlaces = GetDecimalPlaces(inputData.Accuracy);
                    
                    Console.WriteLine($"Корень: x* = {result.Root.ToString($"F{decimalPlaces}")}");
                    Console.WriteLine($"f(x*) = {result.FunctionValue:E3}");
                    Console.WriteLine($"Точность: ε* = {result.AchievedAccuracy:E3}");
                    Console.WriteLine($"Итераций: {result.Iterations}");
                    
                    WriteOutputFile("output.txt", result, decimalPlaces);
                    Console.WriteLine("\nРезультаты записаны в output.txt");
                }
                else
                {
                    Console.WriteLine("ОШИБКА: " + result.ErrorMessage);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"ОШИБКА: {ex.Message}");
            }
            
            Console.WriteLine("\nНажмите любую клавишу для выхода...");
            Console.ReadKey();
        }

        private static int GetDecimalPlaces(double epsilon)
        {
            if (epsilon >= 0.1) return 1;
            if (epsilon >= 0.01) return 2;
            if (epsilon >= 0.001) return 3;
            if (epsilon >= 0.0001) return 4;
            if (epsilon >= 0.00001) return 5;
            if (epsilon >= 0.000001) return 6;
            return 7;
        }

        private class InputData
        {
            public int MethodNumber { get; set; }
            public string FunctionExpression { get; set; } = string.Empty;
            public double LeftBorder { get; set; }
            public double RightBorder { get; set; }
            public double Accuracy { get; set; }
        }

        private static InputData ReadInputFile(string filename)
        {
            string[] lines = File.ReadAllLines(filename);
            List<string> filtered = new List<string>();
            
            foreach (string line in lines)
            {
                string trimmed = line.Trim();
                if (!string.IsNullOrWhiteSpace(trimmed) && !trimmed.StartsWith("#"))
                    filtered.Add(trimmed);
            }
            
            if (filtered.Count < 4)
                throw new FormatException("Файл должен содержать 4 строки: номер метода, функция, границы, точность");

            InputData data = new InputData();

            if (!int.TryParse(filtered[0], out int methodNumber) || methodNumber < 1 || methodNumber > 6)
                throw new FormatException("Первая строка должна содержать число от 1 до 6");
            data.MethodNumber = methodNumber;

            data.FunctionExpression = filtered[1];

            string[] bounds = filtered[2].Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
            if (bounds.Length < 2 || 
                !double.TryParse(bounds[0], out double A) || 
                !double.TryParse(bounds[1], out double B))
                throw new FormatException("Ошибка в границах отрезка");
            
            if (A >= B)
                throw new FormatException("Левая граница должна быть меньше правой");
            
            data.LeftBorder = A;
            data.RightBorder = B;

            if (!double.TryParse(filtered[3], out double Eps) || Eps <= 0)
                throw new FormatException("Ошибка в точности");
            
            data.Accuracy = Eps;
            return data;
        }

        private static void WriteOutputFile(string filename, SolutionResult result, int decimalPlaces)
        {
            using (StreamWriter writer = new StreamWriter(filename))
            {
                writer.WriteLine(result.Root.ToString($"F{decimalPlaces}"));
                writer.WriteLine(result.FunctionValue.ToString("E3"));
                writer.WriteLine(result.AchievedAccuracy.ToString("E3"));
            }
        }
    }
}