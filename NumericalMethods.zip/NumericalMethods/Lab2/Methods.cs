using System;
using System.IO;
using System.Linq;

namespace LinearAlgebraLab2
{
    public class Methods
    {
        private const double Epsilon = 1e-12;

        public void GaussSolveLinearSystem(double[,] A, double[] b, int n, StreamWriter writer)
        {
            if (A == null) throw new ArgumentNullException(nameof(A));
            if (b == null) throw new ArgumentNullException(nameof(b));
            if (writer == null) throw new ArgumentNullException(nameof(writer));

            double[,] a = (double[,])A.Clone();
            double[] bb = (double[])b.Clone();

            writer.WriteLine("\n=== РЕШЕНИЕ СЛАУ МЕТОДОМ ГАУССА ===");

            for (int k = 0; k < n; k++)
            {
                if (Math.Abs(a[k, k]) < Epsilon)
                {
                    writer.WriteLine($"Ошибка: ведущий элемент a[{k},{k}] = {a[k, k]} близок к нулю.");
                    writer.WriteLine("Для решения требуется перестановка строк, но в данной реализации она не выполняется.");
                    return;
                }

                writer.WriteLine($"\n--- Шаг {k + 1} ---");

                double pivot = a[k, k];
                for (int j = k; j < n; j++)
                    a[k, j] /= pivot;
                bb[k] /= pivot;

                for (int i = k + 1; i < n; i++)
                {
                    double factor = a[i, k];
                    if (Math.Abs(factor) < Epsilon) continue;

                    for (int j = k; j < n; j++)
                        a[i, j] -= factor * a[k, j];
                    bb[i] -= factor * bb[k];
                }

                writer.WriteLine($"Матрица A после шага {k + 1}:");
                PrintMatrix(a, writer);
                writer.WriteLine($"Вектор b после шага {k + 1}: {VectorToString(bb)}");
            }

            double[] x = new double[n];
            for (int i = n - 1; i >= 0; i--)
            {
                x[i] = bb[i];
                for (int j = i + 1; j < n; j++)
                    x[i] -= a[i, j] * x[j];
            }

            writer.WriteLine("\n=== РЕЗУЛЬТАТ ===");
            writer.WriteLine("Вектор решения x*:");
            writer.WriteLine(VectorToString(x));

            double[] residual = new double[n];
            for (int i = 0; i < n; i++)
            {
                double sum = 0;
                for (int j = 0; j < n; j++)
                    sum += A[i, j] * x[j];
                residual[i] = sum - b[i];
            }

            writer.WriteLine("\nВектор невязки ε = Ax* - b:");
            writer.WriteLine(VectorToString(residual));

            double norm = Math.Sqrt(residual.Sum(r => r * r));
            writer.WriteLine($"\nНорма вектора невязки ||ε||: {norm:E6}");
        }

        public void GaussFindDeterminant(double[,] A, int n, StreamWriter writer)
        {
            if (A == null) throw new ArgumentNullException(nameof(A));
            if (writer == null) throw new ArgumentNullException(nameof(writer));

            double[,] a = (double[,])A.Clone();
            double det = 1.0;

            writer.WriteLine("\n=== ВЫЧИСЛЕНИЕ ОПРЕДЕЛИТЕЛЯ МЕТОДОМ ГАУССА ===");

            for (int k = 0; k < n; k++)
            {
                if (Math.Abs(a[k, k]) < Epsilon)
                {
                    writer.WriteLine($"Ошибка: ведущий элемент a[{k},{k}] = {a[k, k]} близок к нулю.");
                    writer.WriteLine("Определитель может быть равен 0, либо требуется перестановка строк.");
                    return;
                }

                det *= a[k, k];

                for (int i = k + 1; i < n; i++)
                {
                    double factor = a[i, k] / a[k, k];
                    for (int j = k; j < n; j++)
                        a[i, j] -= factor * a[k, j];
                }

                writer.WriteLine($"\n--- Шаг {k + 1} ---");
                writer.WriteLine($"Ведущий элемент a[{k},{k}] = {a[k, k] + 0.0:F6}");
                writer.WriteLine("Матрица A после исключения элементов под диагональю в столбце k:");
                PrintMatrix(a, writer);
                writer.WriteLine($"Текущее произведение диагональных элементов = {det:F6}");
            }

            writer.WriteLine($"\n=== РЕЗУЛЬТАТ ===");
            writer.WriteLine("Полученная верхнетреугольная матрица:");
            PrintMatrix(a, writer);
            writer.WriteLine($"Определитель матрицы det(A) = {det:F6}");
        }

        public void GaussFindInverseMatrix(double[,] A, int n, StreamWriter writer)
        {
            if (A == null) throw new ArgumentNullException(nameof(A));
            if (writer == null) throw new ArgumentNullException(nameof(writer));

            double[,] a = (double[,])A.Clone();
            double[,] inv = new double[n, n];

            for (int i = 0; i < n; i++)
                inv[i, i] = 1.0;

            writer.WriteLine("\n=== ВЫЧИСЛЕНИЕ ОБРАТНОЙ МАТРИЦЫ МЕТОДОМ ГАУССА-ЖОРДАНА ===");

            for (int k = 0; k < n; k++)
            {
                if (Math.Abs(a[k, k]) < Epsilon)
                {
                    writer.WriteLine($"Ошибка: ведущий элемент a[{k},{k}] = {a[k, k]} близок к нулю.");
                    writer.WriteLine("Матрица может быть вырожденной или требуется перестановка строк.");
                    return;
                }

                writer.WriteLine($"\n--- Шаг {k + 1} ---");

                double pivot = a[k, k];
                for (int j = 0; j < n; j++)
                {
                    a[k, j] /= pivot;
                    inv[k, j] /= pivot;
                }

                for (int i = 0; i < n; i++)
                {
                    if (i == k) continue;

                    double factor = a[i, k];
                    if (Math.Abs(factor) < Epsilon) continue;

                    for (int j = 0; j < n; j++)
                    {
                        a[i, j] -= factor * a[k, j];
                        inv[i, j] -= factor * inv[k, j];
                    }
                }

                writer.WriteLine("Текущее состояние обратной матрицы:");
                PrintMatrix(inv, writer);
            }

            writer.WriteLine("\n=== РЕЗУЛЬТАТ ===");
            writer.WriteLine("Обратная матрица X = A⁻¹:");
            PrintMatrix(inv, writer);

            double[,] check = new double[n, n];
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                    for (int k = 0; k < n; k++)
                        check[i, j] += A[i, k] * inv[k, j];

            writer.WriteLine("Матрица невязки ε = A*X - E:");
            
            double[,] residual = new double[n, n];
            double norm = 0.0;
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    residual[i, j] = check[i, j] - (i == j ? 1 : 0);
                    norm += residual[i, j] * residual[i, j];
                    writer.Write($"{residual[i, j],12:E6} ");
                }
                writer.WriteLine();
            }
            norm = Math.Sqrt(norm);
            
            writer.WriteLine($"\nНорма матрицы невязки ||ε||: {norm:E6}");
        }

        
        public void SimpleIterationSolveLinearSystem(double[,] A, double[] b, int n, 
            double tolerance, int maxIterations, StreamWriter writer)
        {
            // Проверка входных параметров
            if (A == null) throw new ArgumentNullException(nameof(A));
            if (b == null) throw new ArgumentNullException(nameof(b));
            if (writer == null) throw new ArgumentNullException(nameof(writer));

            writer.WriteLine("\n=== РЕШЕНИЕ СЛАУ МЕТОДОМ ПРОСТОЙ ИТЕРАЦИИ ===");
            writer.WriteLine($"Параметры: точность ε = {tolerance:E6}, макс. итераций = {maxIterations}");

            bool hasDiagonalDominance = CheckDiagonalDominance(A, n, writer);
            
            if (!hasDiagonalDominance)
            {
                writer.WriteLine("⚠ ВНИМАНИЕ: Матрица не имеет диагонального преобладания.");
                writer.WriteLine("Метод простой итерации может расходиться или сходиться медленно.");
            }

            for (int i = 0; i < n; i++)
            {
                if (Math.Abs(A[i, i]) < Epsilon)
                {
                    writer.WriteLine($"Ошибка: диагональный элемент A[{i},{i}] = {A[i, i]} близок к нулю.");
                    writer.WriteLine("Метод простой итерации требует ненулевых диагональных элементов.");
                    return;
                }
            }

            double[,] alpha = new double[n, n];
            double[] beta = new double[n];

            for (int i = 0; i < n; i++)
            {
                beta[i] = b[i] / A[i, i];

                for (int j = 0; j < n; j++)
                {
                    if (i != j)
                        alpha[i, j] = -A[i, j] / A[i, i];
                    else
                        alpha[i, j] = 0;
                }
            }

            writer.WriteLine("\nМатрица α (преобразованная система):");
            PrintMatrix(alpha, writer);
            
            double normAlpha = CalculateNorm(alpha, n);
            writer.WriteLine($"Норма матрицы α: {normAlpha:F6}");
            
            if (normAlpha >= 1)
            {
                writer.WriteLine($"⚠ ВНИМАНИЕ: норма матрицы α = {normAlpha:F6} >= 1");
                writer.WriteLine("Достаточное условие сходимости не выполнено.");
            }
            else
            {
                writer.WriteLine($"✓ Норма матрицы α = {normAlpha:F6} < 1 - условие сходимости выполнено.");
            }
            
            writer.WriteLine("\nВектор β:");
            writer.WriteLine(VectorToString(beta));
            writer.WriteLine();

            double[] x = new double[n];
            double[] xPrev = new double[n];
            Array.Copy(beta, x, n);

            writer.WriteLine("Начальное приближение x(0) = β:");
            writer.WriteLine(VectorToString(x));
            writer.WriteLine();

            int iteration = 0;
            double error = double.MaxValue;

            while (iteration < maxIterations && error > tolerance)
            {
                Array.Copy(x, xPrev, n);

                for (int i = 0; i < n; i++)
                {
                    double sum = beta[i];
                    
                    for (int j = 0; j < n; j++)
                        sum += alpha[i, j] * xPrev[j];
                    
                    x[i] = sum;
                }

                iteration++;

                error = 0.0;
                for (int i = 0; i < n; i++)
                {
                    double diff = Math.Abs(x[i] - xPrev[i]);
                    if (diff > error)
                        error = diff;
                }

                double estimatedError = error;
                if (normAlpha < 1 - Epsilon)
                {
                    estimatedError = error * normAlpha / (1 - normAlpha);
                }

                writer.WriteLine($"Итерация {iteration}:");
                writer.WriteLine($"  x = {VectorToString(x)}");
                writer.WriteLine($"  max|x^(k) - x^(k-1)| = {error:E6}");
                writer.WriteLine($"  Оценка погрешности: {estimatedError:E6}");
                writer.WriteLine();
            }

            writer.WriteLine("\n=== РЕЗУЛЬТАТ ===");

            if (iteration >= maxIterations && error > tolerance)
            {
                writer.WriteLine($"Достигнуто максимальное число итераций ({maxIterations})");
                writer.WriteLine($"Достигнутая точность: {error:E6} (требовалось {tolerance:E6})");
            }
            else
            {
                writer.WriteLine($"Сошелся за {iteration} итераций");
                writer.WriteLine($"Достигнутая точность: {error:E6}");
            }

            writer.WriteLine("\nВектор решения x*:");
            writer.WriteLine(VectorToString(x));

            double[] residual = new double[n];
            for (int i = 0; i < n; i++)
            {
                double sum = 0;
                for (int j = 0; j < n; j++)
                    sum += A[i, j] * x[j];
                residual[i] = sum - b[i];
            }

            writer.WriteLine("\nВектор невязки ε = Ax* - b:");
            writer.WriteLine(VectorToString(residual));

            double normResidual = Math.Sqrt(residual.Sum(r => r * r));
            writer.WriteLine($"\nНорма вектора невязки ||ε||: {normResidual:E6}");
            
            writer.WriteLine("\nМатрица α и вектор β для проверки:");
            writer.WriteLine("α =");
            PrintMatrix(alpha, writer);
            writer.WriteLine($"β = {VectorToString(beta)}");
        }


        private bool CheckDiagonalDominance(double[,] A, int n, StreamWriter writer)
        {
            writer.WriteLine("\n--- Проверка условия сходимости (диагональное преобладание) ---");
            writer.WriteLine("Условие: |a_ii| > Σ|a_ij| для j≠i");
            
            bool allDominant = true;
            for (int i = 0; i < n; i++)
            {
                double sum = 0;
                for (int j = 0; j < n; j++)
                {
                    if (i != j)
                        sum += Math.Abs(A[i, j]);
                }
                
                double diag = Math.Abs(A[i, i]);
                bool dominant = diag > sum;
                
                writer.WriteLine($"  Строка {i}: |{A[i, i]}| = {diag:F6} > {sum:F6}? {dominant}");
                
                if (!dominant)
                    allDominant = false;
            }

            if (allDominant)
                writer.WriteLine("  ✓ Все строки имеют диагональное преобладание");
            else
                writer.WriteLine("  ⚠ Не все строки имеют диагональное преобладание");
            
            writer.WriteLine();
            return allDominant;
        }

        private double CalculateNorm(double[,] matrix, int n)
        {
            double maxRowSum = 0;
            
            for (int i = 0; i < n; i++)
            {
                double rowSum = 0;
                for (int j = 0; j < n; j++)
                    rowSum += Math.Abs(matrix[i, j]);
                
                if (rowSum > maxRowSum)
                    maxRowSum = rowSum;
            }
            
            return maxRowSum;
        }

        private void PrintMatrix(double[,] matrix, StreamWriter writer)
        {
            int n = matrix.GetLength(0);
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                    writer.Write($"{matrix[i, j],12:F6} ");
                writer.WriteLine();
            }
        }

        private string VectorToString(double[] v)
        {
            if (v == null) return "";
            return string.Join(" ", v.Select(x => x.ToString("F6")));
        }
    }
}