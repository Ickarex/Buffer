using System;
using System.Globalization;
using System.IO;
using System.Linq;

namespace LinearAlgebraLab2
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputFile = "input.txt";
            string outputFile = "output.txt";

            if (!File.Exists(inputFile))
            {
                Console.WriteLine("Файл input.txt не найден.");
                return;
            }

            try
            {
                string[] lines = File.ReadAllLines(inputFile)
                    .Where(l => !string.IsNullOrWhiteSpace(l))
                    .ToArray();

                int method = int.Parse(lines[0].Trim());
                int m = int.Parse(lines[1].Trim());
                int n = int.Parse(lines[2].Trim());

                double[,] A = new double[n, n];
                double[]? b = (m == 2) ? null : new double[n];

                for (int i = 0; i < n; i++)
                {
                    string line = lines[3 + i].Trim();
                    if (string.IsNullOrEmpty(line))
                    {
                        throw new Exception($"Строка {3 + i} входного файла пуста.");
                    }
                    
                    string[] parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    double[] row = parts.Select(s => double.Parse(s, CultureInfo.InvariantCulture)).ToArray();
                    
                    for (int j = 0; j < n; j++)
                        A[i, j] = row[j];

                    if (m == 1 && row.Length > n && b != null)
                        b[i] = row[n];
                }

                double epsilon = 0.001;
                int maxIterations = 1000;
                
                if (method == 2 && lines.Length > 3 + n)
                {
                    string paramsLine = lines[3 + n].Trim();
                    if (!string.IsNullOrEmpty(paramsLine))
                    {
                        string[] params_line = paramsLine.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                        if (params_line.Length >= 1)
                            epsilon = double.Parse(params_line[0], CultureInfo.InvariantCulture);
                        if (params_line.Length >= 2)
                            maxIterations = int.Parse(params_line[1]);
                    }
                }

                var methods = new Methods();

                using (StreamWriter writer = new StreamWriter(outputFile))
                {
                    writer.WriteLine($"Метод: {(method == 1 ? "Гаусса" : "простой итерации")}");
                    writer.WriteLine($"Тип задачи: m = {m}, порядок матрицы n = {n}");
                    writer.WriteLine("Исходная матрица A:");
                    PrintMatrix(A, writer);

                    if (m == 1 && b != null)
                    {
                        writer.WriteLine("Вектор свободных коэффициентов b:");
                        writer.WriteLine(VectorToString(b));
                        writer.WriteLine();
                    }

                    if (method == 1)
                    {
                        switch (m)
                        {
                            case 1:
                                if (b == null)
                                {
                                    writer.WriteLine("Ошибка: для решения СЛАУ требуется вектор свободных коэффициентов.");
                                    break;
                                }
                                methods.GaussSolveLinearSystem(A, b, n, writer);
                                break;
                            case 2:
                                methods.GaussFindDeterminant(A, n, writer);
                                break;
                            case 3:
                                methods.GaussFindInverseMatrix(A, n, writer);
                                break;
                            default:
                                writer.WriteLine("Ошибка: неизвестный тип задачи m.");
                                break;
                        }
                    }
                    else if (method == 2)
                    {
                        if (m != 1)
                        {
                            writer.WriteLine("Метод простой итерации применим только для решения СЛАУ (m = 1)");
                            return;
                        }

                        if (b == null)
                        {
                            writer.WriteLine("Ошибка: для метода простой итерации требуется вектор свободных коэффициентов.");
                            return;
                        }

                        methods.SimpleIterationSolveLinearSystem(A, b, n, epsilon, maxIterations, writer);
                    }
                }

                Console.WriteLine("Результат записан в файл output.txt");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }
        }

        static void PrintMatrix(double[,] matrix, StreamWriter writer)
        {
            int n = matrix.GetLength(0);
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                    writer.Write($"{matrix[i, j],12:F6} ");
                writer.WriteLine();
            }
            writer.WriteLine();
        }

        static string VectorToString(double[] v)
        {
            if (v == null) return "";
            return string.Join(" ", v.Select(x => x.ToString("F6")));
        }
    }
}