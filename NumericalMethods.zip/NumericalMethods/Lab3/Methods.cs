using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace CalculatingEigenvaluesEigenvectors
{
    public class Methods
    {
        private const double Epsilon = 1e-12;
        private double[,]? transformationS;

        public void FindEigenvalues(double[,] A, int n, StreamWriter writer)
        {
            writer.WriteLine("=== РЕЗУЛЬТАТЫ РАСЧЕТА (ТИП 1: СОБСТВЕННЫЕ ЧИСЛА) ===");
            
            double[] pCoeffs = ReduceToFrobenius(A, n, writer);
            
            writer.WriteLine("P – МАТРИЦА ФРОБЕНИУСА:");
            PrintMatrix(BuildFrobeniusMatrixFromCoeffs(pCoeffs, n), writer);

            writer.WriteLine("ХАРАКТЕРИСТИЧЕСКИЙ ПОЛИНОМ:");
            PrintFrobeniusEquation(pCoeffs, n, writer);

            double[] roots = FindAllRoots(pCoeffs, n, writer);
            var clusters = ClusterEigenvalues(roots);

            writer.WriteLine("\nСПИСОК СОБСТВЕННЫХ ЧИСЕЛ:");
            int i = 1;
            foreach (var cluster in clusters)
            {
                double lambda = cluster.Key;
                double det = CalculateDeterminantCheck(A, lambda, n);
                
                writer.WriteLine($"i = {i}");
                writer.WriteLine($"  λi = {lambda:F10}");
                writer.WriteLine($"  ki = {cluster.Value}");
                writer.WriteLine($"  |A - λiE| = {det:E4}");
                writer.WriteLine(new string('-', 30));
                i++;
            }
        }

        public void FindEigenvectors(double[,] A, int n, StreamWriter writer)
        {
            writer.WriteLine("=== РЕЗУЛЬТАТЫ РАСЧЕТА (ТИП 2: СОБСТВЕННЫЕ ВЕКТОРЫ) ===");
            
            double[] pCoeffs = ReduceToFrobenius(A, n, writer);
            double[] roots = FindAllRoots(pCoeffs, n, writer);
            var clusters = ClusterEigenvalues(roots);

            writer.WriteLine("\nСПИСОК СОБСТВЕННЫХ ВЕКТОРОВ:");
            int idx = 1;
            foreach (var cluster in clusters)
            {
                double lambda = cluster.Key;
                double[] y = new double[n];
                for (int i = 0; i < n; i++) y[i] = Math.Pow(lambda, n - 1 - i);

                double[] x = MultiplyMatrixVector(transformationS!, y, n);

                double maxVal = x.Max(Math.Abs);
                if (maxVal > Epsilon) for (int i = 0; i < n; i++) x[i] /= maxVal;

                writer.WriteLine($"i = {idx} (λ = {lambda:F6}, k = {cluster.Value})");
                writer.WriteLine("  xi (собственный вектор):");
                writer.Write("      ");
                PrintVectorLine(x, writer);

                writer.WriteLine("  Axi - λixi (проверка невязки):");
                writer.Write("      ");
                VerifyVectorResidual(A, x, lambda, n, writer);
                writer.WriteLine(new string('-', 40));
                idx++;
            }
        }

        private double[] ReduceToFrobenius(double[,] A, int n, StreamWriter writer)
        {
            double[,] P = (double[,])A.Clone();
            transformationS = CreateIdentityMatrix(n);

            writer.WriteLine("ПОШАГОВОЕ ПРИВЕДЕНИЕ К ФОРМЕ ФРОБЕНИУСА:");

            for (int k = n - 2; k >= 0; k--)
            {
                writer.WriteLine($"\n--- ШАГ { (n - 2) - k + 1 } ---");
                
                if (Math.Abs(P[k + 1, k]) < 1e-10)
                {
                    if (!TrySwap(P, k, n, writer)) {
                        writer.WriteLine("Внимание: деление на 0 невозможно. Особенный случай.");
                        continue;
                    }
                }

                double pivot = P[k + 1, k];
                double[,] M = CreateIdentityMatrix(n);
                double[,] M_inv = CreateIdentityMatrix(n);

                for (int j = 0; j < n; j++)
                {
                    M[k, j] = (j == k) ? (1.0 / pivot) : (-P[k + 1, j] / pivot);
                    M_inv[k, j] = P[k + 1, j];
                }

                writer.WriteLine($"Матрица M_{k+1}:");
                PrintMatrix(M, writer);
                writer.WriteLine($"Обратная матрица M_{k+1}^-1:");
                PrintMatrix(M_inv, writer);

                transformationS = MultiplyMatrices(transformationS, M, n);
                
                double[,] temp = MultiplyMatrices(M_inv, P, n);
                P = MultiplyMatrices(temp, M, n);

                writer.WriteLine("Текущая матрица P:");
                PrintMatrix(P, writer);
            }

            double[] coeffs = new double[n];
            for (int j = 0; j < n; j++) coeffs[j] = P[0, j];
            return coeffs;
        }

        private double CalculateDeterminantCheck(double[,] A, double lambda, int n)
        {
            double[,] matrix = (double[,])A.Clone();
            for (int i = 0; i < n; i++) matrix[i, i] -= lambda;

            double det = 1.0;
            for (int i = 0; i < n; i++)
            {
                int pivot = i;
                for (int j = i + 1; j < n; j++)
                    if (Math.Abs(matrix[j, i]) > Math.Abs(matrix[pivot, i])) pivot = j;
                
                if (pivot != i)
                {
                    for (int j = 0; j < n; j++) (matrix[i, j], matrix[pivot, j]) = (matrix[pivot, j], matrix[i, j]);
                    det *= -1;
                }
                if (Math.Abs(matrix[i, i]) < 1e-18) return 0;
                det *= matrix[i, i];
                for (int j = i + 1; j < n; j++)
                {
                    double f = matrix[j, i] / matrix[i, i];
                    for (int k = i + 1; k < n; k++) matrix[j, k] -= f * matrix[i, k];
                }
            }
            return det;
        }

        private double[] FindAllRoots(double[] p, int n, StreamWriter writer)
        {
            double[] roots = new double[n];
            double[] curP = (double[])p.Clone();
            for (int i = 0; i < n; i++)
            {
                double x = 1.0;
                for (int iter = 0; iter < 100; iter++)
                {
                    (double f, double df) = Horner(curP, x, n - i);
                    if (Math.Abs(df) < 1e-20) { x += 0.1; continue; }
                    double dx = f / df;
                    x -= dx;
                    if (Math.Abs(dx) < 1e-12) break;
                }
                roots[i] = x;
                curP = Deflate(curP, x, n - i);
            }
            return roots;
        }

        private (double f, double df) Horner(double[] p, double x, int deg)
        {
            double f = 1.0, df = 0.0;
            for (int i = 0; i < deg; i++) { df = df * x + f; f = f * x - p[i]; }
            return (f, df);
        }

        private double[] Deflate(double[] p, double root, int deg)
        {
            double[] newP = new double[deg - 1];
            double res = 1.0;
            for (int i = 0; i < deg - 1; i++) { res = res * root - p[i]; newP[i] = -res; }
            return newP;
        }

        private Dictionary<double, int> ClusterEigenvalues(double[] roots)
        {
            var res = new Dictionary<double, int>();
            foreach (var r in roots.OrderBy(x => x))
            {
                var key = res.Keys.Cast<double?>().FirstOrDefault(k => Math.Abs(k!.Value - r) < 1e-5);
                if (key != null) res[key.Value]++;
                else res[r] = 1;
            }
            return res;
        }

        private void PrintMatrix(double[,] matrix, StreamWriter writer)
        {
            int n = matrix.GetLength(0);
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++)
                    writer.Write($"{ (Math.Abs(matrix[i, j]) < 1e-11 ? 0 : matrix[i, j]), 12:F6} ");
                writer.WriteLine();
            }
        }

        private void PrintVectorLine(double[] v, StreamWriter writer) =>
            writer.WriteLine("(" + string.Join("; ", v.Select(x => x.ToString("F8"))) + ")");

        private void VerifyVectorResidual(double[,] A, double[] x, double lambda, int n, StreamWriter writer)
        {
            double[] Ax = MultiplyMatrixVector(A, x, n);
            double[] res = new double[n];
            for (int i = 0; i < n; i++) res[i] = Ax[i] - lambda * x[i];
            writer.WriteLine("(" + string.Join("; ", res.Select(v => v.ToString("E2"))) + ")");
        }

        private double[,] BuildFrobeniusMatrixFromCoeffs(double[] p, int n)
        {
            double[,] P = new double[n, n];
            for (int j = 0; j < n; j++) P[0, j] = p[j];
            for (int i = 1; i < n; i++) P[i, i - 1] = 1.0;
            return P;
        }

        private void PrintFrobeniusEquation(double[] p, int n, StreamWriter writer)
        {
            writer.Write($"D(λ) = λ^{n}");
            for (int i = 0; i < n; i++)
                writer.Write($" {(p[i] >= 0 ? "-" : "+")} {Math.Abs(p[i]):F4}λ^{n - 1 - i}");
            writer.WriteLine(" = 0\n");
        }

        private double[,] CreateIdentityMatrix(int n)
        {
            double[,] I = new double[n, n];
            for (int i = 0; i < n; i++) I[i, i] = 1.0;
            return I;
        }

        private double[,] MultiplyMatrices(double[,] A, double[,] B, int n)
        {
            double[,] C = new double[n, n];
            for (int i = 0; i < n; i++)
                for (int k = 0; k < n; k++)
                    if (Math.Abs(A[i, k]) > 1e-18)
                        for (int j = 0; j < n; j++)
                            C[i, j] += A[i, k] * B[k, j];
            return C;
        }

        private double[] MultiplyMatrixVector(double[,] A, double[] v, int n)
        {
            double[] res = new double[n];
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                    res[i] += A[i, j] * v[j];
            return res;
        }

        private bool TrySwap(double[,] P, int k, int n, StreamWriter writer)
        {
            for (int j = k - 1; j >= 0; j--)
            {
                if (Math.Abs(P[k + 1, j]) > 1e-10)
                {
                    writer.WriteLine($"Перестановка строк и столбцов {k} и {j}");
                    for (int i = 0; i < n; i++) (P[i, k], P[i, j]) = (P[i, j], P[i, k]);
                    for (int i = 0; i < n; i++) (P[k, i], P[j, i]) = (P[j, i], P[k, i]);
                    return true;
                }
            }
            return false;
        }
    }
}