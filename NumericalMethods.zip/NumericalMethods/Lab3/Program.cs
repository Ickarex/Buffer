using System;
using System.Globalization;
using System.IO;
using System.Linq;

namespace CalculatingEigenvaluesEigenvectors
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputFile = "input.txt";
            string outputFile = "output.txt";

            if (!File.Exists(inputFile))
            {
                Console.WriteLine("Файл input.txt не найден.");
                return;
            }

            try
            {
                string[] lines = File.ReadAllLines(inputFile)
                    .Where(l => !string.IsNullOrWhiteSpace(l))
                    .ToArray();

                int m = int.Parse(lines[0].Trim());  // тип задачи (1 - числа, 2 - векторы)
                int n = int.Parse(lines[1].Trim());  // порядок матрицы

                double[,] A = new double[n, n];

                for (int i = 0; i < n; i++)
                {
                    string line = lines[2 + i].Trim();
                    if (string.IsNullOrEmpty(line))
                    {
                        throw new Exception($"Строка {2 + i} входного файла пуста.");
                    }

                    string[] parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    double[] row = parts.Select(s => double.Parse(s, CultureInfo.InvariantCulture)).ToArray();

                    for (int j = 0; j < n; j++)
                        A[i, j] = row[j];
                }

                var methods = new Methods();

                using (StreamWriter writer = new StreamWriter(outputFile))
                {
                    writer.WriteLine($"Тип задачи: {(m == 1 ? "поиск собственных чисел" : "поиск собственных векторов")}");
                    writer.WriteLine($"Порядок матрицы n = {n}");
                    writer.WriteLine("Исходная матрица A:");
                    PrintMatrix(A, writer);
                    writer.WriteLine();

                    if (m == 1)
                    {
                        methods.FindEigenvalues(A, n, writer);
                    }
                    else if (m == 2)
                    {
                        methods.FindEigenvectors(A, n, writer);
                    }
                    else
                    {
                        writer.WriteLine("Ошибка: неизвестный тип задачи m (должен быть 1 или 2).");
                    }
                }

                Console.WriteLine("Результат записан в файл output.txt");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }
        }

        static void PrintMatrix(double[,] matrix, StreamWriter writer)
        {
            int n = matrix.GetLength(0);
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                    writer.Write($"{matrix[i, j],12:F6} ");
                writer.WriteLine();
            }
            writer.WriteLine();
        }
    }
}