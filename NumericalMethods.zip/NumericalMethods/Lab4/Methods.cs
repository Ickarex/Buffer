using System;
using System.IO;
using System.Linq;

namespace SolvingNonlinearEquations
{
    public class Methods
    {
        private const int MaxIterations = 100;
        private const double H = 1e-7;

        // ВЫБОР СИСТЕМЫ УРАВНЕНИЙ В ЗАВИСИМОСТИ ОТ НОМЕРА МЕТОДА
        private double[] EvaluateF(double[] x, int methodType)
        {
            switch (methodType)
            {
                case 1: // Пример для метода Ньютона (Окружность и прямая)
                    return new double[] {
                        x[0] * x[0] + x[1] * x[1] - 2.0,
                        x[0] - x[1]
                    };
                case 2: // Пример для метода итераций (Параболы)
                    return new double[] {
                        x[0] * x[0] + x[1] - 1.0,
                        x[0] + x[1] * x[1] - 1.0
                    };
                case 3: // Пример для метода спуска (Тригонометрия)
                    return new double[] {
                        Math.Sin(x[0]) - x[1] + 1.0,
                        x[0] + Math.Cos(x[1]) - 1.5
                    };
                default:
                    return new double[x.Length];
            }
        }

        public void SolveSystem(int m, int n, double[] x0, double eps, string[] funcStrings, StreamWriter writer)
        {
            double[] x = (double[])x0.Clone();
            writer.WriteLine($"ПОШАГОВОЕ ВЫПОЛНЕНИЕ ({GetMethodName(m)}):");

            bool converged = false;
            for (int k = 0; k <= MaxIterations; k++)
            {
                double[] f = EvaluateF(x, m);
                double normF = CalculateNorm(f);

                writer.WriteLine($"Итерация k = {k}:");
                writer.WriteLine($"  x(k) = ({string.Join("; ", x.Select(val => val.ToString("F6")))})");

                if (normF < eps)
                {
                    converged = true;
                    PrintFinalResult(x, f, normF, funcStrings, writer);
                    break;
                }

                // Передаем номер метода 'm' в вычислительные блоки
                if (m == 1) x = NextNewton(x, n, m);
                else if (m == 2) x = NextIteration(x, x0, n, m);
                else x = NextDescent(x, n, m);
            }

            if (!converged) writer.WriteLine("ВНИМАНИЕ: Решение не сошлось.");
        }

        // --- Вспомогательные методы с учетом типа системы ---

        private double[] NextNewton(double[] x, int n, int m)
        {
            double[,] W = EvaluateJacobian(x, n, m);
            double[] f = EvaluateF(x, m);
            double[] dx = SolveLinearSystem(W, f, n);
            double[] nextX = new double[n];
            for (int i = 0; i < n; i++) nextX[i] = x[i] - dx[i];
            return nextX;
        }

        private double[] NextIteration(double[] x, double[] x0, int n, int m)
        {
            double[,] W0_inv = InvertMatrix(EvaluateJacobian(x0, n, m), n);
            double[] f = EvaluateF(x, m);
            double[] dx = MultiplyMatrixVector(W0_inv, f, n);
            double[] nextX = new double[n];
            for (int i = 0; i < n; i++) nextX[i] = x[i] - dx[i];
            return nextX;
        }

        private double[] NextDescent(double[] x, int n, int m)
        {
            double[] f = EvaluateF(x, m);
            double[,] W = EvaluateJacobian(x, n, m);
            double[] gradU = new double[n];
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++) gradU[i] += 2 * W[j, i] * f[j];

            double[] W_grad = MultiplyMatrixVector(W, gradU, n);
            double denom = W_grad.Sum(v => v * v);
            double U = f.Sum(v => v * v);
            double lambda = (denom > 1e-20) ? U / denom : 0.01;

            double[] nextX = new double[n];
            for (int i = 0; i < n; i++) nextX[i] = x[i] - lambda * gradU[i];
            return nextX;
        }

        private double[,] EvaluateJacobian(double[] x, int n, int m)
        {
            double[,] J = new double[n, n];
            for (int j = 0; j < n; j++)
            {
                double[] xP = (double[])x.Clone(); xP[j] += H;
                double[] xM = (double[])x.Clone(); xM[j] -= H;
                double[] fP = EvaluateF(xP, m); double[] fM = EvaluateF(xM, m);
                for (int i = 0; i < n; i++) J[i, j] = (fP[i] - fM[i]) / (2 * H);
            }
            return J;
        }

        // ... (Остальные методы: SolveLinearSystem, InvertMatrix, MultiplyMatrixVector, CalculateNorm остаются без изменений)
        private double[] SolveLinearSystem(double[,] A, double[] b, int n)
        {
            for (int i = 0; i < n; i++)
            {
                for (int j = i + 1; j < n; j++)
                {
                    double mult = A[j, i] / A[i, i];
                    for (int k = i; k < n; k++) A[j, k] -= mult * A[i, k];
                    b[j] -= mult * b[i];
                }
            }
            double[] res = new double[n];
            for (int i = n - 1; i >= 0; i--)
            {
                double s = 0;
                for (int j = i + 1; j < n; j++) s += A[i, j] * res[j];
                res[i] = (b[i] - s) / A[i, i];
            }
            return res;
        }

        private double[,] InvertMatrix(double[,] A, int n)
        {
            double[,] inv = new double[n, n];
            for (int i = 0; i < n; i++)
            {
                double[] e = new double[n]; e[i] = 1;
                double[] col = SolveLinearSystem((double[,])A.Clone(), e, n);
                for (int j = 0; j < n; j++) inv[j, i] = col[j];
            }
            return inv;
        }

        private double[] MultiplyMatrixVector(double[,] A, double[] v, int n)
        {
            double[] r = new double[n];
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++) r[i] += A[i, j] * v[j];
            return r;
        }

        private double CalculateNorm(double[] v) => Math.Sqrt(v.Sum(x => x * x));
        private string GetMethodName(int m) => m switch { 1 => "Метод Ньютона", 2 => "Метод итераций", 3 => "Метод наискорейшего спуска", _ => "" };

        private void PrintFinalResult(double[] x, double[] f, double normF, string[] funcs, StreamWriter writer)
        {
            writer.WriteLine(new string('-', 40));
            writer.WriteLine("РЕЗУЛЬТАТ:");
            writer.WriteLine("Система нелинейных уравнений:");
            foreach (var s in funcs) writer.WriteLine($"  {s} = 0");
            writer.WriteLine();
            writer.WriteLine($"  x* (решение) = ({string.Join("; ", x.Select(v => v.ToString("F6")))})");
            writer.WriteLine($"  ε* (вектор невязки) = ({string.Join("; ", f.Select(v => v.ToString("F6")))})");
            writer.WriteLine($"  ||ε*|| (норма невязки) = {normF:E4}");
            writer.WriteLine(new string('-', 40));
        }
    }
}