using System;
using System.Globalization;
using System.IO;
using System.Linq;

namespace SolvingNonlinearEquations
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputFile = "input.txt";
            string outputFile = "output.txt";

            if (!File.Exists(inputFile)) return;

            try
            {
                string[] lines = File.ReadAllLines(inputFile).Where(l => !string.IsNullOrWhiteSpace(l)).ToArray();

                int m = int.Parse(lines[0].Trim()); 
                int n = int.Parse(lines[1].Trim());
                double[] x0 = lines[2].Split(' ', StringSplitOptions.RemoveEmptyEntries)
                                      .Select(s => double.Parse(s, CultureInfo.InvariantCulture)).ToArray();
                double eps = double.Parse(lines[3].Trim(), CultureInfo.InvariantCulture);

                string[] functions = new string[n];
                for (int i = 0; i < n; i++) functions[i] = lines[4 + i].Trim();

                var methods = new Methods();

                using (StreamWriter writer = new StreamWriter(outputFile))
                {
                    writer.WriteLine($"=== РЕШЕНИЕ СИСТЕМ НЕЛИНЕЙНЫХ УРАВНЕНИЙ ===");
                    writer.WriteLine($"Метод: {GetMethodName(m)}");
                    writer.WriteLine($"Размерность n = {n}");
                    writer.WriteLine($"Требуемая погрешность ε = {eps:E2}");
                    writer.WriteLine();

                    methods.SolveSystem(m, n, x0, eps, functions, writer);
                }
                Console.WriteLine("Готово! Проверьте output.txt");
            }
            catch (Exception ex) { Console.WriteLine($"Ошибка: {ex.Message}"); }
        }

        static string GetMethodName(int m) => m switch { 1 => "Метод Ньютона", 2 => "Метод итераций", 3 => "Метод наискорейшего спуска", _ => "Неизвестный" };
    }
}