using System;
using System.IO;

namespace SolvingInterpolationNewton
{
    public class Methods
    {
        public void SolveNewton(int k, int n, double[] x, double[] y, int m, double[] rx, bool isKnown, string funcName, StreamWriter writer)
        {
            // 1. Построение таблицы разделенных разностей
            double[] divDiff = CalculateDividedDifferences(x, y, n);

            double[] results = new double[m + 1];

            writer.WriteLine("x_i    P^(k)(x_i)");
            writer.WriteLine(new string('-', 25));

            // 2. Вычисление значений для результирующей сетки
            for (int i = 0; i <= m; i++)
            {
                double targetX = rx[i];
                double val = 0;

                if (k == 0) val = EvalPolynomial(x, divDiff, n, targetX);
                else if (k == 1) val = EvalFirstDerivative(x, divDiff, n, targetX);
                else if (k == 2) val = EvalSecondDerivative(x, divDiff, n, targetX);

                results[i] = val;
                writer.WriteLine($"{targetX,-6:F3} {val:F6}");
            }

            // 3. Вычисление СКО, если функция известна
            if (isKnown)
            {
                double sko = CalculateRMS(rx, results, m, funcName, k);
                writer.WriteLine(new string('-', 25));
                writer.WriteLine($"СКО (ε): {sko:E4}");
            }
        }

        // Вычисление коэффициентов [x_0, ..., x_i]
        private double[] CalculateDividedDifferences(double[] x, double[] y, int n)
        {
            double[,] f = new double[n + 1, n + 1];
            for (int i = 0; i <= n; i++) f[i, 0] = y[i];

            for (int j = 1; j <= n; j++)
            {
                for (int i = 0; i <= n - j; i++)
                {
                    f[i, j] = (f[i + 1, j - 1] - f[i, j - 1]) / (x[i + j] - x[i]);
                }
            }

            double[] coefs = new double[n + 1];
            for (int i = 0; i <= n; i++) coefs[i] = f[0, i];

            return coefs;
        }

        // Вычисление самого полинома Ньютона (k = 0)
        private double EvalPolynomial(double[] x, double[] coefs, int n, double targetX)
        {
            double result = coefs[0];
            double product = 1.0;

            for (int i = 1; i <= n; i++)
            {
                product *= (targetX - x[i - 1]);
                result += coefs[i] * product;
            }
            return result;
        }

        // Первая производная (k = 1)
        private double EvalFirstDerivative(double[] x, double[] coefs, int n, double targetX)
        {
            double result = 0;

            for (int i = 1; i <= n; i++)
            {
                double sum = 0;
                for (int j = 0; j < i; j++)
                {
                    double product = 1.0;
                    for (int l = 0; l < i; l++)
                    {
                        if (l != j) product *= (targetX - x[l]);
                    }
                    sum += product;
                }
                result += coefs[i] * sum;
            }
            return result;
        }

        // Вторая производная (k = 2)
        private double EvalSecondDerivative(double[] x, double[] coefs, int n, double targetX)
        {
            double result = 0;

            for (int i = 2; i <= n; i++)
            {
                double sumOuter = 0;
                for (int j = 0; j < i; j++)
                {
                    for (int l = 0; l < i; l++)
                    {
                        if (j == l) continue;
                        double product = 1.0;
                        for (int p = 0; p < i; p++)
                        {
                            if (p != j && p != l) product *= (targetX - x[p]);
                        }
                        sumOuter += product;
                    }
                }
                result += coefs[i] * sumOuter;
            }
            return result;
        }

        private double CalculateRMS(double[] rx, double[] results, int m, string funcName, int k)
        {
            double sum = 0;

            for (int i = 0; i <= m; i++)
            {
                double exact = EvaluateAnalytical(rx[i], funcName, k);

                sum += Math.Pow(exact - results[i], 2); 
            }

            return (1.0 / m) * Math.Sqrt(sum); 
        }

        private double EvaluateAnalytical(double x, string funcName, int k)
        {
            if (funcName.Contains("sin"))
            {
                if (k == 0) return Math.Sin(x);
                if (k == 1) return Math.Cos(x);
                if (k == 2) return -Math.Sin(x);
            }
            // Наша новая идеальная функция
            else if (funcName.Contains("x^3"))
            {
                if (k == 0) return Math.Pow(x, 3) - 2 * x * x;
                if (k == 1) return 3 * x * x - 4 * x;
                if (k == 2) return 6 * x - 4;
            }
            return 0;
        }
    }
}