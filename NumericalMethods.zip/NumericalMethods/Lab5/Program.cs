using System;
using System.Globalization;
using System.IO;
using System.Linq;

namespace SolvingInterpolationNewton
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputFile = "input.txt";
            string outputFile = "output.txt";

            if (!File.Exists(inputFile))
            {
                Console.WriteLine($"Файл {inputFile} не найден.");
                return;
            }

            try
            {
                string[] lines = File.ReadAllLines(inputFile)
                                     .Where(l => !string.IsNullOrWhiteSpace(l) && !l.StartsWith("//"))
                                     .ToArray();

                int idx = 0;
                int k = int.Parse(lines[idx++].Trim()); 
                int n = int.Parse(lines[idx++].Trim()); 
                string gridType = lines[idx++].Trim().ToLower();

                double[] x = new double[n + 1];
                if (gridType == "равномерная")
                {
                    var ab = lines[idx++].Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    double a = double.Parse(ab[0], CultureInfo.InvariantCulture);
                    double b = double.Parse(ab[1], CultureInfo.InvariantCulture);
                    double h = (b - a) / n;
                    for (int i = 0; i <= n; i++) x[i] = a + i * h;
                }
                else 
                {
                    x = lines[idx++].Split(' ', StringSplitOptions.RemoveEmptyEntries)
                                    .Select(s => double.Parse(s, CultureInfo.InvariantCulture)).ToArray();
                }

                double[] y = lines[idx++].Split(' ', StringSplitOptions.RemoveEmptyEntries)
                                        .Select(s => double.Parse(s, CultureInfo.InvariantCulture)).ToArray();

                int m = int.Parse(lines[idx++].Trim()); 
                double[] rx = lines[idx++].Split(' ', StringSplitOptions.RemoveEmptyEntries)
                                          .Select(s => double.Parse(s, CultureInfo.InvariantCulture)).ToArray();

                string isKnownStr = lines[idx++].Trim().ToLower();
                bool isAnalyticalKnown = (isKnownStr == "известно");
                string analyticalFunc = isAnalyticalKnown ? lines[idx++].Trim() : "";

                var methods = new Methods();

                using (StreamWriter writer = new StreamWriter(outputFile))
                {
                    writer.WriteLine("=== ИНТЕРПОЛИРОВАНИЕ И ЧИСЛЕННОЕ ДИФФЕРЕНЦИРОВАНИЕ (НЬЮТОН) ===");
                    writer.WriteLine($"Тип сетки: {gridType}");
                    writer.WriteLine($"Вычисляется: {(k == 0 ? "Сам полином" : (k == 1 ? "Первая производная" : "Вторая производная"))}");
                    writer.WriteLine();

                    methods.SolveNewton(k, n, x, y, m, rx, isAnalyticalKnown, analyticalFunc, writer);
                }
                Console.WriteLine("Готово! Проверьте файл output.txt");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }
        }
    }
}