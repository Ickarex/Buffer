using System;
using System.IO;

namespace SolvingSplines
{
    public class Methods
    {
        public void SolveSplines(int k, int n, double[] x, double[] y, int bIdx, double bVal1, double bVal2, int m, double[] rx, bool isKnown, string funcName, StreamWriter writer)
        {
            double[] a = new double[n];
            double[] b = new double[n];
            double[] c = new double[n];
            double[] d = new double[n];

            // Массивы шагов
            double[] dx = new double[n];
            double[] dy = new double[n];
            for (int i = 0; i < n; i++)
            {
                dx[i] = x[i + 1] - x[i];
                dy[i] = y[i + 1] - y[i];
            }

            if (k == 1)
            {
                for (int i = 0; i < n; i++)
                {
                    a[i] = y[i];
                    b[i] = dy[i] / dx[i];
                }
            }
            else if (k == 2)
            {
                double[] B = new double[n + 1];
                if (bIdx == 0)
                {
                    B[0] = bVal1;
                    for (int i = 0; i < n; i++) B[i + 1] = 2.0 * dy[i] / dx[i] - B[i];
                }
                else
                {
                    B[n] = bVal1;
                    for (int i = n - 1; i >= 0; i--) B[i] = 2.0 * dy[i] / dx[i] - B[i + 1];
                }

                for (int i = 0; i < n; i++)
                {
                    a[i] = y[i];
                    b[i] = B[i];
                    c[i] = (B[i + 1] - B[i]) / (2.0 * dx[i]);
                }
            }
            else if (k == 3)
            {
                double[] M = new double[n + 1];
                M[0] = bVal1;
                M[n] = bVal2;

                if (n > 1)
                {
                    // Метод прогонки для M_1 ... M_{n-1}
                    int N = n - 1;
                    double[] A = new double[N]; // нижняя диагональ
                    double[] B_diag = new double[N]; // главная диагональ
                    double[] C = new double[N]; // верхняя диагональ
                    double[] D = new double[N]; // правая часть

                    for (int i = 0; i < N; i++)
                    {
                        B_diag[i] = (dx[i] + dx[i + 1]) / 3.0;
                        if (i < N - 1) C[i] = dx[i + 1] / 6.0;
                        if (i > 0) A[i] = dx[i] / 6.0;
                        
                        D[i] = dy[i + 1] / dx[i + 1] - dy[i] / dx[i];
                    }

                    // Перенос граничных условий в правую часть
                    D[0] -= (dx[0] / 6.0) * M[0];
                    D[N - 1] -= (dx[n - 1] / 6.0) * M[n];

                    // Прямой ход прогонки
                    double[] c_star = new double[N];
                    double[] d_star = new double[N];
                    c_star[0] = C[0] / B_diag[0];
                    d_star[0] = D[0] / B_diag[0];

                    for (int i = 1; i < N; i++)
                    {
                        double m_val = 1.0 / (B_diag[i] - A[i] * c_star[i - 1]);
                        c_star[i] = C[i] * m_val;
                        d_star[i] = (D[i] - A[i] * d_star[i - 1]) * m_val;
                    }

                    // Обратный ход прогонки
                    M[N] = d_star[N - 1]; // это M_{n-1}
                    for (int i = N - 2; i >= 0; i--)
                    {
                        M[i + 1] = d_star[i] - c_star[i] * M[i + 2];
                    }
                }

                // Расчет коэффициентов
                for (int i = 0; i < n; i++)
                {
                    a[i] = y[i];
                    c[i] = M[i] / 2.0;
                    d[i] = (M[i + 1] - M[i]) / (6.0 * dx[i]);
                    b[i] = dy[i] / dx[i] - dx[i] * (2.0 * M[i] + M[i + 1]) / 6.0;
                }
            }

            // Вывод коэффициентов
            writer.WriteLine("Коэффициенты сплайнов (a_i, b_i, c_i, d_i):");
            writer.WriteLine(new string('-', 45));
            for (int i = 0; i < n; i++)
            {
                if (k == 1) writer.WriteLine($"i={i}: {a[i],8:F4} {b[i],8:F4}");
                else if (k == 2) writer.WriteLine($"i={i}: {a[i],8:F4} {b[i],8:F4} {c[i],8:F4}");
                else writer.WriteLine($"i={i}: {a[i],8:F4} {b[i],8:F4} {c[i],8:F4} {d[i],8:F4}");
            }
            writer.WriteLine();

            // Расчет значений в результирующей сетке
            writer.WriteLine("Значения сплайна S(x):");
            writer.WriteLine("x_i      S(x_i)");
            writer.WriteLine(new string('-', 20));

            double[] results = new double[m + 1];
            for (int j = 0; j <= m; j++)
            {
                double targetX = rx[j];
                
                // Поиск нужного интервала (сплайна)
                int splIdx = 0;
                for (int i = 0; i < n; i++)
                {
                    if (targetX >= x[i] && targetX <= x[i + 1])
                    {
                        splIdx = i;
                        break;
                    }
                }
                if (targetX > x[n]) splIdx = n - 1; // экстраполяция
                if (targetX < x[0]) splIdx = 0;

                double diff = targetX - x[splIdx];
                double val = a[splIdx] + b[splIdx] * diff + c[splIdx] * diff * diff + d[splIdx] * diff * diff * diff;

                results[j] = val;
                writer.WriteLine($"{targetX,-6:F3}   {val:F6}");
            }

            // СКО
            if (isKnown)
            {
                double sum = 0;
                for (int j = 0; j <= m; j++)
                {
                    double exact = EvaluateAnalytical(rx[j], funcName);
                    sum += (results[j] - exact) * (results[j] - exact);
                }
                double sko = Math.Sqrt(sum) / (m + 1);
                writer.WriteLine(new string('-', 20));
                writer.WriteLine($"СКО (ε): {sko:E4}");
            }
        }

        private double EvaluateAnalytical(double x, string funcName)
        {
            if (funcName.Contains("sin")) return Math.Sin(x);
            if (funcName.Contains("cos")) return Math.Cos(x);
            return 0;
        }
    }
}