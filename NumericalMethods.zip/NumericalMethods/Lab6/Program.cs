using System;
using System.Globalization;
using System.IO;
using System.Linq;

namespace SolvingSplines
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputFile = "input.txt";
            string outputFile = "output.txt";

            if (!File.Exists(inputFile))
            {
                Console.WriteLine($"Файл {inputFile} не найден.");
                return;
            }

            try
            {
                string[] lines = File.ReadAllLines(inputFile)
                                     .Where(l => !string.IsNullOrWhiteSpace(l) && !l.StartsWith("//"))
                                     .ToArray();

                int idx = 0;
                int k = int.Parse(lines[idx++].Trim()); // Порядок сплайна (1, 2, 3)
                int n = int.Parse(lines[idx++].Trim()); // Количество сплайнов

                double[] x = lines[idx++].Split(' ', StringSplitOptions.RemoveEmptyEntries)
                                         .Select(s => double.Parse(s, CultureInfo.InvariantCulture)).ToArray();
                double[] y = lines[idx++].Split(' ', StringSplitOptions.RemoveEmptyEntries)
                                         .Select(s => double.Parse(s, CultureInfo.InvariantCulture)).ToArray();

                // Чтение граничных условий
                int boundIndex = 0;
                double boundVal1 = 0, boundVal2 = 0;

                if (k == 2)
                {
                    var bound = lines[idx++].Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    boundIndex = int.Parse(bound[0]);
                    boundVal1 = double.Parse(bound[1], CultureInfo.InvariantCulture);
                }
                else if (k == 3)
                {
                    var bound = lines[idx++].Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    boundVal1 = double.Parse(bound[0], CultureInfo.InvariantCulture); // B0
                    boundVal2 = double.Parse(bound[1], CultureInfo.InvariantCulture); // Bn
                }

                int m = int.Parse(lines[idx++].Trim());
                double[] rx = lines[idx++].Split(' ', StringSplitOptions.RemoveEmptyEntries)
                                          .Select(s => double.Parse(s, CultureInfo.InvariantCulture)).ToArray();

                string isKnownStr = lines[idx++].Trim().ToLower();
                bool isKnown = (isKnownStr == "известно");
                string funcName = isKnown ? lines[idx++].Trim() : "";

                var methods = new Methods();

                using (StreamWriter writer = new StreamWriter(outputFile))
                {
                    writer.WriteLine("=== ПРИБЛИЖЕНИЕ СПЛАЙНАМИ ===");
                    string splineType = k == 1 ? "Линейный" : (k == 2 ? "Параболический" : "Кубический");
                    writer.WriteLine($"Вид сплайна: {splineType} (k = {k})");
                    writer.WriteLine();

                    methods.SolveSplines(k, n, x, y, boundIndex, boundVal1, boundVal2, m, rx, isKnown, funcName, writer);
                }

                Console.WriteLine("Готово! Проверьте файл output.txt");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }
        }
    }
}