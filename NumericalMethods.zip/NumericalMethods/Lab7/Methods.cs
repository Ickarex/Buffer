using System;
using System.IO;

namespace SolvingIntegration
{
    public class Methods
    {
        public void SolveIntegration(int m, int n, double[] x, double[] y, string sType, string funcName, StreamWriter writer)
        {
            if (sType == "аналитическая" && m != 5)
            {
                for (int i = 0; i <= n; i++)
                {
                    y[i] = EvaluateAnalytical(x[i], funcName);
                }
            }

            double[] h = new double[n];
            for (int i = 0; i < n; i++) h[i] = x[i + 1] - x[i];

            double integral = 0;

            if (m == 1)
            {
                for (int i = 0; i < n; i++) integral += y[i] * h[i];
            }
            else if (m == 2)
            {
                for (int i = 0; i < n; i++) integral += y[i + 1] * h[i];
            }
            else if (m == 3)
            {
                for (int i = 0; i < n; i++) integral += (y[i] + y[i + 1]) / 2.0 * h[i];
            }
            else if (m == 4)
            {
                if (n % 2 != 0)
                {
                    writer.WriteLine("ОШИБКА: Для метода Симпсона число интервалов (n) должно быть четным!");
                    return;
                }

                double hUniform = (x[n] - x[0]) / n;
                double sumOdd = 0;
                for (int i = 1; i < n; i += 2) sumOdd += y[i];
                double sumEven = 0;
                for (int i = 2; i < n; i += 2) sumEven += y[i];

                integral = (hUniform / 3.0) * (y[0] + y[n] + 4 * sumOdd + 2 * sumEven);
            }
            else if (m == 5)
            {
                if (sType != "аналитическая")
                {
                    writer.WriteLine("ОШИБКА: Метод Гаусса требует аналитического задания функции, так как узлы вычисляются динамически!");
                    return;
                }

                double[] t = { -Math.Sqrt(3.0 / 5.0), 0, Math.Sqrt(3.0 / 5.0) };
                double[] w = { 5.0 / 9.0, 8.0 / 9.0, 5.0 / 9.0 };

                for (int i = 0; i < n; i++)
                {
                    double a = x[i];
                    double b = x[i + 1];
                    double h_half = (b - a) / 2.0;
                    double center = (a + b) / 2.0;

                    double sum = 0;
                    for (int j = 0; j < 3; j++)
                    {
                        double targetX = h_half * t[j] + center;
                        sum += w[j] * EvaluateAnalytical(targetX, funcName);
                    }
                    integral += h_half * sum;
                }
            }

            writer.WriteLine($"Значение интеграла (I): {integral:F8}");
            
            if (funcName.Contains("sin") && x[n] > 3.14 && x[n] < 3.15)
            {
                writer.WriteLine($"Точное значение:       2,00000000");
                writer.WriteLine($"Погрешность (Δ):       {Math.Abs(2.0 - integral):E4}");
            }
        }

        private double EvaluateAnalytical(double x, string funcName)
        {
            string safeFunc = funcName.Replace(" ", "").ToLower();

            if (safeFunc.Contains("sin(x)")) return Math.Sin(x);
            if (safeFunc.Contains("cos(x)")) return Math.Cos(x);
            if (safeFunc.Contains("x^2") || safeFunc.Contains("x*x")) return x * x;
            if (safeFunc.Contains("x^3")) return Math.Pow(x, 3);
            if (safeFunc.Contains("e^x") || safeFunc.Contains("exp(x)")) return Math.Exp(x);

            Console.WriteLine($"[ПРЕДУПРЕЖДЕНИЕ] Функция '{funcName}' не запрограммирована. Возвращен 0.");
            return 0;
        }
    }
}