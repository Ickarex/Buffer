using System;
using System.Globalization;
using System.IO;
using System.Linq;

namespace SolvingIntegration
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputFile = "input.txt";
            string outputFile = "output.txt";

            if (!File.Exists(inputFile))
            {
                Console.WriteLine($"Файл {inputFile} не найден.");
                return;
            }

            try
            {
                string[] lines = File.ReadAllLines(inputFile)
                                     .Where(l => !string.IsNullOrWhiteSpace(l) && !l.StartsWith("//"))
                                     .ToArray();

                int idx = 0;
                int m = int.Parse(lines[idx++].Trim());
                string gridType = lines[idx++].Trim().ToLower();
                int n = int.Parse(lines[idx++].Trim());

                double[] x = new double[n + 1];
                if (gridType == "равномерная")
                {
                    var ab = lines[idx++].Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    double a = double.Parse(ab[0], CultureInfo.InvariantCulture);
                    double b = double.Parse(ab[1], CultureInfo.InvariantCulture);
                    double h = (b - a) / n;
                    for (int i = 0; i <= n; i++) x[i] = a + i * h;
                }
                else
                {
                    x = lines[idx++].Split(' ', StringSplitOptions.RemoveEmptyEntries)
                                    .Select(s => double.Parse(s, CultureInfo.InvariantCulture)).ToArray();
                }

                string sType = lines[idx++].Trim().ToLower();
                double[] y = new double[n + 1];
                string funcName = "";

                if (sType == "табличная")
                {
                    y = lines[idx++].Split(' ', StringSplitOptions.RemoveEmptyEntries)
                                    .Select(s => double.Parse(s, CultureInfo.InvariantCulture)).ToArray();
                }
                else
                {
                    funcName = lines[idx++].Trim();
                }

                var methods = new Methods();

                using (StreamWriter writer = new StreamWriter(outputFile))
                {
                    writer.WriteLine("=== ЧИСЛЕННОЕ ИНТЕГРИРОВАНИЕ ===");
                    writer.WriteLine($"Метод: {GetMethodName(m)}");
                    writer.WriteLine($"Сетка: {gridType} (n = {n})");
                    writer.WriteLine();

                    methods.SolveIntegration(m, n, x, y, sType, funcName, writer);
                }

                Console.WriteLine("Готово! Проверьте файл output.txt");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
                Console.WriteLine(ex.StackTrace);
            }
        }

        static string GetMethodName(int m)
        {
            if (m == 1) return "Левые прямоугольники";
            if (m == 2) return "Правые прямоугольники";
            if (m == 3) return "Трапеции";
            if (m == 4) return "Симпсон (параболы)";
            if (m == 5) return "Гаусс (3-точечный)";
            return "Неизвестный метод";
        }
    }
}