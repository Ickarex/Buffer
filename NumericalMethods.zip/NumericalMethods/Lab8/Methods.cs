using System;
using System.IO;

namespace SolvingODE
{
    public class Methods
    {
        public void SolveODE(int t, int p, int q, int m, double[] x, double[] y0, string[] f, bool isKnown, string[] Y_exact, StreamWriter writer)
        {
            // 1. Формируем систему функций f_sys для любого типа задачи
            string[] f_sys = new string[p];
            if (t == 1) 
            {
                f_sys[0] = f[0];
            }
            else if (t == 2) 
            {
                f_sys = f;
            }
            else if (t == 3) 
            {
                // Сведение ОДУ n-го порядка к системе уравнений
                for (int i = 0; i < p - 1; i++) f_sys[i] = $"y{i + 2}";
                f_sys[p - 1] = f[0];
            }

            double[,] results = new double[m + 1, p];
            for (int j = 0; j < p; j++) results[0, j] = y0[j];

            // 2. Основной цикл метода Рунге-Кутты
            for (int i = 0; i < m; i++)
            {
                double h = x[i + 1] - x[i];
                
                double[] currentY = new double[p];
                for (int j = 0; j < p; j++) currentY[j] = results[i, j];

                double[] k1 = new double[p];
                double[] k2 = new double[p];
                double[] k3 = new double[p];
                double[] k4 = new double[p];

                // --- Шаг 1 (k1) ---
                for (int j = 0; j < p; j++) k1[j] = h * Eval(f_sys[j], x[i], currentY);

                // --- Шаг 2 (k2) ---
                if (q >= 2) 
                {
                    double[] yTemp = new double[p];
                    for (int j = 0; j < p; j++) yTemp[j] = currentY[j] + k1[j] / 2.0;
                    for (int j = 0; j < p; j++) k2[j] = h * Eval(f_sys[j], x[i] + h / 2.0, yTemp);
                }

                // --- Шаг 3 (k3) ---
                if (q >= 3) 
                {
                    double[] yTemp = new double[p];
                    if (q == 3) {
                        for (int j = 0; j < p; j++) yTemp[j] = currentY[j] - k1[j] + 2.0 * k2[j];
                        for (int j = 0; j < p; j++) k3[j] = h * Eval(f_sys[j], x[i] + h, yTemp);
                    } else {
                        for (int j = 0; j < p; j++) yTemp[j] = currentY[j] + k2[j] / 2.0;
                        for (int j = 0; j < p; j++) k3[j] = h * Eval(f_sys[j], x[i] + h / 2.0, yTemp);
                    }
                }

                // --- Шаг 4 (k4) ---
                if (q == 4) 
                {
                    double[] yTemp = new double[p];
                    for (int j = 0; j < p; j++) yTemp[j] = currentY[j] + k3[j];
                    for (int j = 0; j < p; j++) k4[j] = h * Eval(f_sys[j], x[i] + h, yTemp);
                }

                // --- Итоговая сумма по порядку точности ---
                for (int j = 0; j < p; j++) 
                {
                    if (q == 1) results[i + 1, j] = currentY[j] + k1[j];
                    else if (q == 2) results[i + 1, j] = currentY[j] + k2[j];
                    else if (q == 3) results[i + 1, j] = currentY[j] + (k1[j] + 4.0 * k2[j] + k3[j]) / 6.0;
                    else if (q == 4) results[i + 1, j] = currentY[j] + (k1[j] + 2.0 * k2[j] + 2.0 * k3[j] + k4[j]) / 6.0;
                }
            }

            // 3. Вывод результатов
            writer.Write($"{"x_i", -8}");
            for (int j = 0; j < p; j++) writer.Write($"{"y_" + (j+1), -15}");
            writer.WriteLine("\n" + new string('-', 50));

            for (int i = 0; i <= m; i++)
            {
                writer.Write($"{x[i], -8:F3}");
                for (int j = 0; j < p; j++) writer.Write($"{results[i, j], -15:F6}");
                writer.WriteLine();
            }

            // 4. Подсчет СКО
            if (isKnown)
            {
                writer.WriteLine(new string('-', 50));
                for (int j = 0; j < p; j++)
                {
                    double sumSq = 0;
                    for (int i = 0; i <= m; i++)
                    {
                        double exact = Eval(Y_exact[j], x[i], new double[p]);
                        sumSq += Math.Pow(results[i, j] - exact, 2);
                    }
                    double sko = Math.Sqrt(sumSq) / (m + 1);
                    writer.WriteLine($"СКО (ε) для y_{j+1}: {sko:E4}");
                }
            }
        }

        // Заглушка, вычисляющая аналитические формулы
        private double Eval(string expr, double x, double[] y)
        {
            string safe = expr.Replace(" ", "").ToLower();

            // Автоматические переменные системы (y1, y2...)
            if (safe == "y" || safe == "y1") return y[0];
            if (safe == "y2") return y[1];
            if (safe == "y3") return y[2];
            if (safe == "-y1") return -y[0];

            // Правые части ДУ
            if (safe == "x+y") return x + y[0];
            if (safe == "y-x") return y[0] - x;
            if (safe == "x^2+y^2") return x * x + y[0] * y[0];

            // Точные решения
            if (safe == "exp(x)") return Math.Exp(x);
            if (safe == "2*exp(x)-x-1") return 2 * Math.Exp(x) - x - 1;
            if (safe == "sin(x)") return Math.Sin(x);
            if (safe == "cos(x)") return Math.Cos(x);

            return 0;
        }
    }
}