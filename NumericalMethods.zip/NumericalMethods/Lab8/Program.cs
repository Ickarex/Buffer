using System;
using System.Globalization;
using System.IO;
using System.Linq;

namespace SolvingODE
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputFile = "input.txt";
            string outputFile = "output.txt";

            if (!File.Exists(inputFile)) return;

            try
            {
                string[] lines = File.ReadAllLines(inputFile)
                                     .Where(l => !string.IsNullOrWhiteSpace(l) && !l.StartsWith("//"))
                                     .ToArray();

                int idx = 0;
                int t = int.Parse(lines[idx++].Trim()); // Тип задачи
                
                int p = 1;
                if (t == 2 || t == 3) p = int.Parse(lines[idx++].Trim()); // Кол-во уравнений / порядок ДУ
                
                int q = int.Parse(lines[idx++].Trim()); // Порядок точности Рунге-Кутты
                string gridType = lines[idx++].Trim().ToLower(); // Тип сетки
                int m = int.Parse(lines[idx++].Trim()); // Количество интервалов

                double[] x = new double[m + 1];
                if (gridType == "равномерная")
                {
                    var ab = lines[idx++].Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    double a = double.Parse(ab[0], CultureInfo.InvariantCulture);
                    double b = double.Parse(ab[1], CultureInfo.InvariantCulture);
                    double h = (b - a) / m;
                    for (int i = 0; i <= m; i++) x[i] = a + i * h;
                }
                else
                {
                    x = lines[idx++].Split(' ', StringSplitOptions.RemoveEmptyEntries)
                                    .Select(s => double.Parse(s, CultureInfo.InvariantCulture)).ToArray();
                }

                // Начальные условия y_0
                double[] y0 = lines[idx++].Split(' ', StringSplitOptions.RemoveEmptyEntries)
                                          .Select(s => double.Parse(s, CultureInfo.InvariantCulture)).ToArray();

                // Функции системы
                string[] f = new string[t == 2 ? p : 1];
                for (int i = 0; i < f.Length; i++) f[i] = lines[idx++].Trim();

                // Точное решение (если известно)
                string isKnownStr = lines[idx++].Trim().ToLower();
                bool isKnown = (isKnownStr == "известно");
                string[] Y_exact = new string[t == 2 ? p : 1];
                if (isKnown)
                {
                    for (int i = 0; i < Y_exact.Length; i++) Y_exact[i] = lines[idx++].Trim();
                }

                var methods = new Methods();

                using (StreamWriter writer = new StreamWriter(outputFile))
                {
                    writer.WriteLine("=== РЕШЕНИЕ ОБЫКНОВЕННЫХ ДИФФЕРЕНЦИАЛЬНЫХ УРАВНЕНИЙ ===");
                    writer.WriteLine($"Тип задачи: {(t == 1 ? "ОДУ 1-го порядка" : (t == 2 ? "Система ОДУ" : "ОДУ n-го порядка"))}");
                    writer.WriteLine($"Точность метода Рунге-Кутты: q = {q}");
                    writer.WriteLine(new string('-', 50));

                    methods.SolveODE(t, p, q, m, x, y0, f, isKnown, Y_exact, writer);
                }

                Console.WriteLine("Готово! Проверьте файл output.txt");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
                Console.WriteLine(ex.StackTrace);
            }
        }
    }
}