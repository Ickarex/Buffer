using System;
using System.IO;

namespace SolvingIntegralEquations
{
    public class Methods
    {
        public void SolveIntegral(int q, int p, double a, double b, string K_func, string f_func, double lambda, int n, double eps, bool isKnown, string exact_func, StreamWriter writer)
        {
            if (q == 1)
            {
                writer.WriteLine("ЛИУ 1-го рода (сведение ко 2-му роду) в данной базовой версии не реализовано. Пожалуйста, используйте q=2.");
                return;
            }

            double h = (b - a) / n;
            double[] x = new double[n + 1];
            for (int i = 0; i <= n; i++) x[i] = a + i * h;

            double[] y = new double[n + 1];

            if (p == 1)
            {
                // Метод последовательных приближений
                double[] phi_prev = new double[n + 1];
                for (int i = 0; i <= n; i++) 
                {
                    phi_prev[i] = Eval(f_func, x[i]);
                    y[i] = phi_prev[i];
                }

                double currentEps = 1.0;
                int iter = 1;
                int maxIter = 100;

                while (currentEps > eps && iter < maxIter)
                {
                    double[] phi_curr = new double[n + 1];
                    double maxDiff = 0;

                    for (int i = 0; i <= n; i++)
                    {
                        // Интегрируем методом трапеций: int K(x_i, s) * phi_prev(s) ds
                        double integral = 0;
                        for (int j = 0; j <= n; j++)
                        {
                            double Aj = (j == 0 || j == n) ? h / 2.0 : h;
                            integral += Aj * EvalK(K_func, x[i], x[j]) * phi_prev[j];
                        }

                        phi_curr[i] = integral;
                        double addition = Math.Pow(lambda, iter) * phi_curr[i];
                        y[i] += addition;

                        if (Math.Abs(addition) > maxDiff) maxDiff = Math.Abs(addition);
                    }

                    currentEps = maxDiff;
                    for (int i = 0; i <= n; i++) phi_prev[i] = phi_curr[i];
                    iter++;
                }
                writer.WriteLine($"Выполнено итераций: {iter}");
            }
            else if (p == 2)
            {
                // Метод дискретизации
                double[,] B = new double[n + 1, n + 1];
                double[] F = new double[n + 1];

                for (int i = 0; i <= n; i++)
                {
                    F[i] = Eval(f_func, x[i]);

                    for (int j = 0; j <= n; j++)
                    {
                        // Квадратурные коэффициенты метода трапеций
                        double Aj = (j == 0 || j == n) ? h / 2.0 : h;
                        
                        // Кронекеровская дельта (1 если i==j, иначе 0)
                        double delta = (i == j) ? 1.0 : 0.0;
                        
                        // Формирование матрицы системы
                        B[i, j] = delta - lambda * Aj * EvalK(K_func, x[i], x[j]);
                    }
                }

                y = SolveGauss(B, F, n + 1);
            }

            // Вывод результатов
            writer.WriteLine(new string('-', 45));
            writer.WriteLine($"{"x_i", -10} {"y_i (Числ)", -15} {(isKnown ? "y_i (Точн)" : "")}");
            writer.WriteLine(new string('-', 45));

            double sumSq = 0;

            for (int i = 0; i <= n; i++)
            {
                writer.Write($"{x[i], -10:F4} {y[i], -15:F6}");
                if (isKnown)
                {
                    double exact = Eval(exact_func, x[i]);
                    writer.Write($" {exact, -15:F6}");
                    sumSq += Math.Pow(y[i] - exact, 2);
                }
                writer.WriteLine();
            }

            if (isKnown)
            {
                double sko = Math.Sqrt(sumSq / (n + 1));
                writer.WriteLine(new string('-', 45));
                writer.WriteLine($"СКО (ε): {sko:E4}");
            }
        }

        // Внутренний метод Гаусса для решения СЛАУ
        private double[] SolveGauss(double[,] A, double[] b, int n)
        {
            double[] x = new double[n];
            for (int k = 0; k < n - 1; k++)
            {
                for (int i = k + 1; i < n; i++)
                {
                    double factor = A[i, k] / A[k, k];
                    for (int j = k; j < n; j++) A[i, j] -= factor * A[k, j];
                    b[i] -= factor * b[k];
                }
            }
            for (int i = n - 1; i >= 0; i--)
            {
                double sum = 0;
                for (int j = i + 1; j < n; j++) sum += A[i, j] * x[j];
                x[i] = (b[i] - sum) / A[i, i];
            }
            return x;
        }

        // Парсер ядра K(x,s)
        private double EvalK(string expr, double x, double s)
        {
            string eq = expr.Replace(" ", "").ToLower();
            if (eq == "x*s") return x * s;
            if (eq == "x+s") return x + s;
            return 0;
        }

        // Парсер обычных функций
        private double Eval(string expr, double x)
        {
            string eq = expr.Replace(" ", "").ToLower();
            if (eq == "x") return x;
            if (eq == "(5/6)*x" || eq == "5/6*x") return (5.0 / 6.0) * x;
            if (eq == "1") return 1.0;
            return 0;
        }
    }
}