using System;
using System.Globalization;
using System.IO;
using System.Linq;

namespace SolvingIntegralEquations
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputFile = "input.txt";
            string outputFile = "output.txt";

            if (!File.Exists(inputFile)) return;

            try
            {
                string[] lines = File.ReadAllLines(inputFile)
                                     .Where(l => !string.IsNullOrWhiteSpace(l) && !l.StartsWith("//"))
                                     .ToArray();

                int idx = 0;
                int q = int.Parse(lines[idx++].Trim()); // 1 - ЛИУ 1-го рода, 2 - ЛИУ 2-го рода
                int p = int.Parse(lines[idx++].Trim()); // 1 - Послед. приближения, 2 - Дискретизация

                var ab = lines[idx++].Split(' ', StringSplitOptions.RemoveEmptyEntries);
                double a = double.Parse(ab[0], CultureInfo.InvariantCulture);
                double b = double.Parse(ab[1], CultureInfo.InvariantCulture);

                string K_func = lines[idx++].Trim(); // Ядро K(x,s)
                string f_func = lines[idx++].Trim(); // Правая часть f(x)

                double lambda = 0;
                if (q == 2) lambda = double.Parse(lines[idx++].Trim(), CultureInfo.InvariantCulture);

                int n = int.Parse(lines[idx++].Trim()); // Количество интервалов сетки

                double eps = 0;
                if (p == 1) eps = double.Parse(lines[idx++].Trim(), CultureInfo.InvariantCulture);

                string isKnownStr = lines[idx++].Trim().ToLower();
                bool isKnown = (isKnownStr == "известно");
                string exact_func = isKnown ? lines[idx++].Trim() : "";

                var methods = new Methods();

                using (StreamWriter writer = new StreamWriter(outputFile))
                {
                    writer.WriteLine("=== РЕШЕНИЕ ЛИНЕЙНЫХ ИНТЕГРАЛЬНЫХ УРАВНЕНИЙ ===");
                    writer.WriteLine($"Тип уравнения: Фредгольма {q}-го рода");
                    writer.WriteLine($"Метод: {(p == 1 ? "Последовательных приближений" : "Дискретизации")}");
                    writer.WriteLine(new string('-', 45));

                    methods.SolveIntegral(q, p, a, b, K_func, f_func, lambda, n, eps, isKnown, exact_func, writer);
                }

                Console.WriteLine("Готово! Проверьте файл output.txt");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }
        }
    }
}